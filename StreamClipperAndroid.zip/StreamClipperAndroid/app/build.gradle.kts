plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The access-key secret comes from the GitHub secret LICENSE_SECRET (or a Gradle property for local builds).
// Use the same text in the KeyMaker app, and never change it, or old keys stop working.
val licenseSecret: String = System.getenv("LICENSE_SECRET")?.takeIf { it.isNotBlank() }
    ?: (project.findProperty("LICENSE_SECRET") as String?) ?: ""
if (licenseSecret.length < 12) {
    throw GradleException(
        "LICENSE_SECRET is missing or too short. In GitHub: Settings > Secrets and variables > Actions > " +
            "New repository secret, name LICENSE_SECRET, value = any long random text (16+ characters). " +
            "Use the same value for the KeyMaker app."
    )
}

android {
    namespace = "app.streamclipper"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.streamclipper"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }   // Oppo K13 Turbo Pro is arm64
        buildConfigField("String", "LICENSE_SECRET", "\"" + licenseSecret.replace("\\", "\\\\").replace("\"", "\\\"") + "\"")
    }

    buildFeatures { buildConfig = true }

    // One fixed signing key for every build, so a new version installs over the old one
    // (no uninstalling) and the app keeps its data and its access key.
    signingConfigs {
        create("ci") {
            storeFile = file("ci.keystore")
            storePassword = "android"
            keyAlias = "ci"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("ci") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs { useLegacyPackaging = true }   // needed so yt-dlp/ffmpeg binaries can be executed
        resources {
            excludes += setOf(
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES",
                "META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/INDEX.LIST"
            )
        }
    }
}

dependencies {
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
    implementation("com.google.mlkit:face-detection:16.1.6")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.alphacephei:vosk-android:0.3.47")      // offline speech-to-text for captions
    implementation("net.java.dev.jna:jna:5.13.0@aar")
}
