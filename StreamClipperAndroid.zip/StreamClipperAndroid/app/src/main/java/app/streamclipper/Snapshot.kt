package app.streamclipper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File

/** Grabs one frame of a stream, video link or phone video so the user can mark the facecam on it. */
object Snapshot {
    fun grab(ctx: Context, source: String, isUri: Boolean, variant: Int, log: (String) -> Unit): Bitmap {
        if (isUri) return fromPhone(ctx, source, variant)
        Bins.init(ctx)
        val work = File(ctx.cacheDir, "snap").apply { deleteRecursively(); mkdirs() }
        try {
            val r = Bins.resolve(source, log, 720)
            val v = r.video
            val isHls = v.contains("m3u8") || v.contains("hls_playlist") || v.contains("hls_variant")
            val file: File
            if (isHls) {
                val pl = Hls.parse(Hls.mediaUrl(v, 720))
                if (pl.segs.isEmpty()) throw IllegalStateException("the stream has no video yet")
                val n = pl.segs.size
                // Live: a recent segment (another one each time). Recorded: a spot early in the video.
                val idx = if (pl.ended) (n * (0.15 + 0.2 * variant)).toInt() % n else (n - 1 - variant).mod(n)
                file = File(work, "seg.ts")
                file.outputStream().use { o ->
                    pl.mapUri?.let { o.write(Hls.get(it)) }
                    o.write(Hls.get(pl.segs[idx].uri))
                }
            } else {
                val start = 5 + variant * 20
                file = Bins.download(source, work, "snap", log, "*$start-${start + 3}", 480)
            }
            val jpg = File(work, "frame.jpg")
            val out = Bins.run(
                listOf("-y", "-loglevel", "error", "-i", file.absolutePath, "-frames:v", "1", "-vf", "scale=1280:-2", "-q:v", "2", jpg.absolutePath)
            ).second
            return BitmapFactory.decodeFile(jpg.absolutePath)
                ?: throw IllegalStateException("couldn't read a frame ${out.take(80)}")
        } finally {
            work.deleteRecursively()
        }
    }

    private fun fromPhone(ctx: Context, source: String, variant: Int): Bitmap {
        val m = MediaMetadataRetriever()
        try {
            m.setDataSource(ctx, Uri.parse(source))
            val durUs = (m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000
            val t = if (durUs > 0) (durUs * (0.1 + 0.18 * variant)).toLong() % durUs else 1_000_000L
            val f = m.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: throw IllegalStateException("couldn't read a frame from that video")
            return if (f.width > 1280) Bitmap.createScaledBitmap(f, 1280, (f.height * 1280L / f.width).toInt(), true) else f
        } finally {
            m.release()
        }
    }
}
