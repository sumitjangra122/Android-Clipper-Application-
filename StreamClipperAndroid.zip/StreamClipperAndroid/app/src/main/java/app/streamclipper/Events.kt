package app.streamclipper

import kotlin.math.max
import kotlin.math.min

/** A burst of action: when it started building, its strongest moment, and the last moment it was still active. */
class Event(val onset: Double, val peak: Double, val peakScore: Double, val end: Double)

/** A moment of the stream or video to cut, in seconds on the same clock as the scores. */
class ClipSpan(val start: Double, val end: Double)

/**
 * Turns a stream of scores (one per 0.5 s) into whole events with a start and an end,
 * instead of single trigger points. An event opens when the score passes [thr()], and stays open
 * until it has been calm for [calmSec]. The onset is found by walking back to where the score began to rise.
 */
class EventDetector(
    private val thr: () -> Double,
    private val calmSec: Double = 6.0,
    private val maxSec: Double = 75.0,
) {
    private val history = ArrayDeque<Pair<Double, Double>>()
    private var active = false
    private var onset = 0.0
    private var lastHigh = 0.0
    private var peak = 0.0
    private var peakScore = 0.0

    private fun low() = max(1.0, thr() * 0.5)

    /** Start of the event in progress, or null. Used to keep its video in the buffer. */
    fun activeOnset(): Double? = if (active) onset else null

    fun feed(t: Double, score: Double): Event? {
        history.addLast(t to score)
        while (history.size > 120) history.removeFirst()      // ~60 s
        if (!active) {
            if (score >= thr()) {
                active = true
                var o = t
                for (i in history.indices.reversed()) {
                    val (ht, hs) = history[i]
                    if (hs >= low()) o = ht else break
                }
                onset = o
                lastHigh = t
                peak = t
                peakScore = score
            }
            return null
        }
        if (score >= low()) lastHigh = t
        if (score > peakScore) {
            peak = t
            peakScore = score
        }
        if (t - lastHigh >= calmSec || t - onset >= maxSec) {
            active = false
            return Event(onset, peak, peakScore, lastHigh)
        }
        return null
    }

    /** Closes any open event, for the end of a video. */
    fun finish(): Event? {
        if (!active) return null
        active = false
        return Event(onset, peak, peakScore, lastHigh)
    }
}

object ClipWindow {
    const val LEAD = 5.0     // seconds of build-up before the action starts
    const val TAIL = 3.0     // seconds after the action ends
    const val MIN_AUTO = 12.0
    const val MAX_AUTO = 90.0

    /**
     * @param length wanted clip length in seconds, or 0 for "auto" (as long as the action lasts)
     */
    fun compute(e: Event, length: Int): ClipSpan {
        val span = e.end - e.onset
        if (length <= 0) {
            var s = e.onset - LEAD
            var t = e.end + TAIL
            if (t - s < MIN_AUTO) {
                val pad = MIN_AUTO - (t - s)
                s -= pad * 0.4
                t += pad * 0.6
            }
            if (t - s > MAX_AUTO) {
                s = max(e.onset - LEAD, min(e.peak - MAX_AUTO * 0.45, e.end + TAIL - MAX_AUTO))
                t = s + MAX_AUTO
            }
            return ClipSpan(s, t)
        }
        val len = length.toDouble()
        val need = span + LEAD + TAIL
        if (need <= len) {
            // the whole action fits: spread the spare time, a bit more before than after
            val s = e.onset - LEAD - (len - need) * 0.3
            return ClipSpan(s, s + len)
        }
        // the action is longer than the clip: centre on the strongest moment, never start before the build-up
        var s = e.peak - len * 0.45
        s = max(s, e.onset - LEAD)
        s = min(s, e.end + TAIL - len)
        return ClipSpan(s, s + len)
    }
}
