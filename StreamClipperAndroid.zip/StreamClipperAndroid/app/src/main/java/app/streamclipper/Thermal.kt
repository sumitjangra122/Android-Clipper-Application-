package app.streamclipper

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager

/** Keeps the phone from cooking itself while it edits clips. */
object Thermal {
    fun batteryTempC(ctx: Context): Float {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    /** 0 = fine, 1 = warm, 2 = hot, 3 = very hot. */
    fun level(ctx: Context): Int {
        val t = batteryTempC(ctx)
        val s = try {
            ctx.getSystemService(PowerManager::class.java)?.currentThermalStatus ?: 0
        } catch (_: Throwable) {
            0
        }
        return when {
            s >= PowerManager.THERMAL_STATUS_SEVERE || t >= 45f -> 3
            s >= PowerManager.THERMAL_STATUS_MODERATE || t >= 42f -> 2
            s >= PowerManager.THERMAL_STATUS_LIGHT || t >= 39f -> 1
            else -> 0
        }
    }

    /** Pauses (up to [maxWaitMs]) while the phone is hot. Returns the level when it carries on. */
    fun coolDown(ctx: Context, log: (String) -> Unit, maxWaitMs: Long = 4 * 60_000L): Int {
        var waited = 0L
        var told = false
        while (level(ctx) >= 2 && waited < maxWaitMs) {
            if (!told) {
                told = true
                log("Phone is hot (${batteryTempC(ctx).toInt()}\u00B0C), pausing edits to cool down\u2026")
            }
            Thread.sleep(15_000)
            waited += 15_000
        }
        return level(ctx)
    }
}
