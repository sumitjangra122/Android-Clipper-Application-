package app.streamclipper

import java.text.Normalizer

/**
 * Hindi in Devanagari -> casual Roman ("Hinglish"), the way people type it: "mai ja rha hu".
 * Common words come from a dictionary in everyday spelling; everything else goes through spelling rules
 * with schwa deletion (so "सबसे" becomes "sabse", not "sabase").
 */
object Hinglish {
    private val dict: Map<String, String> = HashMap<String, String>().apply {
        fun add(roman: String, vararg words: String) { for (w in words) put(Normalizer.normalize(w, Normalizer.Form.NFC), roman) }
        // pronouns and basics
        add("mai", "मैं", "मै"); add("maine", "मैंने"); add("mujhe", "मुझे"); add("mujhko", "मुझको"); add("mera", "मेरा")
        add("meri", "मेरी"); add("mere", "मेरे"); add("hum", "हम"); add("hume", "हमें"); add("humara", "हमारा"); add("humari", "हमारी")
        add("tum", "तुम"); add("tumne", "तुमने"); add("tumhe", "तुम्हें"); add("tumhara", "तुम्हारा"); add("tumhari", "तुम्हारी")
        add("tu", "तू"); add("tujhe", "तुझे"); add("tera", "तेरा"); add("teri", "तेरी"); add("tere", "तेरे")
        add("aap", "आप"); add("aapka", "आपका"); add("aapki", "आपकी"); add("aapko", "आपको"); add("wo", "वो", "वह")
        add("we", "वे"); add("use", "उसे"); add("usko", "उसको"); add("uska", "उसका"); add("uski", "उसकी"); add("unhe", "उन्हें")
        add("unka", "उनका"); add("ye", "ये", "यह"); add("is", "इस"); add("ise", "इसे"); add("iska", "इसका"); add("iski", "इसकी")
        add("us", "उस"); add("in", "इन"); add("kaun", "कौन"); add("kya", "क्या"); add("kyu", "क्यों", "क्यूं"); add("kab", "कब")
        add("kaha", "कहाँ", "कहां"); add("kaise", "कैसे"); add("kaisa", "कैसा"); add("kaisi", "कैसी"); add("kitna", "कितना")
        add("kitne", "कितने"); add("kitni", "कितनी"); add("koi", "कोई"); add("kuch", "कुछ"); add("sab", "सब"); add("sabse", "सबसे")
        add("bahut", "बहुत"); add("thoda", "थोड़ा"); add("bas", "बस"); add("bhi", "भी"); add("hi", "ही"); add("to", "तो")
        add("na", "ना"); add("nahi", "नहीं", "नही"); add("mat", "मत"); add("aur", "और"); add("ya", "या"); add("lekin", "लेकिन")
        add("par", "पर"); add("pe", "पे"); add("se", "से"); add("ko", "को"); add("ka", "का"); add("ki", "की"); add("ke", "के")
        add("me", "में", "मे"); add("tak", "तक"); add("liye", "लिए", "लिये"); add("sath", "साथ"); add("baad", "बाद")
        add("pehle", "पहले"); add("ab", "अब"); add("abhi", "अभी"); add("phir", "फिर"); add("jab", "जब"); add("tab", "तब")
        add("yaha", "यहाँ", "यहां"); add("waha", "वहाँ", "वहां"); add("aise", "ऐसे"); add("aisa", "ऐसा"); add("aisi", "ऐसी")
        add("waise", "वैसे"); add("itna", "इतना"); add("itne", "इतने"); add("utna", "उतना"); add("jo", "जो"); add("jise", "जिसे")
        add("jaise", "जैसे"); add("kyunki", "क्योंकि"); add("agar", "अगर"); add("magar", "मगर"); add("warna", "वरना")
        add("kabhi", "कभी"); add("hamesha", "हमेशा"); add("sirf", "सिर्फ़", "सिर्फ"); add("bilkul", "बिल्कुल", "बिलकुल")
        add("sach", "सच"); add("jhooth", "झूठ"); add("sahi", "सही"); add("galat", "गलत", "ग़लत"); add("theek", "ठीक")
        // to be
        add("hai", "है", "हैं"); add("tha", "था"); add("thi", "थी"); add("the", "थे"); add("ho", "हो"); add("hu", "हूँ", "हूं")
        add("hua", "हुआ"); add("hui", "हुई"); add("hue", "हुए"); add("hoga", "होगा"); add("hogi", "होगी"); add("honge", "होंगे")
        add("hota", "होता"); add("hoti", "होती"); add("hote", "होते"); add("hogaya", "होगया")
        add("rha", "रहा"); add("rhi", "रही"); add("rhe", "रहे")
        // common verbs
        add("gaya", "गया"); add("gayi", "गई", "गयी"); add("gaye", "गए", "गये"); add("ja", "जा"); add("jana", "जाना")
        add("jata", "जाता"); add("jati", "जाती"); add("jate", "जाते"); add("jao", "जाओ"); add("jaunga", "जाऊँगा", "जाऊंगा")
        add("aa", "आ"); add("aaya", "आया"); add("aayi", "आई"); add("aao", "आओ"); add("aana", "आना"); add("aata", "आता")
        add("kar", "कर"); add("karna", "करना"); add("karta", "करता"); add("karti", "करती"); add("karte", "करते"); add("karo", "करो")
        add("kiya", "किया"); add("kare", "करे"); add("karega", "करेगा"); add("karenge", "करेंगे"); add("de", "दे"); add("dena", "देना")
        add("diya", "दिया"); add("do", "दो"); add("le", "ले"); add("lena", "लेना"); add("liya", "लिया"); add("lo", "लो")
        add("dekh", "देख"); add("dekho", "देखो"); add("dekha", "देखा"); add("dekhna", "देखना"); add("bol", "बोल"); add("bola", "बोला")
        add("bolo", "बोलो"); add("bata", "बता"); add("batao", "बताओ"); add("bataya", "बताया"); add("sun", "सुन"); add("suno", "सुनो")
        add("chal", "चल"); add("chalo", "चलो"); add("chala", "चला"); add("ruk", "रुक"); add("ruko", "रुको"); add("mil", "मिल")
        add("mila", "मिला"); add("mili", "मिली"); add("pata", "पता"); add("samajh", "समझ"); add("samjha", "समझा"); add("chahiye", "चाहिए")
        add("chahta", "चाहता"); add("lagta", "लगता"); add("lagi", "लगी"); add("laga", "लगा"); add("bhai", "भाई"); add("yaar", "यार")
        add("dost", "दोस्त"); add("bhaiya", "भैया"); add("sir", "सर"); add("bro", "ब्रो"); add("pagal", "पागल"); add("mast", "मस्त")
        add("kamaal", "कमाल"); add("zabardast", "ज़बरदस्त", "जबरदस्त"); add("ekdam", "एकदम"); add("seedha", "सीधा")
        add("aaj", "आज"); add("kal", "कल"); add("raat", "रात"); add("din", "दिन"); add("time", "टाइम"); add("baat", "बात")
        add("kaam", "काम"); add("log", "लोग"); add("naam", "नाम"); add("paisa", "पैसा"); add("paise", "पैसे"); add("ghar", "घर")
        add("gaadi", "गाड़ी"); add("duniya", "दुनिया"); add("zindagi", "ज़िंदगी", "जिंदगी"); add("pyaar", "प्यार"); add("ek", "एक")
        add("do", "दो"); add("teen", "तीन"); add("char", "चार"); add("paanch", "पांच", "पाँच"); add("bada", "बड़ा"); add("badi", "बड़ी")
        add("bade", "बड़े"); add("chhota", "छोटा"); add("accha", "अच्छा"); add("achha", "अच्छा"); add("acchi", "अच्छी"); add("bura", "बुरा")
        add("naya", "नया"); add("nayi", "नई"); add("purana", "पुराना"); add("sabko", "सबको"); add("sabka", "सबका")
        // gaming and internet words that Hindi speech comes out in Devanagari
        add("clutch", "क्लच"); add("game", "गेम"); add("gaming", "गेमिंग"); add("kill", "किल"); add("fight", "फाइट"); add("match", "मैच")
        add("player", "प्लेयर"); add("team", "टीम"); add("squad", "स्क्वाड"); add("stream", "स्ट्रीम"); add("live", "लाइव")
        add("video", "वीडियो"); add("channel", "चैनल"); add("subscribe", "सब्सक्राइब"); add("like", "लाइक"); add("share", "शेयर")
        add("comment", "कमेंट"); add("follow", "फॉलो"); add("phone", "फोन"); add("mobile", "मोबाइल"); add("ok", "ओके")
        add("hello", "हेलो"); add("thanks", "थैंक्स"); add("sorry", "सॉरी"); add("please", "प्लीज़", "प्लीज"); add("boss", "बॉस")
        add("grenade", "ग्रेनेड"); add("sniper", "स्नाइपर"); add("zone", "ज़ोन", "जोन"); add("circle", "सर्कल"); add("loot", "लूट")
        add("headshot", "हेडशॉट"); add("chicken", "चिकन"); add("dinner", "डिनर"); add("insta", "इंस्टा"); add("youtube", "यूट्यूब")
        add("of", "ऑफ"); add("on", "ऑन"); add("off", "ऑफ"); add("op", "ओपी"); add("noob", "नूब"); add("pro", "प्रो"); add("level", "लेवल"); add("rank", "रैंक"); add("tournament", "टूर्नामेंट")
        add("income", "इनकम"); add("source", "सोर्स"); add("scene", "सीन"); add("full", "फुल"); add("sure", "श्योर"); add("fan", "फैन")
        add("massage", "मसाज"); add("reaction", "रिएक्शन"); add("roast", "रोस्ट"); add("funny", "फनी"); add("comedy", "कॉमेडी")
    }

    private const val VIRAMA = '\u094D'
    private const val NUKTA = '\u093C'
    private const val ANUSVARA = '\u0902'
    private const val CHANDRA = '\u0901'
    private const val VISARGA = '\u0903'

    private val cons = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n", 'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh",
        'ञ' to "n", 'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n", 'त' to "t", 'थ' to "th", 'द' to "d",
        'ध' to "dh", 'न' to "n", 'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m", 'य' to "y", 'र' to "r",
        'ल' to "l", 'ळ' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h",
    )
    private val nuktaCons = mapOf('क' to "k", 'ख' to "kh", 'ग' to "g", 'ज' to "z", 'ड' to "d", 'ढ' to "dh", 'फ' to "f", 'य' to "y")
    private val indep = mapOf(
        'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "u", 'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai",
        'ओ' to "o", 'औ' to "au", 'ऑ' to "o", 'ऍ' to "e",
    )
    private val matra = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "u", 'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o",
        'ौ' to "au", 'ॉ' to "o", 'ॅ' to "e",
    )

    private class Syl(var onset: String, var vowel: String?, var nasal: Boolean = false, var visarga: Boolean = false)

    /** Roman spelling of one Devanagari word. Text that isn't Devanagari is returned as it is. */
    fun word(raw: String): String {
        val w = Normalizer.normalize(raw.trim(), Normalizer.Form.NFC)
        if (w.isEmpty()) return w
        dict[w]?.let { return it }
        if (w.none { it in '\u0900'..'\u097F' }) return w
        return rules(w)
    }

    private fun rules(s: String): String {
        val syls = ArrayList<Syl>()
        val pending = StringBuilder()
        var i = 0
        val n = s.length
        while (i < n) {
            val c = s[i]
            val base = cons[c]
            when {
                base != null -> {
                    i++
                    var r: String = base
                    if (i < n && s[i] == NUKTA) {
                        r = nuktaCons[c] ?: base
                        i++
                    }
                    if (c == 'ञ' && pending.toString() == "j") pending.clear().append("gy") else pending.append(r)
                    if (i < n && s[i] == VIRAMA) {
                        i++
                        continue   // conjunct: the next consonant joins this one
                    }
                    val syl = Syl(pending.toString(), null)
                    pending.clear()
                    if (i < n && matra.containsKey(s[i])) {
                        syl.vowel = matra[s[i]]
                        i++
                    }
                    syls.add(syl)
                }
                indep.containsKey(c) -> {
                    syls.add(Syl("", if (syls.isEmpty()) indep[c] else (indep[c] ?: "a").let { if (it == "aa") "a" else it }))
                    i++
                }
                c == ANUSVARA || c == CHANDRA -> {
                    syls.lastOrNull()?.nasal = true
                    i++
                }
                c == VISARGA -> {
                    syls.lastOrNull()?.visarga = true
                    i++
                }
                c == VIRAMA || c == NUKTA -> i++
                else -> {
                    syls.add(Syl(c.toString(), ""))
                    i++
                }
            }
        }
        if (pending.isNotEmpty()) syls.add(Syl(pending.toString(), ""))

        // Schwa deletion: the spoken word drops many of the inherent 'a's.
        val keep = BooleanArray(syls.size) { syls[it].vowel == null }
        val count = syls.size
        for (k in 0 until count) {
            if (syls[k].vowel != null) continue
            if (count > 1 && k == count - 1) {
                keep[k] = false                                   // word-final a
            } else if (k > 0 && k < count - 1) {
                val prevRealized = syls[k - 1].vowel != "" && (syls[k - 1].vowel != null || keep[k - 1])
                val nextExplicit = syls[k + 1].vowel != null && syls[k + 1].vowel != ""
                if (prevRealized && nextExplicit) keep[k] = false  // medial a before a syllable with a clear vowel
            }
        }

        val sb = StringBuilder()
        for (k in 0 until count) {
            val sy = syls[k]
            sb.append(sy.onset)
            when {
                sy.vowel == null -> if (keep[k]) sb.append('a')
                else -> sb.append(sy.vowel)
            }
            if (sy.nasal && k < count - 1) {
                val next = syls[k + 1].onset
                sb.append(if (next.startsWith("p") || next.startsWith("b") || next.startsWith("m")) 'm' else 'n')
            }
            if (sy.visarga) sb.append('h')
        }
        return sb.toString()
    }
}
