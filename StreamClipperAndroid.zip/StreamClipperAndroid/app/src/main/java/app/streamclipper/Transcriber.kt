package app.streamclipper

import android.content.Context
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.zip.ZipInputStream
import kotlin.math.min

/** Offline speech-to-text for captions (Vosk). English and Hindi models are downloaded once. */
object Transcriber {
    private val models = listOf(
        Triple("English", "vosk-model-small-en-us-0.15", "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"),
        Triple("Hindi", "vosk-model-small-hi-0.22", "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"),
    )

    // Languages: 0 English, 1 Hindi speech written in English letters (Hinglish), 2 Hindi in Devanagari.
    // Hinglish and Devanagari use the same Hindi speech model.
    private fun mi(lang: Int) = if (lang == 0) 0 else 1

    fun langName(lang: Int) = when (lang) { 0 -> "English"; 1 -> "Hinglish"; else -> "Hindi" }

    /** Which speech model a language needs: "English" or "Hindi". */
    fun modelLabel(lang: Int) = models[mi(lang)].first

    private fun modelDir(ctx: Context, lang: Int) = File(ctx.filesDir, "vosk/${models[mi(lang)].second}")

    fun hasModel(ctx: Context, lang: Int): Boolean = File(modelDir(ctx, lang), "am").isDirectory

    private fun download(url: String, to: File, log: (String) -> Unit) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.instanceFollowRedirects = true
        try {
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            val total = c.contentLengthLong
            var done = 0L
            var step = -1
            c.inputStream.use { ins ->
                to.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val s = (done * 5 / total).toInt()
                            if (s != step) {
                                step = s
                                log("Downloading captions model… ${done * 100 / total}%")
                            }
                        }
                    }
                }
            }
        } finally {
            c.disconnect()
        }
    }

    private fun unzip(zip: File, into: File) {
        into.mkdirs()
        val root = into.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val f = File(into, e.name)
                if (!f.canonicalPath.startsWith(root)) continue   // never write outside the target folder
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { z.copyTo(it) }
                }
            }
        }
    }

    /** Returns the model folder, downloading it first if needed. */
    fun ensureModel(ctx: Context, lang: Int, log: (String) -> Unit): File {
        val dir = modelDir(ctx, lang)
        if (hasModel(ctx, lang)) return dir
        val (name, _, url) = models[mi(lang)]
        log("Downloading the $name captions model (about 40 MB, only once)…")
        val tmp = File(ctx.cacheDir, "vosk_model_$lang.zip")
        try {
            download(url, tmp, log)
            unzip(tmp, File(ctx.filesDir, "vosk"))
        } finally {
            tmp.delete()
        }
        if (!hasModel(ctx, lang)) throw IllegalStateException("the $name model didn't unpack correctly")
        return dir
    }

    /** For the settings buttons: download in the background, then report. [done] gets null on success. */
    fun prefetch(ctx: Context, lang: Int, done: (String?) -> Unit) {
        Thread {
            try {
                ensureModel(ctx.applicationContext, lang) { }
                done(null)
            } catch (e: Exception) {
                done(e.message ?: e.javaClass.simpleName)
            }
        }.start()
    }

    private fun collect(json: String, out: MutableList<CapWord>) {
        val arr = try {
            JSONObject(json).optJSONArray("result")
        } catch (_: Exception) {
            null
        } ?: return
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val w = o.optString("word").trim()
            if (w.isNotEmpty()) out.add(CapWord(w, o.optDouble("start"), o.optDouble("end")))
        }
    }

    /** Timed words spoken in the part of [input] from [ss] for [len] seconds (times start at 0 for the clip). */
    fun words(ctx: Context, input: File, ss: Double, len: Double, lang: Int, log: (String) -> Unit): List<CapWord> {
        val dir = ensureModel(ctx, lang, log)
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        val pcm = Bins.bytes(
            listOf(
                "-loglevel", "error", "-ss", String.format(Locale.US, "%.3f", ss), "-t", String.format(Locale.US, "%.3f", len),
                "-i", input.absolutePath, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-",
            )
        )
        if (pcm.size < 16000) return emptyList()
        val model = Model(dir.absolutePath)
        try {
            val rec = Recognizer(model, 16000f)
            rec.setWords(true)
            val out = ArrayList<CapWord>()
            var off = 0
            while (off < pcm.size) {
                val n = min(8000, pcm.size - off)
                val chunk = pcm.copyOfRange(off, off + n)
                if (rec.acceptWaveForm(chunk, n)) collect(rec.result, out)
                off += n
            }
            collect(rec.finalResult, out)
            rec.close()
            if (lang == 1) {
                // Hindi speech written in English letters, the way people type it ("mai ja rha hu")
                return out.map { CapWord(Hinglish.word(it.text), it.start, it.end) }.filter { it.text.isNotBlank() }
            }
            return out
        } finally {
            model.close()
        }
    }

    /** Copies the bundled caption fonts out of the APK so ffmpeg can read them. */
    fun fontsDir(ctx: Context): File {
        val dir = File(ctx.filesDir, Captions.FONTS_DIR_NAME)
        dir.mkdirs()
        for (name in ctx.assets.list("fonts") ?: emptyArray()) {
            val f = File(dir, name)
            if (!f.exists() || f.length() == 0L) {
                ctx.assets.open("fonts/$name").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            }
        }
        return dir
    }
}
