package app.streamclipper

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** A screen area as fractions of the frame. */
class Area(val l: Double, val t: Double, val r: Double, val b: Double)

/** Which game is being watched. It changes what "something happened" looks like on screen. */
enum class Game(val label: String, val wMotion: Double, val wFlash: Double, val wRed: Double, val wHud: Double, val hud: List<Area>) {
    GENERAL("General", 1.0, 0.6, 0.3, 0.0, emptyList()),
    // BGMI: kill feed top right, kills and knock banners top centre, red hit flashes
    BGMI("BGMI", 0.8, 0.5, 0.6, 1.0, listOf(Area(0.60, 0.0, 1.0, 0.30), Area(0.30, 0.10, 0.70, 0.40))),
    // GTA: explosions, crashes, shootouts show up as flashes and big motion
    GTA("GTA", 1.0, 1.0, 0.5, 0.0, emptyList());

    companion object {
        fun of(i: Int): Game = values().getOrElse(i) { GENERAL }
    }
}

class FrameFeatures(val motion: Double, val flash: Double, val red: Double, val hud: Double)

/** Cheap per-frame features from tiny RGB frames (for example 96x54). Keeps the previous frame to measure change. */
class VisualFeatures(private val w: Int, private val h: Int, private val game: Game) {
    private var prev: IntArray? = null
    private var prevMean = 0.0

    private fun inHud(x: Int, y: Int): Boolean {
        val fx = (x + 0.5) / w
        val fy = (y + 0.5) / h
        for (a in game.hud) if (fx >= a.l && fx <= a.r && fy >= a.t && fy <= a.b) return true
        return false
    }

    fun feed(rgb: ByteArray, off: Int): FrameFeatures {
        val n = w * h
        val g = IntArray(n)
        var sum = 0L
        var red = 0
        for (i in 0 until n) {
            val r = rgb[off + 3 * i].toInt() and 255
            val gg = rgb[off + 3 * i + 1].toInt() and 255
            val b = rgb[off + 3 * i + 2].toInt() and 255
            val y = (r * 30 + gg * 59 + b * 11) / 100
            g[i] = y
            sum += y
            if (r > 140 && r * 10 > gg * 18 && r * 10 > b * 18) red++
        }
        val mean = sum.toDouble() / n
        val p = prev
        var motion = 0.0
        var hud = 0.0
        var flash = 0.0
        if (p != null) {
            var ms = 0L
            var hs = 0L
            var hn = 0
            for (y in 0 until h) for (x in 0 until w) {
                val d = abs(g[y * w + x] - p[y * w + x])
                ms += d
                if (game.hud.isNotEmpty() && inHud(x, y)) { hs += d; hn++ }
            }
            motion = ms.toDouble() / n
            hud = if (hn > 0) hs.toDouble() / hn else 0.0
            flash = abs(mean - prevMean)
        }
        prev = g
        prevMean = mean
        return FrameFeatures(motion, flash, red.toDouble() / n, hud)
    }
}

/** Rolling "what is normal for this stream" so a loud or busy stream doesn't trigger on everything. */
class Baseline(private val keep: Int = 240, private val sdFloor: Double) {
    private val hist = ArrayDeque<Double>()

    fun z(x: Double): Double {
        if (hist.size < 20) return 0.0
        val mean = hist.average()
        var v = 0.0
        for (d in hist) v += (d - mean) * (d - mean)
        return (x - mean) / max(sqrt(v / hist.size), sdFloor)
    }

    fun add(x: Double) {
        hist.addLast(x)
        if (hist.size > keep) hist.removeFirst()
    }
}

/** Turns window-averaged screen features into one score, comparable to the audio score. */
class VisualScorer(private val game: Game) {
    private val bm = Baseline(sdFloor = 1.0)
    private val bf = Baseline(sdFloor = 0.7)
    private val br = Baseline(sdFloor = 0.01)
    private val bh = Baseline(sdFloor = 1.0)
    private val recent = ArrayDeque<Double>()

    fun score(f: FrameFeatures): Double {
        val parts = ArrayList<Double>()
        parts.add(game.wMotion * max(0.0, bm.z(f.motion)))
        parts.add(game.wFlash * max(0.0, bf.z(f.flash)))
        parts.add(game.wRed * max(0.0, br.z(f.red)))
        if (game.wHud > 0) parts.add(game.wHud * max(0.0, bh.z(f.hud)))
        bm.add(f.motion); bf.add(f.flash); br.add(f.red); bh.add(f.hud)
        parts.sortDescending()
        val top = if (parts.size >= 2) (parts[0] + parts[1]) / 2 * 1.25 else parts[0]
        recent.addLast(top)
        if (recent.size > 3) recent.removeFirst()
        return min(recent.average(), 12.0)   // a huge flash must not drown out everything else
    }
}

object Fuse {
    /** Audio and screen agree = strong. Screen alone counts a bit less, so loading screens and map swipes don't clip. */
    fun score(audio: Double, visual: Double): Double {
        val v = visual * 0.75
        return max(audio, v) + 0.5 * max(0.0, min(audio, v))
    }
}
