package app.streamclipper

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import java.io.File

object Store {
    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("clipper", Context.MODE_PRIVATE)

    private fun outputTree(ctx: Context): Uri? =
        prefs(ctx).getString("outTree", null)?.let { Uri.parse(it) }

    /** Human-readable save location for the UI and log. */
    fun where(ctx: Context): String {
        val tree = outputTree(ctx) ?: return "Movies/StreamClipper (default)"
        val id = try {
            DocumentsContract.getTreeDocumentId(tree)
        } catch (_: Exception) {
            return "chosen folder"
        }
        val vol = id.substringBefore(':', "")
        val path = id.substringAfter(':', id)
        return if (vol == "primary") "Internal storage/$path" else "SD card/$path"
    }

    /** Saves a video to the folder the user picked, or Movies/StreamClipper by default. */
    fun saveVideo(ctx: Context, f: File, displayName: String): Uri? {
        val tree = outputTree(ctx)
        if (tree != null) {
            try {
                val docId = DocumentsContract.getTreeDocumentId(tree)
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
                val out = DocumentsContract.createDocument(ctx.contentResolver, parent, "video/mp4", displayName)
                if (out != null) {
                    ctx.contentResolver.openOutputStream(out)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                    return out
                }
            } catch (e: Exception) {
                LogBus.post("Chosen folder failed (${e.message?.take(60)}), saving to Movies/StreamClipper instead")
            }
        }
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/StreamClipper")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val r = ctx.contentResolver
        val uri = r.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        r.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        v.clear()
        v.put(MediaStore.Video.Media.IS_PENDING, 0)
        r.update(uri, v, null, null)
        return uri
    }
}

/** Tiny in-process log shared by the service (writer) and the activity (reader). */
object LogBus {
    private val lines = ArrayList<String>()
    private val main = Handler(Looper.getMainLooper())
    @Volatile var listener: (() -> Unit)? = null

    @Synchronized
    fun post(line: String) {
        lines += line
        if (lines.size > 300) lines.removeAt(0)
        main.post { listener?.invoke() }
    }

    @Synchronized
    fun clear() {
        lines.clear()
        main.post { listener?.invoke() }
    }

    @Synchronized
    fun last(): String? = lines.lastOrNull()

    @Synchronized
    fun text(): String = lines.joinToString("\n")
}
