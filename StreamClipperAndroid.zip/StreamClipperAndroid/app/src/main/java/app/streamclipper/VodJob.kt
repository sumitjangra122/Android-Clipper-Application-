package app.streamclipper

import android.content.Context
import android.net.Uri
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Clips a recorded video: a URL (YouTube video, Kick/Twitch VOD, ...) or a file from the phone.
 * Scans the audio and the screen of the whole video, finds the best events (a fight, a clutch, a funny moment)
 * with their real start and end, and cuts each one straight from the source with an accurate start.
 */
class VodJob(
    private val ctx: Context,
    val id: Int,
    private val source: String,
    private val isUri: Boolean,
    private val range: Pair<Double, Double>?,   // manual start/end in seconds, or null for auto highlights
    private val cfg: Config,
    private val submit: (File, () -> Unit) -> Unit,
    private val log: (String) -> Unit,
) {
    @Volatile private var cancelled = false
    @Volatile private var proc: Process? = null
    private val outstanding = AtomicInteger(0)
    private val monitor = Object()

    companion object {
        private const val VW = 96
        private const val VH = 54
    }

    fun cancel() {
        cancelled = true
        proc?.destroy()
        Bins.cancel("vod$id")
    }

    private fun editDone() {
        outstanding.decrementAndGet()
        synchronized(monitor) { monitor.notifyAll() }
    }

    /** The source must stay on disk until every edit that reads from it has finished. */
    private fun waitForEdits() {
        synchronized(monitor) {
            while (outstanding.get() > 0 && !cancelled) monitor.wait(2000)
        }
    }

    private fun queueEdit(work: File, file: File, ss: Double, len: Double, name: String, what: String) {
        outstanding.incrementAndGet()
        submit(File(work, "unused_$name")) {
            try {
                Editor.process(ctx, file, ss, len, source, cfg, name, log)
            } catch (e: Throwable) {
                log("$what edit failed: ${e.message?.take(120)}")
            } finally {
                editDone()
            }
        }
    }

    fun run() {
        if (!License.active(ctx)) {
            log("Access has ended. Enter a new key in the app to continue.")
            return
        }
        val work = File(ctx.cacheDir, "vod$id").apply { deleteRecursively(); mkdirs() }
        try {
            if (range != null) {
                runManual(work, range)
                return
            }
            val file = if (isUri) copyLocal(work) else Bins.download(source, work, "vod$id", log, null, cfg.srcMax)
            if (cancelled) return
            val metaDur = duration(file)
            log("Video ready: ${file.length() / 1_000_000} MB, length ${if (metaDur > 0) mmss(metaDur) else "unknown"}")
            if (metaDur <= 0) log("ffmpeg says: $probeInfo")

            log("Scanning the audio…")
            val audio = audioScores(file)
            if (cancelled) return
            if (audio.size < 10) {
                log("Couldn't read any audio from this video, so highlights can't be found")
                return
            }
            val dur = max(metaDur, audio.size * 0.5)
            val visual = if (cfg.watchScreen) {
                log("Scanning the screen for action…")
                screenScores(file, audio.size)
            } else DoubleArray(audio.size)
            if (cancelled) return

            val scores = DoubleArray(audio.size) { Fuse.score(audio[it], visual[it]) }
            var events = findEvents(scores, cfg.thr)
            if (events.isEmpty()) {
                log("Nothing above the sensitivity level, taking the strongest moments")
                events = findEvents(scores, cfg.thr * 0.6)
            }
            val picks = choose(events)
            if (picks.isEmpty()) {
                log("No clear highlights found. Try a higher sensitivity.")
                return
            }
            log("Found ${picks.size} highlight${if (picks.size > 1) "s" else ""}, editing…")

            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            picks.forEachIndexed { k, e ->
                if (cancelled) return@forEachIndexed
                val span = ClipWindow.compute(e, cfg.clipLen)
                var s = max(0.0, span.start)
                var en = min(dur, span.end)
                if (cfg.clipLen > 0 && en - s < cfg.clipLen) {
                    if (s == 0.0) en = min(dur, cfg.clipLen.toDouble()) else s = max(0.0, en - cfg.clipLen)
                }
                if (en - s < 5) return@forEachIndexed
                log("Clip ${k + 1}/${picks.size}: ${mmss(s)} to ${mmss(en)} (action ${mmss(e.onset)} to ${mmss(e.end)})")
                queueEdit(work, file, s, en - s, "video${id}_${stamp}_${k + 1}", "Clip ${k + 1}")
            }
            waitForEdits()
        } finally {
            work.deleteRecursively()
        }
    }

    private fun mmss(t: Double): String {
        val s = t.toInt()
        return if (s >= 3600) "%d:%02d:%02d".format(Locale.US, s / 3600, (s / 60) % 60, s % 60)
        else "%d:%02d".format(Locale.US, s / 60, s % 60)
    }

    /** Cuts exactly the time range the user typed in. */
    private fun runManual(work: File, r: Pair<Double, Double>) {
        val s = r.first
        val e = r.second
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = "video${id}_${stamp}_manual"
        if (!isUri) {
            log("Downloading just ${mmss(s)} to ${mmss(e)}…")
            try {
                val f = Bins.download(source, work, "vod$id", log, "*%.2f-%.2f".format(Locale.US, s, e), cfg.srcMax)
                if (cancelled) return
                log("Clip ${mmss(s)} to ${mmss(e)} ready, editing to 9:16…")
                queueEdit(work, f, 0.0, e - s, name, "Manual clip")
                waitForEdits()
                return
            } catch (ex: Exception) {
                if (cancelled) return
                log("Section download failed (${ex.message?.take(60)}), downloading the full video instead")
                work.listFiles()?.forEach { it.delete() }
            }
        }
        val file = if (isUri) copyLocal(work) else Bins.download(source, work, "vod$id", log, null, cfg.srcMax)
        if (cancelled) return
        val metaDur = duration(file)
        val end = if (metaDur > 0) min(e, metaDur) else e
        if (end - s < 1) {
            log("That range is outside the video (length ${if (metaDur > 0) mmss(metaDur) else "unknown"})")
            return
        }
        log("Clip ${mmss(s)} to ${mmss(end)} ready, editing to 9:16…")
        queueEdit(work, file, s, end - s, name, "Manual clip")
        waitForEdits()
    }

    private fun copyLocal(dir: File): File {
        val out = File(dir, "video.mp4")
        log("Copying the video from your phone…")
        val ins = ctx.contentResolver.openInputStream(Uri.parse(source))
            ?: throw IllegalStateException("can't open that video")
        ins.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        return out
    }

    private var probeInfo = ""

    private fun duration(file: File): Double {
        val out = Bins.run(listOf("-hide_banner", "-i", file.absolutePath)).second
        probeInfo = out.lines().filter { it.isNotBlank() }.takeLast(2).joinToString(" | ").take(160)
        val m = Regex("Duration: (\\d+):(\\d+):(\\d+(?:\\.\\d+)?)").find(out) ?: return 0.0
        return m.groupValues[1].toInt() * 3600.0 + m.groupValues[2].toInt() * 60.0 +
            m.groupValues[3].toDouble()
    }

    // ---- analysis -----------------------------------------------------------------------------

    /** Audio score per 0.5 s: how far above this video's normal loudness. */
    private fun audioScores(file: File): DoubleArray {
        val p = Bins.stream(
            listOf("-loglevel", "error", "-i", file.absolutePath, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-")
        )
        proc = p
        val out = ArrayList<Double>()
        val base = Baseline(sdFloor = 1.5)
        val recent = ArrayDeque<Double>()
        val inp = p.inputStream.buffered(1 shl 16)
        val chunk = ByteArray(16000) // 8000 samples = 0.5 s
        try {
            while (!cancelled) {
                var off = 0
                while (off < chunk.size) {
                    val r = inp.read(chunk, off, chunk.size - off)
                    if (r < 0) break
                    off += r
                }
                if (off < chunk.size) break
                var sum = 0.0
                var i = 0
                while (i < chunk.size) {
                    val s = (chunk[i + 1].toInt() shl 8) or (chunk[i].toInt() and 0xFF)
                    val v = s / 32768.0
                    sum += v * v
                    i += 2
                }
                val db = max(20 * log10(sqrt(sum / 8000) + 1e-9), -90.0)
                recent.addLast(base.z(db))
                if (recent.size > 3) recent.removeFirst()
                base.add(db)
                out.add(recent.average())
                if (out.size % 2400 == 0) log("Scanned ${out.size / 120} min…")
            }
        } finally {
            p.destroy()
            proc = null
        }
        return out.toDoubleArray()
    }

    /**
     * Screen score per 0.5 s. Only keyframes are decoded (a few per ten seconds), which keeps a long
     * video cheap and the phone cool; the audio supplies the fine timing.
     */
    private fun screenScores(file: File, windows: Int): DoubleArray {
        val out = DoubleArray(windows)
        val err = File.createTempFile("vis_err_", ".txt", ctx.cacheDir)
        val feats = ArrayList<FrameFeatures>()
        val game = Game.of(cfg.game)
        val vf = VisualFeatures(VW, VH, game)
        val scorer = VisualScorer(game)
        val scores = ArrayList<Double>()
        try {
            val p = Bins.streamWithErr(
                listOf(
                    "-hide_banner", "-nostats", "-skip_frame", "nokey", "-skip_loop_filter", "all", "-threads", "2",
                    "-i", file.absolutePath, "-an",
                    "-vf", "select='eq(pict_type,I)',scale=$VW:$VH,format=rgb24,showinfo",
                    "-fps_mode", "passthrough", "-f", "rawvideo", "pipe:1",
                ),
                err
            )
            proc = p
            val inp = p.inputStream.buffered(1 shl 16)
            val fsz = VW * VH * 3
            val buf = ByteArray(fsz)
            try {
                while (!cancelled) {
                    var off = 0
                    while (off < fsz) {
                        val r = inp.read(buf, off, fsz - off)
                        if (r < 0) break
                        off += r
                    }
                    if (off < fsz) break
                    val f = vf.feed(buf, 0)
                    feats.add(f)
                    scores.add(scorer.score(f))
                }
            } finally {
                p.destroy()
                proc = null
            }
            val pts = Regex("pts_time:([0-9.]+)").findAll(err.readText())
                .mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()
            // each keyframe's score covers the stretch since the previous keyframe
            for (i in 1 until min(scores.size, pts.size)) {
                val w0 = (pts[i - 1] / 0.5).toInt().coerceIn(0, windows)
                val w1 = (pts[i] / 0.5).toInt().coerceIn(0, windows)
                for (w in w0 until w1) out[w] = max(out[w], scores[i])
            }
        } finally {
            err.delete()
        }
        return out
    }

    private fun findEvents(scores: DoubleArray, thr: Double): List<Event> {
        val det = EventDetector({ thr })
        val events = ArrayList<Event>()
        for (i in scores.indices) det.feed(i * 0.5, scores[i])?.let { events.add(it) }
        det.finish()?.let { events.add(it) }
        return events
    }

    /** Best events first, at least 20 s apart, up to the max clips setting, then back in time order. */
    private fun choose(events: List<Event>): List<Event> {
        val chosen = ArrayList<Event>()
        for (e in events.sortedByDescending { it.peakScore }) {
            if (chosen.size >= cfg.maxClips) break
            if (chosen.none { abs(it.peak - e.peak) < 20 }) chosen.add(e)
        }
        return chosen.sortedBy { it.onset }
    }
}
