package app.streamclipper

import android.content.Context
import android.net.Uri
import com.yausername.youtubedl_android.YoutubeDL
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Clips a recorded video: a URL (YouTube video, Kick/Twitch VOD, ...) or a file from the phone.
 * Scans the whole audio track, ranks loud moments against the video's own baseline, then
 * cuts and edits the best ones (up to cfg.maxClips).
 */
class VodJob(
    private val ctx: Context,
    val id: Int,
    private val source: String,
    private val isUri: Boolean,
    private val cfg: Config,
    private val submit: (File, () -> Unit) -> Unit,
    private val log: (String) -> Unit,
) {
    @Volatile private var cancelled = false
    @Volatile private var proc: Process? = null

    fun cancel() {
        cancelled = true
        proc?.destroy()
        try {
            YoutubeDL.getInstance().destroyProcessById("vod$id")
        } catch (_: Throwable) {
        }
    }

    fun run() {
        val work = File(ctx.cacheDir, "vod$id").apply { deleteRecursively(); mkdirs() }
        try {
            val file = if (isUri) copyLocal(work) else Bins.download(source, work, "vod$id", log)
            if (cancelled) return
            val dur = duration(file)
            if (dur < 20) {
                log("Video is too short to clip")
                return
            }
            log("Scanning audio (${(dur / 60).toInt()} min)…")
            val picks = findMoments(file)
            if (cancelled) return
            if (picks.isEmpty()) {
                log("No clear highlights found. Try a higher sensitivity.")
                return
            }
            log("Found ${picks.size} highlight moments, cutting…")

            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            picks.forEachIndexed { k, t ->
                if (cancelled) return@forEachIndexed
                val start = max(0.0, t - cfg.pre)
                val end = min(dur, t + cfg.post)
                val raw = File(ctx.cacheDir, "raw_v${id}_${k + 1}_$stamp.mp4")
                if (!cut(file, start, end - start, raw)) {
                    log("Clip ${k + 1}: cutting failed")
                    return@forEachIndexed
                }
                val name = "video${id}_${stamp}_${k + 1}"
                log("Clip ${k + 1}/${picks.size} at ${mmss(t)} cut, editing to 9:16…")
                submit(raw) {
                    try {
                        Editor.process(ctx, raw, source, cfg, name, log)
                    } catch (e: Throwable) {
                        log("Clip ${k + 1} edit failed: ${e.message?.take(120)}")
                    }
                }
            }
        } finally {
            work.deleteRecursively()
        }
    }

    private fun mmss(t: Double): String {
        val s = t.toInt()
        return "%d:%02d".format(Locale.US, s / 60, s % 60)
    }

    private fun copyLocal(dir: File): File {
        val out = File(dir, "video.mp4")
        log("Copying the video from your phone…")
        val ins = ctx.contentResolver.openInputStream(Uri.parse(source))
            ?: throw IllegalStateException("can't open that video")
        ins.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        return out
    }

    private fun duration(file: File): Double {
        val out = Bins.run(listOf("-hide_banner", "-i", file.absolutePath)).second
        val m = Regex("Duration: (\\d+):(\\d+):(\\d+(?:\\.\\d+)?)").find(out) ?: return 0.0
        return m.groupValues[1].toInt() * 3600.0 + m.groupValues[2].toInt() * 60.0 +
            m.groupValues[3].toDouble()
    }

    /** Streams the audio through ffmpeg in 0.5 s windows and returns the best moments (seconds). */
    private fun findMoments(file: File): List<Double> {
        val p = Bins.stream(
            listOf("-loglevel", "error", "-i", file.absolutePath, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-")
        )
        proc = p
        val dbs = ArrayList<Double>()
        val inp = p.inputStream.buffered(1 shl 16)
        val chunk = ByteArray(16000) // 8000 samples = 0.5 s
        try {
            while (!cancelled) {
                var off = 0
                while (off < chunk.size) {
                    val r = inp.read(chunk, off, chunk.size - off)
                    if (r < 0) break
                    off += r
                }
                if (off < chunk.size) break
                var sum = 0.0
                var i = 0
                while (i < chunk.size) {
                    val s = (chunk[i + 1].toInt() shl 8) or (chunk[i].toInt() and 0xFF)
                    val v = s / 32768.0
                    sum += v * v
                    i += 2
                }
                dbs += max(20 * log10(sqrt(sum / 8000) + 1e-9), -90.0)
                if (dbs.size % 2400 == 0) log("Scanned ${dbs.size / 120} min…")
            }
        } finally {
            p.destroy()
            proc = null
        }
        if (cancelled) return emptyList()

        val n = dbs.size
        val scores = DoubleArray(n)
        val hist = ArrayDeque<Double>()
        val recent = ArrayDeque<Double>()
        for (i in 0 until n) {
            val db = dbs[i]
            var z = 0.0
            if (hist.size >= 20) {
                val mean = hist.average()
                var v = 0.0
                for (x in hist) v += (x - mean) * (x - mean)
                z = (db - mean) / max(sqrt(v / hist.size), 1.5)
            }
            recent.addLast(z)
            if (recent.size > 3) recent.removeFirst()
            scores[i] = recent.average()
            hist.addLast(db)
            if (hist.size > 240) hist.removeFirst()
        }

        val order = (0 until n).sortedByDescending { scores[it] }
        fun pick(minScore: Double, limit: Int): List<Int> {
            val chosen = ArrayList<Int>()
            for (i in order) {
                if (scores[i] < minScore || chosen.size >= limit) break
                if (chosen.none { Math.abs(it - i) * 0.5 <= cfg.cooldown }) chosen += i
            }
            return chosen
        }
        var chosen = pick(cfg.thr, cfg.maxClips)
        if (chosen.isEmpty()) {
            log("Nothing above the sensitivity level, taking the loudest moments")
            chosen = pick(0.8, 3)
        }
        return chosen.sorted().map { it * 0.5 }
    }

    private fun cut(src: File, start: Double, len: Double, out: File): Boolean {
        val s = "%.2f".format(Locale.US, start)
        val l = "%.2f".format(Locale.US, len)
        var r = Bins.run(
            listOf(
                "-loglevel", "error", "-y", "-ss", s, "-i", src.absolutePath, "-t", l,
                "-c", "copy", "-avoid_negative_ts", "make_zero", "-movflags", "+faststart", out.absolutePath,
            )
        )
        if (r.first == 0 && out.exists() && out.length() > 0) return true
        val v = if (Bins.encoder == "libx264")
            listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "20")
        else
            listOf("-c:v", "mpeg4", "-q:v", "3")
        r = Bins.run(
            listOf("-loglevel", "error", "-y", "-ss", s, "-i", src.absolutePath, "-t", l) +
                v + listOf("-c:a", "aac", "-movflags", "+faststart", out.absolutePath)
        )
        return r.first == 0 && out.exists() && out.length() > 0
    }
}
