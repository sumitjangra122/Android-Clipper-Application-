package app.streamclipper

import android.content.Context
import android.graphics.BitmapFactory
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import java.util.Locale
import kotlin.math.max

/**
 * Watches the clip once (one ffmpeg pass) and works out, with no user input:
 *  - which scene uses which layout (facecam + gameplay, full-screen cam, or gameplay only),
 *    so broadcast streams that cut between cams and banners are framed correctly each time
 *  - where the action is (horizontal centre of motion, facecam areas excluded)
 */
object AutoLayout {
    class Result(val segs: List<Scene>, val motionX: Double, val cacheFace: Box?)

    private const val PW = 96

    fun loadFace(ctx: Context, key: String): Box? {
        val p = Store.prefs(ctx).getString(key, null)?.split(",") ?: return null
        if (p.size != 4) return null
        return try {
            Box(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat())
        } catch (_: NumberFormatException) {
            null
        }
    }

    fun saveFace(ctx: Context, key: String, r: Box) {
        Store.prefs(ctx).edit().putString(key, "${r.l},${r.t},${r.r},${r.b}").apply()
    }

    fun analyse(ctx: Context, clip: File, vw: Int, vh: Int, dur: Double, cached: Box?, log: (String) -> Unit): Result {
        val step = if (dur <= 40) 1.0 else 1.5
        val ph = (PW.toDouble() * vh / vw).toInt().coerceAtLeast(2) / 2 * 2
        val dir = File(ctx.cacheDir, "an_${System.nanoTime()}").apply { mkdirs() }
        try {
            // One pass: face-detection frames, hard-cut times, and tiny gray frames for motion.
            val fg = "[0:v]split=3[a][b][c];" +
                "[a]fps=${String.format(Locale.US, "%.4f", 1.0 / step)},scale=960:-2[o1];" +
                "[b]scale=320:-2,select='gt(scene,0.35)',showinfo[o2];" +
                "[c]fps=4,scale=$PW:$ph,format=gray[o3]"
            val (raw, err) = Bins.bytesWithErr(
                listOf(
                    "-hide_banner", "-nostats", "-y", "-i", clip.absolutePath, "-filter_complex", fg,
                    "-map", "[o1]", "-q:v", "3", File(dir, "f_%03d.jpg").absolutePath,
                    "-map", "[o2]", "-f", "null", "/dev/null",
                    "-map", "[o3]", "-f", "rawvideo", "-pix_fmt", "gray", "pipe:1",
                )
            )
            val cuts = Regex("pts_time:([0-9.]+)").findAll(err)
                .mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()
            val files = dir.listFiles { f -> f.name.endsWith(".jpg") }?.sortedBy { it.name } ?: emptyList()
            if (files.isEmpty()) {
                log("Layout analysis failed: ${err.lines().lastOrNull { it.isNotBlank() }?.take(90) ?: "no output"}")
            }

            // Largest face in each sampled frame.
            val faces = ArrayList<Box?>()
            val detector = FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .setMinFaceSize(0.04f)
                    .build()
            )
            try {
                for (f in files) {
                    val bmp = BitmapFactory.decodeFile(f.absolutePath)
                    if (bmp == null) {
                        faces.add(null)
                        continue
                    }
                    val found = try {
                        Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
                    } catch (_: Exception) {
                        emptyList()
                    }
                    val w = bmp.width.toFloat()
                    val h = bmp.height.toFloat()
                    faces.add(
                        found.map { fc ->
                            val bb = fc.boundingBox
                            Box(
                                (bb.left / w).coerceIn(0f, 1f), (bb.top / h).coerceIn(0f, 1f),
                                (bb.right / w).coerceIn(0f, 1f), (bb.bottom / h).coerceIn(0f, 1f),
                            )
                        }.maxByOrNull { it.area }
                    )
                    bmp.recycle()
                }
            } finally {
                detector.close()
            }

            var segs = Segmenter.build(step, faces, dur, cuts, cached)
            var usedCache = false
            if (segs.none { it.kind != Kind.BLUR } && cached != null) {
                // No face anywhere in this clip: fall back to where this channel's facecam was before.
                segs = listOf(Scene(0.0, dur, Kind.STACK, cached))
                usedCache = true
            }

            // Where is the action? Skip pairs that straddle a hard cut, mask out facecam areas.
            val fsz = PW * ph
            val frames = raw.size / fsz
            val acc = DoubleArray(fsz)
            var pairs = 0
            val diff = IntArray(fsz)
            for (i in 0 until frames - 1) {
                var sum = 0L
                for (p in 0 until fsz) {
                    val d = Math.abs((raw[i * fsz + p].toInt() and 0xFF) - (raw[(i + 1) * fsz + p].toInt() and 0xFF))
                    diff[p] = d
                    sum += d
                }
                if (sum.toDouble() / fsz > 35.0) continue // a cut, not motion
                for (p in 0 until fsz) acc[p] += diff[p].toDouble()
                pairs++
            }
            for (s in segs) {
                val f = s.face ?: continue
                val ex = f.w * 1.7f
                val ey = f.h * 1.7f
                val x0 = ((f.cx - ex) * PW).toInt().coerceIn(0, PW)
                val x1 = ((f.cx + ex) * PW).toInt().coerceIn(0, PW)
                val y0 = ((f.cy - ey) * ph).toInt().coerceIn(0, ph)
                val y1 = ((f.cy + ey) * ph).toInt().coerceIn(0, ph)
                for (y in y0 until y1) for (x in x0 until x1) acc[y * PW + x] = 0.0
            }
            var total = 0.0
            var weighted = 0.0
            for (x in 0 until PW) {
                var col = 0.0
                for (y in 0 until ph) col += acc[y * PW + x]
                total += col
                weighted += col * x
            }
            val motionX = if (total < max(pairs, 1) * 30.0) 0.5 else weighted / total / (PW - 1)

            val cacheFace = if (usedCache) null
            else segs.filter { it.kind == Kind.STACK }.maxByOrNull { it.len }?.face
            return Result(segs, motionX, cacheFace)
        } finally {
            dir.deleteRecursively()
        }
    }
}
