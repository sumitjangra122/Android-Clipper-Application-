package app.streamclipper

import android.content.Context
import android.graphics.BitmapFactory
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import java.util.Locale
import kotlin.math.max

/**
 * Watches the clip once (one ffmpeg pass) and works out, with no user input:
 *  - which scene uses which layout (facecam + gameplay, full-screen cam, or gameplay only),
 *    so broadcast streams that cut between cams and banners are framed correctly each time
 *  - where the action is (horizontal centre of motion, facecam areas excluded)
 */
object AutoLayout {
    class Result(val segs: List<Scene>, val motionX: Double, val cacheFace: Box?)

    private const val PW = 96

    /** Preference key for the facecam area a user marked for this stream or video. */
    fun regionKey(source: String) = "region_" + source.trim().lowercase().hashCode()

    fun loadRegion(ctx: Context, source: String): Box? {
        val p = Store.prefs(ctx).getString(regionKey(source), null)?.split(",") ?: return null
        if (p.size != 4) return null
        return try {
            Box(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat(), true)
        } catch (_: NumberFormatException) {
            null
        }
    }

    fun saveRegion(ctx: Context, source: String, r: Box?) {
        val e = Store.prefs(ctx).edit()
        if (r == null) e.remove(regionKey(source)) else e.putString(regionKey(source), "${r.l},${r.t},${r.r},${r.b}")
        e.apply()
    }

    fun loadFace(ctx: Context, key: String): Box? {
        val p = Store.prefs(ctx).getString(key, null)?.split(",") ?: return null
        if (p.size != 4) return null
        return try {
            Box(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat())
        } catch (_: NumberFormatException) {
            null
        }
    }

    fun saveFace(ctx: Context, key: String, r: Box) {
        Store.prefs(ctx).edit().putString(key, "${r.l},${r.t},${r.r},${r.b}").apply()
    }

    fun analyse(ctx: Context, clip: File, vw: Int, vh: Int, dur: Double, cached: Box?, region: Box?, useCam: Boolean, log: (String) -> Unit): Result {
        val step = if (dur <= 40) 1.0 else 1.5
        val ph = (PW.toDouble() * vh / vw).toInt().coerceAtLeast(2) / 2 * 2
        val dir = File(ctx.cacheDir, "an_${System.nanoTime()}").apply { mkdirs() }
        try {
            // One pass: face-detection frames, hard-cut times, and tiny gray frames for motion.
            val rate = String.format(Locale.US, "%.4f", 1.0 / step)
            var fg = "[0:v]split=" + (if (region != null) 4 else 3) + "[a][b][c]" + (if (region != null) "[d]" else "") + ";" +
                "[a]fps=$rate,scale=960:-2[o1];" +
                "[b]scale=320:-2,select='gt(scene,0.35)',showinfo[o2];" +
                "[c]fps=4,scale=$PW:$ph,format=gray[o3]"
            val args = arrayListOf("-hide_banner", "-nostats", "-y", "-i", clip.absolutePath)
            if (region != null) {
                // The marked facecam area, cut out of every sampled frame, so we only look for a face there.
                val rw = max(2, (region.w * vw).toInt() / 2 * 2)
                val rh = max(2, (region.h * vh).toInt() / 2 * 2)
                val rx = (region.l * vw).toInt().coerceIn(0, max(vw - rw, 0))
                val ry = (region.t * vh).toInt().coerceIn(0, max(vh - rh, 0))
                fg += ";[d]fps=$rate,crop=$rw:$rh:$rx:$ry,scale=480:-2[o4]"
            }
            args += listOf("-filter_complex", fg)
            args += listOf("-map", "[o1]", "-q:v", "3", File(dir, "f_%03d.jpg").absolutePath)
            if (region != null) args += listOf("-map", "[o4]", "-q:v", "3", File(dir, "r_%03d.jpg").absolutePath)
            args += listOf("-map", "[o2]", "-f", "null", "/dev/null")
            args += listOf("-map", "[o3]", "-f", "rawvideo", "-pix_fmt", "gray", "pipe:1")
            val (raw, err) = Bins.bytesWithErr(args)
            val cuts = Regex("pts_time:([0-9.]+)").findAll(err)
                .mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()
            val files = dir.listFiles { f -> f.name.startsWith("f_") && f.name.endsWith(".jpg") }?.sortedBy { it.name } ?: emptyList()
            val rfiles = dir.listFiles { f -> f.name.startsWith("r_") && f.name.endsWith(".jpg") }?.sortedBy { it.name } ?: emptyList()
            if (files.isEmpty()) {
                log("Layout analysis failed: ${err.lines().lastOrNull { it.isNotBlank() }?.take(90) ?: "no output"}")
            }

            // One face per sampled frame. Automatic mode picks the most facecam-like face (near an edge,
            // not a mid-screen game character). With a marked area we only look inside that area.
            val faces = ArrayList<Box?>()
            val subjects = ArrayList<Box?>()   // the biggest face in each frame, for videos without a facecam
            val detector = FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .setMinFaceSize(0.04f)
                    .build()
            )
            try {
                for ((idx, f) in files.withIndex()) {
                    val bmp = BitmapFactory.decodeFile(f.absolutePath)
                    if (bmp == null) {
                        faces.add(null)
                        continue
                    }
                    val found = try {
                        Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
                    } catch (_: Exception) {
                        emptyList()
                    }
                    val w = bmp.width.toFloat()
                    val h = bmp.height.toFloat()
                    val boxes = found.map { fc ->
                        val bb = fc.boundingBox
                        Box(
                            (bb.left / w).coerceIn(0f, 1f), (bb.top / h).coerceIn(0f, 1f),
                            (bb.right / w).coerceIn(0f, 1f), (bb.bottom / h).coerceIn(0f, 1f),
                        )
                    }
                    bmp.recycle()
                    subjects.add(boxes.maxByOrNull { it.area })
                    if (region == null) {
                        faces.add(boxes.filter { Segmenter.accepts(it) }.maxByOrNull { Segmenter.score(it, cached) })
                    } else {
                        val big = boxes.filter { it.w > Segmenter.BIG_FACE }.maxByOrNull { it.area }
                        var inRegion = false
                        if (big == null && idx < rfiles.size) {
                            val rb = BitmapFactory.decodeFile(rfiles[idx].absolutePath)
                            if (rb != null) {
                                val rf = try {
                                    Tasks.await(detector.process(InputImage.fromBitmap(rb, 0)))
                                } catch (_: Exception) {
                                    emptyList()
                                }
                                inRegion = rf.any { it.boundingBox.width() >= 0.12f * rb.width }
                                rb.recycle()
                            }
                        }
                        faces.add(big ?: if (inRegion) region else null)
                    }
                }
            } finally {
                detector.close()
            }

            var segs = Segmenter.build(step, faces, dur, cuts, cached, maxGap = if (region != null) 6 else 3)
            var usedCache = false
            if (region != null && segs.none { it.kind != Kind.BLUR }) {
                // The user marked a cam but no face was found in this clip: trust the marked area.
                segs = listOf(Scene(0.0, dur, Kind.STACK, region))
            } else if (region == null && segs.none { it.kind != Kind.BLUR } && cached != null) {
                // No face anywhere in this clip: fall back to where this channel's facecam was before.
                segs = listOf(Scene(0.0, dur, Kind.STACK, cached))
                usedCache = true
            }

            if (!useCam) segs = listOf(Scene(0.0, dur, Kind.BLUR, null))   // no facecam in this video

            // Where is the action? Skip pairs that straddle a hard cut, mask out facecam areas.
            val fsz = PW * ph
            val frames = raw.size / fsz
            val acc = DoubleArray(fsz)
            var pairs = 0
            val diff = IntArray(fsz)
            for (i in 0 until frames - 1) {
                var sum = 0L
                for (p in 0 until fsz) {
                    val d = Math.abs((raw[i * fsz + p].toInt() and 0xFF) - (raw[(i + 1) * fsz + p].toInt() and 0xFF))
                    diff[p] = d
                    sum += d
                }
                if (sum.toDouble() / fsz > 35.0) continue // a cut, not motion
                for (p in 0 until fsz) acc[p] += diff[p].toDouble()
                pairs++
            }
            for (s in segs) {
                val f = s.face ?: continue
                val ex = f.w * 1.7f
                val ey = f.h * 1.7f
                val x0 = ((f.cx - ex) * PW).toInt().coerceIn(0, PW)
                val x1 = ((f.cx + ex) * PW).toInt().coerceIn(0, PW)
                val y0 = ((f.cy - ey) * ph).toInt().coerceIn(0, ph)
                val y1 = ((f.cy + ey) * ph).toInt().coerceIn(0, ph)
                for (y in y0 until y1) for (x in x0 until x1) acc[y * PW + x] = 0.0
            }
            var total = 0.0
            var weighted = 0.0
            for (x in 0 until PW) {
                var col = 0.0
                for (y in 0 until ph) col += acc[y * PW + x]
                total += col
                weighted += col * x
            }
            val motionX = if (total < max(pairs, 1) * 30.0) 0.5 else weighted / total / (PW - 1)

            // Without a facecam, centre the crop on the people (faces) if we found them, else on the motion.
            val seen = subjects.filterNotNull()
            val subjectX = if (!useCam && seen.size >= max(2, subjects.size / 3))
                seen.map { it.cx.toDouble() }.average() else null

            val cacheFace = if (usedCache || region != null || !useCam) null
            else segs.filter { it.kind == Kind.STACK }.maxByOrNull { it.len }?.face
            return Result(segs, subjectX ?: motionX, cacheFace)
        } finally {
            dir.deleteRecursively()
        }
    }
}
