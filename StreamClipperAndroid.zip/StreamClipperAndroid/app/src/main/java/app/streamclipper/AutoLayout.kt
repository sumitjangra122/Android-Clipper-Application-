package app.streamclipper

import android.content.Context
import android.graphics.BitmapFactory
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import java.util.Locale
import kotlin.math.max

/**
 * Watches the clip once (one ffmpeg pass) and works out, with no user input:
 *  - which scene uses which layout (facecam + gameplay, full-screen cam, or gameplay only),
 *    so broadcast streams that cut between cams and banners are framed correctly each time
 *  - where the action is (horizontal centre of motion, facecam areas excluded)
 */
object AutoLayout {
    class Result(val segs: List<Scene>, val motionX: Double, val cacheFace: Box?)

    private const val PW = 96

    /** Preference key for the facecam area a user marked for this stream or video. */
    fun regionKey(source: String) = "region_" + source.trim().lowercase().hashCode()

    fun loadRegion(ctx: Context, source: String): Box? {
        val p = Store.prefs(ctx).getString(regionKey(source), null)?.split(",") ?: return null
        if (p.size != 4) return null
        return try {
            Box(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat(), true)
        } catch (_: NumberFormatException) {
            null
        }
    }

    fun saveRegion(ctx: Context, source: String, r: Box?) {
        val e = Store.prefs(ctx).edit()
        if (r == null) e.remove(regionKey(source)) else e.putString(regionKey(source), "${r.l},${r.t},${r.r},${r.b}")
        e.apply()
    }

    fun loadFace(ctx: Context, key: String): Box? {
        val p = Store.prefs(ctx).getString(key, null)?.split(",") ?: return null
        if (p.size != 4) return null
        return try {
            Box(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat())
        } catch (_: NumberFormatException) {
            null
        }
    }

    fun saveFace(ctx: Context, key: String, r: Box) {
        Store.prefs(ctx).edit().putString(key, "${r.l},${r.t},${r.r},${r.b}").apply()
    }

    fun analyse(ctx: Context, clip: File, ss: Double, dur: Double, vw: Int, vh: Int, cached: Box?, region: Box?, useCam: Boolean, log: (String) -> Unit): Result {
        val step = if (dur <= 40) 1.0 else 1.5
        val ph = (PW.toDouble() * vh / vw).toInt().coerceAtLeast(2) / 2 * 2
        val dir = File(ctx.cacheDir, "an_${System.nanoTime()}").apply { mkdirs() }
        try {
            // One pass: face-detection frames, hard-cut times, and tiny gray frames for motion.
            val rate = String.format(Locale.US, "%.4f", 1.0 / step)
            val fg = "[0:v]split=3[a][b][c];" +
                "[a]fps=$rate,scale=960:-2[o1];" +
                "[b]scale=320:-2,select='gt(scene,0.5)',showinfo[o2];" +
                "[c]fps=4,scale=$PW:$ph,format=gray[o3]"
            // -ss / -t before -i: only the part of the file that becomes the clip is looked at.
            val args = arrayListOf(
                "-hide_banner", "-nostats", "-y", "-threads", "3",
                "-ss", String.format(Locale.US, "%.3f", ss), "-t", String.format(Locale.US, "%.3f", dur),
                "-i", clip.absolutePath, "-filter_complex", fg,
                "-map", "[o1]", "-q:v", "3", File(dir, "f_%03d.jpg").absolutePath,
                "-map", "[o2]", "-f", "null", "/dev/null",
                "-map", "[o3]", "-f", "rawvideo", "-pix_fmt", "gray", "pipe:1",
            )
            val (raw, err) = Bins.bytesWithErr(args)
            val cuts = Regex("pts_time:([0-9.]+)").findAll(err)
                .mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()
            val files = dir.listFiles { f -> f.name.startsWith("f_") && f.name.endsWith(".jpg") }?.sortedBy { it.name } ?: emptyList()
            if (files.isEmpty()) {
                log("Layout analysis failed: ${err.lines().lastOrNull { it.isNotBlank() }?.take(90) ?: "no output"}")
            }

            // One face per sampled frame. Automatic mode picks the most facecam-like face (near an edge,
            // not a mid-screen game character). With a marked area we only look inside that area.
            val faces = ArrayList<Box?>()
            val subjects = ArrayList<Box?>()   // the biggest face in each frame, for videos without a facecam
            val detector = FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .setMinFaceSize(0.04f)
                    .build()
            )
            try {
                for ((idx, f) in files.withIndex()) {
                    val bmp = BitmapFactory.decodeFile(f.absolutePath)
                    if (bmp == null) {
                        faces.add(null)
                        continue
                    }
                    val found = try {
                        Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
                    } catch (_: Exception) {
                        emptyList()
                    }
                    val w = bmp.width.toFloat()
                    val h = bmp.height.toFloat()
                    val boxes = found.map { fc ->
                        val bb = fc.boundingBox
                        Box(
                            (bb.left / w).coerceIn(0f, 1f), (bb.top / h).coerceIn(0f, 1f),
                            (bb.right / w).coerceIn(0f, 1f), (bb.bottom / h).coerceIn(0f, 1f),
                        )
                    }
                    bmp.recycle()
                    subjects.add(boxes.maxByOrNull { it.area })
                    if (region == null) {
                        faces.add(boxes.filter { Segmenter.accepts(it) }.maxByOrNull { Segmenter.score(it, cached) })
                    } else {
                        // The user marked the cam, so it is always shown, face visible or not.
                        // Only a full-screen cam scene (a very big face) switches to the follow-the-face layout.
                        faces.add(boxes.filter { it.w > Segmenter.BIG_FACE }.maxByOrNull { it.area } ?: region)
                    }
                }
            } finally {
                detector.close()
            }

            var segs = Segmenter.build(step, faces, dur, cuts, cached)
            var usedCache = false
            if (region != null && segs.none { it.kind != Kind.BLUR }) {
                // The user marked a cam but no face was found in this clip: trust the marked area.
                segs = listOf(Scene(0.0, dur, Kind.STACK, region))
            } else if (region == null && segs.none { it.kind != Kind.BLUR } && cached != null) {
                // No face anywhere in this clip: fall back to where this channel's facecam was before.
                segs = listOf(Scene(0.0, dur, Kind.STACK, cached))
                usedCache = true
            }

            if (!useCam) segs = listOf(Scene(0.0, dur, Kind.BLUR, null))   // no facecam in this video

            // Where is the action? Skip pairs that straddle a hard cut, mask out facecam areas.
            val fsz = PW * ph
            val frames = raw.size / fsz
            val acc = DoubleArray(fsz)
            var pairs = 0
            val diff = IntArray(fsz)
            for (i in 0 until frames - 1) {
                var sum = 0L
                for (p in 0 until fsz) {
                    val d = Math.abs((raw[i * fsz + p].toInt() and 0xFF) - (raw[(i + 1) * fsz + p].toInt() and 0xFF))
                    diff[p] = d
                    sum += d
                }
                if (sum.toDouble() / fsz > 35.0) continue // a cut, not motion
                for (p in 0 until fsz) acc[p] += diff[p].toDouble()
                pairs++
            }
            for (s in segs) {
                val f = s.face ?: continue
                val ex = f.w * 1.7f
                val ey = f.h * 1.7f
                val x0 = ((f.cx - ex) * PW).toInt().coerceIn(0, PW)
                val x1 = ((f.cx + ex) * PW).toInt().coerceIn(0, PW)
                val y0 = ((f.cy - ey) * ph).toInt().coerceIn(0, ph)
                val y1 = ((f.cy + ey) * ph).toInt().coerceIn(0, ph)
                for (y in y0 until y1) for (x in x0 until x1) acc[y * PW + x] = 0.0
            }
            var total = 0.0
            var weighted = 0.0
            for (x in 0 until PW) {
                var col = 0.0
                for (y in 0 until ph) col += acc[y * PW + x]
                total += col
                weighted += col * x
            }
            val motionX = if (total < max(pairs, 1) * 30.0) 0.5 else weighted / total / (PW - 1)

            // Without a facecam, centre the crop on the people (faces) if we found them, else on the motion.
            val seen = subjects.filterNotNull()
            val subjectX = if (!useCam && seen.size >= max(2, subjects.size / 3))
                seen.map { it.cx.toDouble() }.average() else null

            val cacheFace = if (usedCache || region != null || !useCam) null
            else segs.filter { it.kind == Kind.STACK }.maxByOrNull { it.len }?.face
            return Result(segs, subjectX ?: motionX, cacheFace)
        } finally {
            dir.deleteRecursively()
        }
    }
}
