package app.streamclipper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import kotlin.math.hypot

/**
 * Looks at a few frames of a clip and works out, with no user input:
 *  - where the streamer's facecam is (a face that stays put across frames)
 *  - where the action is (horizontal centre of frame-to-frame motion, facecam excluded)
 */
object AutoLayout {
    /** [face] is normalised 0..1 (null = no facecam). [fresh] = detected now, not from cache. */
    class Result(val face: RectF?, val motionX: Double, val fresh: Boolean)

    private const val PW = 96

    fun loadFace(ctx: Context, key: String): RectF? {
        val p = Store.prefs(ctx).getString(key, null)?.split(",") ?: return null
        if (p.size != 4) return null
        return try {
            RectF(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat())
        } catch (_: NumberFormatException) {
            null
        }
    }

    fun saveFace(ctx: Context, key: String, r: RectF) {
        Store.prefs(ctx).edit().putString(key, "${r.left},${r.top},${r.right},${r.bottom}").apply()
    }

    private class Track(var cx: Float, var cy: Float) {
        val boxes = ArrayList<RectF>()
    }

    fun analyse(clip: File, vw: Int, vh: Int, cached: RectF?): Result {
        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(clip.absolutePath)
        val durUs = (mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000
        val fw = 960
        val fh = (960.0 * vh / vw).toInt().coerceAtLeast(2)
        val ph = (PW.toDouble() * vh / vw).toInt().coerceAtLeast(2)
        val acc = Array(ph) { DoubleArray(PW) }
        val tracks = ArrayList<Track>()
        val n = 5

        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setMinFaceSize(0.04f)
                .build()
        )
        try {
            for (k in 0 until n) {
                val t = durUs * (k + 1) / (n + 1)
                val a = mmr.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST, fw, fh) ?: continue
                val b = mmr.getScaledFrameAtTime(t + 250_000, MediaMetadataRetriever.OPTION_CLOSEST, fw, fh)

                val faces = try {
                    Tasks.await(detector.process(InputImage.fromBitmap(a, 0)))
                } catch (_: Exception) {
                    emptyList()
                }
                for (f in faces) {
                    val bb = f.boundingBox
                    val r = RectF(
                        (bb.left / a.width.toFloat()).coerceIn(0f, 1f),
                        (bb.top / a.height.toFloat()).coerceIn(0f, 1f),
                        (bb.right / a.width.toFloat()).coerceIn(0f, 1f),
                        (bb.bottom / a.height.toFloat()).coerceIn(0f, 1f),
                    )
                    val tr = tracks.firstOrNull { hypot(it.cx - r.centerX(), it.cy - r.centerY()) < 0.05f }
                    if (tr == null) {
                        tracks += Track(r.centerX(), r.centerY()).also { it.boxes += r }
                    } else {
                        tr.boxes += r
                        tr.cx = r.centerX()
                        tr.cy = r.centerY()
                    }
                }

                if (b != null) {
                    val ga = gray(a, ph)
                    val gb = gray(b, ph)
                    for (y in 0 until ph) for (x in 0 until PW) {
                        acc[y][x] += Math.abs(ga[y * PW + x] - gb[y * PW + x]).toDouble()
                    }
                    b.recycle()
                }
                a.recycle()
            }
        } finally {
            detector.close()
            mmr.release()
        }

        // A facecam is a face that stays put in most sampled frames.
        val stable = tracks.filter { tr ->
            if (tr.boxes.size < 3) return@filter false
            val xs = tr.boxes.map { it.centerX() }
            val ys = tr.boxes.map { it.centerY() }
            val w = tr.boxes.map { it.width() }.average().toFloat()
            val tol = maxOf(0.04f, 0.4f * w)
            (xs.max() - xs.min()) <= tol && (ys.max() - ys.min()) <= tol
        }
        val best = stable.maxByOrNull { tr -> tr.boxes.map { it.width() * it.height() }.average() }
        var face: RectF? = best?.let { tr ->
            RectF(
                tr.boxes.map { it.left }.average().toFloat(),
                tr.boxes.map { it.top }.average().toFloat(),
                tr.boxes.map { it.right }.average().toFloat(),
                tr.boxes.map { it.bottom }.average().toFloat(),
            )
        }
        val fresh = face != null
        if (face == null) face = cached

        // Mask the facecam area out of the motion map, then take the centre of what's left.
        face?.let { f ->
            val ex = f.width() * 1.7f
            val ey = f.height() * 1.7f
            val x0 = ((f.centerX() - ex) * PW).toInt().coerceIn(0, PW)
            val x1 = ((f.centerX() + ex) * PW).toInt().coerceIn(0, PW)
            val y0 = ((f.centerY() - ey) * ph).toInt().coerceIn(0, ph)
            val y1 = ((f.centerY() + ey) * ph).toInt().coerceIn(0, ph)
            for (y in y0 until y1) for (x in x0 until x1) acc[y][x] = 0.0
        }
        var total = 0.0
        var weighted = 0.0
        for (x in 0 until PW) {
            var col = 0.0
            for (y in 0 until ph) col += acc[y][x]
            total += col
            weighted += col * x
        }
        val motionX = if (total < 200.0) 0.5 else weighted / total / (PW - 1)
        return Result(face, motionX, fresh)
    }

    private fun gray(bmp: Bitmap, ph: Int): IntArray {
        val s = Bitmap.createScaledBitmap(bmp, PW, ph, true)
        val px = IntArray(PW * ph)
        s.getPixels(px, 0, PW, 0, 0, PW, ph)
        if (s !== bmp) s.recycle()
        return IntArray(PW * ph) { i ->
            val p = px[i]
            (((p shr 16) and 255) * 30 + ((p shr 8) and 255) * 59 + (p and 255) * 11) / 100
        }
    }
}
