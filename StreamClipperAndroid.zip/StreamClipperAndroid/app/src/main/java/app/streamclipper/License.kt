package app.streamclipper

import android.content.Context
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import app.license.LicenseCodec
import app.license.Plan
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.min

/**
 * Time-limited access. A key from the KeyMaker app starts a plan (7 days, 1 month, ...) the moment it is entered.
 * When the plan ends the app locks until a new key is entered. State is kept in app storage and signed with a
 * key held in the Android Keystore, and the clock is guarded against being wound back.
 */
object License {
    enum class State { ACTIVE, NONE, EXPIRED, CLOCK }

    class Status(val state: State, val plan: Plan?, val expiresAt: Long, val daysLeft: Int)

    private const val PREF = "license"
    private const val DAY = 86_400_000L

    @Volatile private var offset = 0L   // real time minus device time, when we could ask the internet

    fun now(): Long = System.currentTimeMillis() + offset

    /** Best-effort check of the real date, so setting the phone clock forward or back doesn't help. */
    fun refreshServerTime() {
        Thread {
            try {
                val c = URL("https://www.google.com").openConnection() as HttpURLConnection
                c.requestMethod = "HEAD"
                c.connectTimeout = 3000
                c.readTimeout = 3000
                val d = c.date
                c.disconnect()
                if (d > 0) {
                    val diff = d - System.currentTimeMillis()
                    offset = if (abs(diff) > 6 * 3_600_000L) diff else 0L
                }
            } catch (_: Exception) {
            }
        }.start()
    }

    fun deviceCode(ctx: Context): String {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        return LicenseCodec.deviceCodeFrom(id)
    }

    // ---- signed storage -------------------------------------------------------------------------

    private fun sign(data: String): String = try {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias("lic")) {
            val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, "AndroidKeyStore")
            g.init(KeyGenParameterSpec.Builder("lic", KeyProperties.PURPOSE_SIGN).build())
            g.generateKey()
        }
        val key = ks.getKey("lic", null) as SecretKey
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(key)
        Base64.encodeToString(mac.doFinal(data.toByteArray()), Base64.NO_WRAP)
    } catch (_: Exception) {
        ""
    }

    private class Saved(val keyHash: String, val activatedAt: Long, val expiresAt: Long, val lastSeen: Long, val plan: Plan)

    private fun load(ctx: Context): Saved? {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val d = p.getString("d", null) ?: return null
        if (sign(d) != (p.getString("t", "") ?: "")) return null   // edited by hand
        val s = d.split("|")
        if (s.size != 5) return null
        return try {
            Saved(s[0], s[1].toLong(), s[2].toLong(), s[3].toLong(), Plan.of(s[4].toInt()))
        } catch (_: Exception) {
            null
        }
    }

    private fun save(ctx: Context, s: Saved) {
        val d = "${s.keyHash}|${s.activatedAt}|${s.expiresAt}|${s.lastSeen}|${s.plan.code}"
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("d", d).putString("t", sign(d)).apply()
    }

    private fun hash(key: String): String = Integer.toHexString(key.hashCode())

    // ---- status -------------------------------------------------------------------------------

    fun status(ctx: Context): Status {
        val s = load(ctx) ?: return Status(State.NONE, null, 0, 0)
        val n = now()
        if (n + 5 * 60_000L < s.lastSeen) return Status(State.CLOCK, s.plan, s.expiresAt, 0)
        if (n - s.lastSeen > 60_000L) save(ctx, Saved(s.keyHash, s.activatedAt, s.expiresAt, n, s.plan))
        val left = ceil((s.expiresAt - n) / DAY.toDouble()).toInt()
        return if (n >= s.expiresAt) Status(State.EXPIRED, s.plan, s.expiresAt, 0)
        else Status(State.ACTIVE, s.plan, s.expiresAt, left)
    }

    fun active(ctx: Context): Boolean = status(ctx).state == State.ACTIVE

    // ---- activation ---------------------------------------------------------------------------

    /** Returns null on success, otherwise a message to show the user. */
    fun activate(ctx: Context, input: String): String? {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val n = now()
        val until = p.getLong("lockUntil", 0L)
        if (n < until) return "Too many wrong keys. Try again in ${((until - n) / 60_000L) + 1} min."

        val key = LicenseCodec.normalise(input)
        val d = LicenseCodec.decode(BuildConfig.LICENSE_SECRET, key, deviceCode(ctx))
        if (d == null) {
            val bad = p.getInt("bad", 0) + 1
            val e = p.edit().putInt("bad", bad)
            if (bad >= 5) e.putInt("bad", 0).putLong("lockUntil", n + 10 * 60_000L)
            e.apply()
            return "That key isn't valid. Check it, or ask for a key for this device (device code ${deviceCode(ctx)})."
        }
        p.edit().putInt("bad", 0).apply()

        val old = load(ctx)
        if (old != null && old.keyHash == hash(key)) {
            return if (n >= old.expiresAt) "This key has already been used and has run out. Ask for a new one." else null
        }
        val today = LicenseCodec.dayNumber(n / DAY)
        if (d.issueDay > today + 2) return "This key isn't valid yet. Check the date on this phone."
        if (today > d.issueDay + LicenseCodec.ACTIVATION_WINDOW_DAYS) {
            return "This key is too old to activate. Keys must be entered within ${LicenseCodec.ACTIVATION_WINDOW_DAYS} days of being made. Ask for a new one."
        }
        // The plan runs from now, but never past the key's own latest end date (stops re-install tricks).
        val hardEnd = (LicenseCodec.epochDayOf(d.issueDay) + LicenseCodec.ACTIVATION_WINDOW_DAYS + d.plan.days) * DAY
        val expires = min(n + d.plan.days * DAY, hardEnd)
        save(ctx, Saved(hash(key), n, expires, n, d.plan))
        return null
    }
}
