package app.streamclipper

import android.app.Activity
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.File

/**
 * In-app Google sign-in for YouTube. After you sign in, the session cookies are saved as a
 * cookies.txt that yt-dlp uses, so YouTube stops asking "confirm you're not a bot".
 */
class YouTubeLoginActivity : Activity() {
    private lateinit var web: WebView
    private var finished = false

    private val loginUrl =
        "https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F"

    // A normal Chrome-for-Android user agent. Google refuses sign-in from agents that say "wv" (WebView).
    private val ua = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/131.0.0.0 Mobile Safari/537.36"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF12121A.toInt())
            fitsSystemWindows = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val title = TextView(this).apply {
            text = "Sign in to YouTube"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFEDEDF5.toInt())
        }
        val cancel = Button(this).apply {
            text = "Cancel"
            isAllCaps = false
            setOnClickListener { finish() }
        }
        val done = Button(this).apply {
            text = "I'm signed in"
            isAllCaps = false
            setOnClickListener { capture(true) }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(cancel)
        bar.addView(done)

        web = WebView(this)
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.userAgentString = ua
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)
        try {
            // Don't tell Google which app this is (WebView normally sends the package name).
            if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
                WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, emptySet())
            }
        } catch (_: Throwable) {
        }

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val host = url?.let { Uri.parse(it).host } ?: return
                if (host.endsWith("youtube.com")) capture(false)
            }
        }
        web.loadUrl(loginUrl)
    }

    /** Builds a cookies.txt from the WebView session once the user is signed in. */
    private fun capture(manual: Boolean) {
        if (finished) return
        val cm = CookieManager.getInstance()
        cm.flush()
        val yt = cm.getCookie("https://www.youtube.com") ?: ""
        val signedIn = yt.contains("SAPISID=") || yt.contains("__Secure-3PAPISID=") ||
            yt.contains("__Secure-1PAPISID=")
        if (!signedIn) {
            if (manual) Toast.makeText(this, "Not signed in yet. Finish signing in first.", Toast.LENGTH_LONG).show()
            return
        }
        val google = (cm.getCookie("https://www.google.com") ?: "") + ";" +
            (cm.getCookie("https://accounts.google.com") ?: "")

        val expiry = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        fun add(domain: String, raw: String) {
            val seen = LinkedHashMap<String, String>()
            for (part in raw.split(";")) {
                val kv = part.trim()
                val i = kv.indexOf('=')
                if (i > 0) seen[kv.substring(0, i)] = kv.substring(i + 1)
            }
            for ((k, v) in seen) sb.append(domain).append("\tTRUE\t/\tTRUE\t").append(expiry)
                .append('\t').append(k).append('\t').append(v).append('\n')
        }
        add(".youtube.com", yt)
        add(".google.com", google)
        File(filesDir, "cookies.txt").writeText(sb.toString())

        // YouTube rotates session cookies if the same login stays open in a browser, so close ours.
        cm.removeAllCookies(null)
        cm.flush()
        WebStorage.getInstance().deleteAllData()
        web.clearCache(true)

        finished = true
        Toast.makeText(this, "Signed in. YouTube links will use your account.", Toast.LENGTH_LONG).show()
        setResult(RESULT_OK)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
