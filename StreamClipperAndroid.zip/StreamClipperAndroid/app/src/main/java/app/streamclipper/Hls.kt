package app.streamclipper

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

class Seg(val seq: Long, val uri: String, val dur: Double)
class Playlist(val segs: List<Seg>, val mapUri: String?, val target: Double, val ended: Boolean)

object Hls {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/130.0 Mobile Safari/537.36"

    fun get(url: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", UA)
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    private fun text(url: String) = String(get(url))

    private fun resolve(base: String, ref: String): String = URI(base).resolve(ref).toString()

    /** If [url] is a master playlist, pick the best variant (up to [maxH] pixels high; 0 = best). */
    fun mediaUrl(url: String, maxH: Int = 0): String {
        val t = text(url)
        if (!t.contains("#EXT-X-STREAM-INF")) return url
        val lines = t.lines()
        val cands = ArrayList<Pair<Int, String>>()
        for (i in lines.indices) {
            if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue
            val uri = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") } ?: continue
            val h = Regex("RESOLUTION=\\d+x(\\d+)").find(lines[i])?.groupValues?.get(1)?.toInt() ?: 0
            cands += h to resolve(url, uri.trim())
        }
        if (cands.isEmpty()) return url
        val ok = cands.filter { maxH == 0 || it.first in 1..maxH }
        val pick = ok.maxByOrNull { it.first } ?: cands.minByOrNull { it.first }!!
        return pick.second
    }

    fun parse(url: String): Playlist {
        val t = text(url)
        var seq = 0L
        var target = 6.0
        var map: String? = null
        var ended = false
        var dur = 0.0
        var n = 0
        val segs = ArrayList<Seg>()
        for (raw in t.lines()) {
            val l = raw.trim()
            when {
                l.startsWith("#EXT-X-MEDIA-SEQUENCE:") ->
                    seq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
                l.startsWith("#EXT-X-TARGETDURATION:") ->
                    target = l.substringAfter(':').trim().toDoubleOrNull() ?: 6.0
                l.startsWith("#EXT-X-MAP:") -> {
                    val m = Regex("URI=\"([^\"]+)\"").find(l)
                    if (m != null) map = resolve(url, m.groupValues[1])
                }
                l.startsWith("#EXTINF:") ->
                    dur = l.substringAfter(':').substringBefore(',').toDoubleOrNull() ?: target
                l.startsWith("#EXT-X-ENDLIST") -> ended = true
                l.isNotEmpty() && !l.startsWith("#") -> {
                    segs += Seg(seq + n, resolve(url, l), dur)
                    n++
                }
            }
        }
        return Playlist(segs, map, target, ended)
    }
}
