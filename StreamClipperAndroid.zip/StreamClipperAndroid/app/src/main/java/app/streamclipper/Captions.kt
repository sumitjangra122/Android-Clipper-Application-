package app.streamclipper

import java.util.Locale

class CapWord(val text: String, val start: Double, val end: Double)

enum class CapStyle(val label: String) {
    POP("Pop"),            // one big word at a time, pops in
    HIGHLIGHT("Highlight"), // a few words, the spoken one lights up
    CLEAN("Clean"),        // normal subtitles
    BOX("Box");            // bold words on a coloured box

    companion object {
        fun of(i: Int): CapStyle = values().getOrElse(i) { HIGHLIGHT }
    }
}

/** Builds an ASS subtitle file (burned in by ffmpeg) from timed words. */
object Captions {
    const val FONTS_DIR_NAME = "fonts"
    private const val YELLOW = "&H0000E6FF&"    // ASS colours are BGR
    private const val WHITE = "&H00FFFFFF&"
    private const val PINK = "&H00632EFF&"      // #FF2E63

    private fun ts(t: Double): String {
        val c = Math.round(maxOf(t, 0.0) * 100).toInt()
        return String.format(Locale.US, "%d:%02d:%02d.%02d", c / 360000, (c / 6000) % 60, (c / 100) % 60, c % 100)
    }

    private fun esc(s: String) = s.replace("\\", "").replace("{", "(").replace("}", ")").replace("\n", " ")

    private fun group(words: List<CapWord>, maxWords: Int, maxChars: Int, maxPause: Double): List<List<CapWord>> {
        val out = ArrayList<List<CapWord>>()
        var cur = ArrayList<CapWord>()
        var chars = 0
        for (w in words) {
            val pause = if (cur.isEmpty()) 0.0 else w.start - cur.last().end
            if (cur.isNotEmpty() && (cur.size >= maxWords || chars + w.text.length > maxChars || pause > maxPause)) {
                out.add(cur)
                cur = ArrayList()
                chars = 0
            }
            cur.add(w)
            chars += w.text.length + 1
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }

    /** Words whose gaps are tiny are joined up, so text doesn't flicker between words. */
    private fun tidy(words: List<CapWord>): List<CapWord> = words.mapIndexed { i, w ->
        val next = words.getOrNull(i + 1)
        val end = if (next != null && next.start - w.end < 0.35) next.start else w.end + 0.15
        CapWord(w.text, w.start, maxOf(end, w.start + 0.12))
    }

    fun build(rawWords: List<CapWord>, style: CapStyle, hindi: Boolean, w: Int, h: Int): String {
        val k = w / 1080.0
        val words = tidy(rawWords.filter { it.text.isNotBlank() })
        fun cased(s: String) = esc(if (hindi || style == CapStyle.CLEAN) s else s.uppercase())

        // font, size, bold, border style, outline, shadow, box colour, y position
        val font: String
        val size: Int
        val bold: Int
        val bs: Int
        val outline: Int
        val shadow: Int
        val yFrac: Double
        when (style) {
            CapStyle.POP -> { font = if (hindi) "Hind" else "Anton"; size = if (hindi) 130 else 165; bold = if (hindi) 1 else 0; bs = 1; outline = 9; shadow = 3; yFrac = 0.66 }
            CapStyle.HIGHLIGHT -> { font = if (hindi) "Hind" else "Anton"; size = if (hindi) 105 else 128; bold = if (hindi) 1 else 0; bs = 1; outline = 8; shadow = 3; yFrac = 0.66 }
            CapStyle.CLEAN -> { font = if (hindi) "Hind" else "Poppins ExtraBold"; size = if (hindi) 78 else 70; bold = if (hindi) 1 else 0; bs = 1; outline = 4; shadow = 2; yFrac = 0.72 }
            CapStyle.BOX -> { font = if (hindi) "Hind" else "Anton"; size = if (hindi) 92 else 104; bold = if (hindi) 1 else 0; bs = 3; outline = 16; shadow = 0; yFrac = 0.66 }
        }
        val outlineColour = if (style == CapStyle.BOX) PINK else "&H00000000&"
        val x = w / 2
        val y = (h * yFrac).toInt()
        val sb = StringBuilder()
        sb.append("[Script Info]\nScriptType: v4.00+\nPlayResX: $w\nPlayResY: $h\nWrapStyle: 0\nScaledBorderAndShadow: yes\n\n")
        sb.append("[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, ")
        sb.append("Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n")
        val primary = if (style == CapStyle.POP) YELLOW else WHITE
        sb.append("Style: Cap,$font,${(size * k).toInt()},$primary,&H000000FF&,$outlineColour,&H80000000&,$bold,0,0,0,100,100,0,0,$bs,")
        sb.append("${(outline * k).toInt()},${(shadow * k).toInt()},5,${(80 * k).toInt()},${(80 * k).toInt()},0,1\n\n")
        sb.append("[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
        val pos = "\\an5\\pos($x,$y)"

        fun event(start: Double, end: Double, text: String) {
            sb.append("Dialogue: 0,${ts(start)},${ts(end)},Cap,,0,0,0,,{$pos}$text\n")
        }

        when (style) {
            CapStyle.POP -> for (wd in words) {
                event(wd.start, wd.end, "{\\fscx72\\fscy72\\t(0,90,\\fscx100\\fscy100)}${cased(wd.text)}")
            }
            CapStyle.HIGHLIGHT -> for (g in group(words, 3, if (hindi) 22 else 20, 0.7)) {
                for ((i, cur) in g.withIndex()) {
                    val end = if (i == g.lastIndex) cur.end else g[i + 1].start
                    val line = g.mapIndexed { j, wd ->
                        if (j == i) "{\\c$YELLOW}${cased(wd.text)}{\\c$WHITE}" else cased(wd.text)
                    }.joinToString(" ")
                    event(cur.start, end, line)
                }
            }
            CapStyle.CLEAN -> for (g in group(words, 7, 40, 0.9)) {
                event(g.first().start, g.last().end, g.joinToString(" ") { cased(it.text) })
            }
            CapStyle.BOX -> for (g in group(words, 3, 22, 0.7)) {
                event(g.first().start, g.last().end, g.joinToString(" ") { cased(it.text) })
            }
        }
        return sb.toString()
    }
}
