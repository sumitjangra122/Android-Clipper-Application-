package app.streamclipper

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/** Normalised (0..1) rectangle. Pure Kotlin so the scene logic can be tested off-device. */
data class Box(val l: Float, val t: Float, val r: Float, val b: Float) {
    val w get() = r - l
    val h get() = b - t
    val cx get() = (l + r) / 2
    val cy get() = (t + b) / 2
    val area get() = w * h
    fun dist(o: Box): Double = hypot((cx - o.cx).toDouble(), (cy - o.cy).toDouble())
}

enum class Kind { STACK, FACE, BLUR }

class Scene(var start: Double, var end: Double, val kind: Kind, val face: Box?) {
    val len get() = end - start
}

/**
 * Turns per-second face detections into a short list of scenes, each with its own layout.
 * Broadcast streams cut between cams, banners and gameplay, so one fixed crop doesn't fit a whole clip.
 */
object Segmenter {
    const val BIG_FACE = 0.25f   // a face wider than this share of the frame = full-screen cam scene
    private const val MIN_SCENE = 1.2
    private const val MAX_SCENES = 8

    fun kindOf(f: Box?): Kind = when {
        f == null -> Kind.BLUR
        f.w > BIG_FACE -> Kind.FACE
        else -> Kind.STACK
    }

    private fun avg(list: List<Box>) = Box(
        list.map { it.l }.average().toFloat(), list.map { it.t }.average().toFloat(),
        list.map { it.r }.average().toFloat(), list.map { it.b }.average().toFloat(),
    )

    private fun similar(a: Box, b: Box) = a.dist(b) < 0.05 && (b.w / a.w) in 0.7f..1.4f

    /**
     * @param step seconds between samples (sample i is at i * step)
     * @param faces main face per sample, or null when none was found
     * @param cuts hard-cut times found by scene detection, used to snap scene boundaries
     * @param cached facecam position remembered from an earlier clip of this channel
     */
    fun build(step: Double, faces: List<Box?>, dur: Double, cuts: List<Double>, cached: Box?): List<Scene> {
        val n = faces.size
        if (n == 0) return listOf(Scene(0.0, dur, Kind.BLUR, null))

        // 1. A detection with no matching neighbour is usually a false positive (a game character, say).
        val f1 = faces.toMutableList()
        for (i in 0 until n) {
            val f = faces[i] ?: continue
            var prevOk = false
            var nextOk = false
            for (d in 1..2) {
                if (i - d >= 0 && faces[i - d]?.let { it.dist(f) < 0.08 } == true) prevOk = true
                if (i + d < n && faces[i + d]?.let { it.dist(f) < 0.08 } == true) nextOk = true
            }
            val cacheOk = cached != null && f.dist(cached) < 0.10
            if (!prevOk && !nextOk && !cacheOk) f1[i] = null
        }

        // 2. Short gaps (head turned, looking down) between matching detections keep the same layout.
        var i = 0
        while (i < n) {
            if (f1[i] != null) { i++; continue }
            var j = i
            while (j < n && f1[j] == null) j++
            val before = if (i > 0) f1[i - 1] else null
            val after = if (j < n) f1[j] else null
            val gap = j - i
            if (before != null) {
                val fillBetween = after != null && gap <= 3 && before.dist(after) < 0.08 &&
                    kindOf(before) == kindOf(after)
                val fillTrailing = after == null && gap <= 2
                if (fillBetween || fillTrailing) for (k in i until j) f1[k] = before
            }
            i = j
        }

        // 3. Group neighbouring samples that use the same layout.
        class G(val kind: Kind, val first: Int, var last: Int, val boxes: ArrayList<Box>)
        val groups = ArrayList<G>()
        for (k in 0 until n) {
            val f = f1[k]
            val kind = kindOf(f)
            val g = groups.lastOrNull()
            val same = g != null && g.kind == kind &&
                (kind == Kind.BLUR || (f != null && similar(avg(g.boxes), f)))
            if (g != null && same) {
                g.last = k
                if (f != null) g.boxes.add(f)
            } else {
                val bx = ArrayList<Box>()
                if (f != null) bx.add(f)
                groups.add(G(kind, k, k, bx))
            }
        }

        // 4. Scene boundaries, snapped to real hard cuts when one is close.
        val segs = ArrayList<Scene>()
        for ((gi, g) in groups.withIndex()) {
            var start = 0.0
            if (gi > 0) {
                val mid = (groups[gi - 1].last + g.first) / 2.0 * step
                start = cuts.filter { abs(it - mid) <= 1.0 }.minByOrNull { abs(it - mid) } ?: mid
                start = max(start, segs.last().start + 0.2)
            }
            segs.add(Scene(start, 0.0, g.kind, if (g.boxes.isEmpty()) null else avg(g.boxes)))
        }
        for (si in segs.indices) segs[si].end = if (si == segs.size - 1) dur else segs[si + 1].start

        // 5. Tidy: fold tiny scenes into the longer neighbour, join look-alikes, cap the count.
        foldShort(segs, MIN_SCENE)
        joinSimilar(segs)
        while (segs.size > MAX_SCENES) foldShort(segs, Double.MAX_VALUE, once = true)
        joinSimilar(segs)
        return segs
    }

    private fun foldShort(segs: MutableList<Scene>, minLen: Double, once: Boolean = false) {
        while (segs.size > 1) {
            val idx = segs.indices.minByOrNull { segs[it].len } ?: break
            val s = segs[idx]
            if (s.len >= minLen) break
            val prev = segs.getOrNull(idx - 1)
            val next = segs.getOrNull(idx + 1)
            if (prev != null && (next == null || prev.len >= next.len)) prev.end = s.end
            else if (next != null) next.start = s.start
            segs.removeAt(idx)
            if (once) break
        }
    }

    private fun joinSimilar(segs: MutableList<Scene>) {
        var i = 0
        while (i < segs.size - 1) {
            val a = segs[i]
            val b = segs[i + 1]
            val same = a.kind == b.kind &&
                (a.kind == Kind.BLUR || (a.face != null && b.face != null && similar(a.face, b.face)))
            if (same) {
                val merged = Scene(a.start, b.end, a.kind, if (a.face != null && b.face != null) avg(listOf(a.face, b.face)) else a.face)
                segs[i] = merged
                segs.removeAt(i + 1)
            } else {
                i++
            }
        }
    }
}
