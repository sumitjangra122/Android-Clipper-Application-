package app.streamclipper

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

/** Playable stream: either one muxed HLS URL, or separate video + audio HLS URLs (YouTube). */
class Resolved(val video: String, val audio: String?)

/** yt-dlp (stream URL lookup) and the ffmpeg binary that ships inside the APK. */
object Bins {
    private var ready = false
    private lateinit var ffmpegPath: String
    private lateinit var ldPath: String
    private lateinit var tmpDir: String

    var encoder = "libx264"
        private set

    @Synchronized
    fun init(ctx: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(ctx)
        FFmpeg.getInstance().init(ctx)
        ffmpegPath = File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so").absolutePath
        ldPath = File(ctx.noBackupFilesDir, "youtubedl-android/packages/ffmpeg/usr/lib").absolutePath
        tmpDir = ctx.cacheDir.absolutePath
        ready = true
        val enc = run(listOf("-hide_banner", "-encoders")).second
        encoder = if (enc.contains("libx264")) "libx264" else "mpeg4"
    }

    private fun proc(args: List<String>): ProcessBuilder {
        val pb = ProcessBuilder(listOf(ffmpegPath) + args)
        pb.environment()["LD_LIBRARY_PATH"] = ldPath
        pb.environment()["TMPDIR"] = tmpDir
        return pb
    }

    /** Runs ffmpeg; returns exit code and combined stdout+stderr. */
    fun run(args: List<String>): Pair<Int, String> {
        val p = proc(args).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        return p.waitFor() to out
    }

    /** Runs ffmpeg and returns raw stdout bytes (stderr discarded). */
    fun bytes(args: List<String>): ByteArray {
        val p = proc(args).redirectError(ProcessBuilder.Redirect.to(File("/dev/null"))).start()
        val data = p.inputStream.readBytes()
        p.waitFor()
        return data
    }

    private var loggedFormats = false

    private val resolveLock = Any()

    /** yt-dlp option sets to try in order. YouTube needs a few client fallbacks. */
    private fun ytAttempts(url: String): List<List<Pair<String, String>>> {
        val list = ArrayList<List<Pair<String, String>>>()
        list.add(emptyList())
        if (url.contains("youtube.com") || url.contains("youtu.be")) {
            list.add(listOf("--remote-components" to "ejs:github"))
            list.add(listOf("--extractor-args" to "youtube:player_client=web_safari"))
            list.add(listOf("--extractor-args" to "youtube:player_client=ios"))
            list.add(listOf("--extractor-args" to "youtube:player_client=tv"))
        }
        return list
    }

    private fun errLine(e: Exception): String =
        e.message?.lines()?.lastOrNull { it.isNotBlank() } ?: e.javaClass.simpleName

    /** Asks yt-dlp for playable HLS URL(s) (Kick, YouTube, Twitch, ...). YouTube gives video and audio separately. */
    fun resolve(url: String, log: (String) -> Unit): Resolved = synchronized(resolveLock) {
        var lastErr = "unknown error"
        for ((i, opts) in ytAttempts(url).withIndex()) {
            try {
                val req = YoutubeDLRequest(url)
                req.addOption("-g")
                req.addOption("-f", "bv[height<=720]+ba/b[height<=720]/b")
                req.addOption("-S", "res:720,fps:30")
                req.addOption("--no-playlist")
                for ((k, v) in opts) req.addOption(k, v)
                val out = YoutubeDL.getInstance().execute(req, null, null).out
                val urls = out.lines().map { it.trim() }.filter { it.startsWith("http") }
                if (urls.isNotEmpty()) {
                    if (i > 0) log("Stream found using fallback #$i")
                    return@synchronized Resolved(urls[0], urls.getOrNull(1))
                }
                lastErr = "yt-dlp returned no stream URL"
            } catch (e: Exception) {
                lastErr = errLine(e)
            }
        }
        if (!loggedFormats) {
            loggedFormats = true
            logFormats(url, log)
        }
        throw IllegalStateException(lastErr)
    }

    /** Downloads a whole video (VOD) to [dir] as video.mp4 (or similar) and returns the file. */
    fun download(url: String, dir: File, pid: String, log: (String) -> Unit, section: String? = null): File {
        var lastErr = "download failed"
        for (opts in ytAttempts(url)) {
            try {
                val req = YoutubeDLRequest(url)
                req.addOption(
                    "-f",
                    "bv*[height<=720][ext=mp4]+ba[ext=m4a]/bv*[height<=720]+ba/b[height<=720]/b"
                )
                req.addOption("--merge-output-format", "mp4")
                req.addOption("--no-playlist")
                req.addOption("-o", File(dir, "video.%(ext)s").absolutePath)
                if (section != null) req.addOption("--download-sections", section)
                for ((k, v) in opts) req.addOption(k, v)
                var lastStep = -1
                YoutubeDL.getInstance().execute(req, pid, { p: Float, _: Long, _: String ->
                    val step = p.toInt() / 10
                    if (step != lastStep) {
                        lastStep = step
                        log("Downloading video… ${p.toInt()}%")
                    }
                })
                val exact = File(dir, "video.mp4")
                val f = if (exact.exists()) exact else
                    dir.listFiles()?.filter { it.name.startsWith("video.") && !it.name.endsWith(".part") }
                        ?.maxByOrNull { it.length() }
                if (f != null && f.length() > 0) return f
                lastErr = "download finished but no file was found"
            } catch (e: Exception) {
                lastErr = errLine(e)
            }
        }
        throw IllegalStateException(lastErr)
    }

    /** Starts ffmpeg and hands back the process so the caller can stream its stdout. */
    fun stream(args: List<String>): Process =
        proc(args).redirectError(ProcessBuilder.Redirect.to(File("/dev/null"))).start()

    /** Shows what formats the site actually offered, so failures can be diagnosed from a screenshot. */
    private fun logFormats(url: String, log: (String) -> Unit) {
        try {
            val req = YoutubeDLRequest(url).addOption("-F").addOption("--no-playlist")
            val r = YoutubeDL.getInstance().execute(req, null, null)
            val rows = r.out.lines().filter {
                it.isNotBlank() && !it.startsWith("[") && !it.startsWith("-") && !it.startsWith("ID")
            }
            log("Formats offered (${rows.size}):")
            rows.take(14).forEach { log("  " + it.replace(Regex("\\s+"), " ").take(70)) }
        } catch (e: Exception) {
            log("Could not list formats: " + (e.message?.lines()?.lastOrNull { it.isNotBlank() }?.take(80) ?: ""))
        }
    }

    /** Updates yt-dlp at most once a day (sites change often) and logs the version in use. */
    fun updateYtDlpIfStale(ctx: Context, log: (String) -> Unit) {
        val p = Store.prefs(ctx)
        val last = p.getLong("ytdlp_updated", 0L)
        if (System.currentTimeMillis() - last >= 24L * 3600 * 1000) {
            try {
                val st = YoutubeDL.getInstance().updateYoutubeDL(ctx)
                p.edit().putLong("ytdlp_updated", System.currentTimeMillis()).apply()
                log("yt-dlp update: $st")
            } catch (e: Throwable) {
                log("yt-dlp update failed: " + (e.message?.take(70) ?: e.javaClass.simpleName))
            }
        }
        val v = try { YoutubeDL.getInstance().versionName(ctx) } catch (_: Throwable) { null }
        log("yt-dlp version: ${v ?: "unknown"}")
    }
}
