package app.streamclipper

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

/** Playable stream: either one muxed HLS URL, or separate video + audio HLS URLs (YouTube). */
class Resolved(val video: String, val audio: String?)

/** yt-dlp (stream URL lookup) and the ffmpeg binary that ships inside the APK. */
object Bins {
    private var ready = false
    private lateinit var ffmpegPath: String
    private lateinit var ldPath: String
    private lateinit var sslCert: String
    private lateinit var homeDir: String
    private lateinit var tmpDir: String
    private lateinit var filesPath: String

    var encoder = "libx264"
        private set

    /** First line of `ffmpeg -version`, for the log. */
    var ffmpegInfo = ""
        private set

    @Synchronized
    fun init(ctx: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(ctx)
        FFmpeg.getInstance().init(ctx)
        ffmpegPath = File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so").absolutePath
        // Same library path the yt-dlp library uses: the python folder holds shared libs ffmpeg needs too.
        val pk = File(ctx.noBackupFilesDir, "youtubedl-android/packages")
        ldPath = listOf("python", "ffmpeg", "aria2c").joinToString(":") { File(pk, "$it/usr/lib").absolutePath }
        sslCert = File(pk, "python/usr/etc/tls/cert.pem").absolutePath
        homeDir = File(pk, "python/usr").absolutePath
        tmpDir = ctx.cacheDir.absolutePath
        filesPath = ctx.filesDir.absolutePath

        val v = run(listOf("-hide_banner", "-version")).second
        val first = v.lines().firstOrNull { it.startsWith("ffmpeg version") }
        if (first == null) {
            val why = v.lines().filter { it.isNotBlank() }.take(2).joinToString(" | ").take(160)
            throw IllegalStateException("ffmpeg can't start: ${why.ifEmpty { "no output" }}")
        }
        ffmpegInfo = first.take(60)
        val enc = run(listOf("-hide_banner", "-encoders")).second
        encoder = if (enc.contains("libx264")) "libx264" else "mpeg4"
        ready = true
    }

    private fun proc(args: List<String>): ProcessBuilder {
        val pb = ProcessBuilder(listOf(ffmpegPath) + args)
        val env = pb.environment()
        env["LD_LIBRARY_PATH"] = ldPath
        env["SSL_CERT_FILE"] = sslCert
        env["HOME"] = homeDir
        env["TMPDIR"] = tmpDir
        return pb
    }

    /** Runs ffmpeg; returns exit code and combined stdout+stderr. */
    fun run(args: List<String>): Pair<Int, String> {
        val p = proc(args).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        return p.waitFor() to out
    }

    /** Runs ffmpeg and returns raw stdout bytes (stderr discarded). */
    fun bytes(args: List<String>): ByteArray = bytesWithErr(args).first

    /** Like [bytes] but also returns whatever ffmpeg wrote to stderr, for diagnostics. */
    fun bytesWithErr(args: List<String>): Pair<ByteArray, String> {
        val errFile = File.createTempFile("ff", ".err", File(tmpDir))
        try {
            val p = proc(args).redirectError(errFile).start()
            val data = p.inputStream.readBytes()
            p.waitFor()
            return data to errFile.readText()
        } finally {
            errFile.delete()
        }
    }

    /** Cookie file the user added in Settings (helps with YouTube's "confirm you're not a bot"). */
    fun cookiesFile(): File? = File(filesPath, "cookies.txt").takeIf { it.exists() && it.length() > 0 }

    private fun cookieOpts(): List<Pair<String, String>> =
        cookiesFile()?.let { listOf("--cookies" to it.absolutePath) } ?: emptyList()

    private var loggedFormats = false

    private val resolveLock = Any()

    /** yt-dlp option sets to try in order. YouTube needs a few client fallbacks. */
    private fun ytAttempts(url: String): List<List<Pair<String, String>>> {
        val ck = cookieOpts()
        val list = ArrayList<List<Pair<String, String>>>()
        list.add(ck)
        if (url.contains("youtube.com") || url.contains("youtu.be")) {
            list.add(ck + listOf("--remote-components" to "ejs:github"))
            for (c in listOf("android_vr", "mweb", "web_safari", "ios", "tv")) {
                list.add(ck + listOf("--extractor-args" to "youtube:player_client=$c"))
            }
        }
        return list
    }

    private fun errLine(e: Exception): String =
        e.message?.lines()?.lastOrNull { it.isNotBlank() } ?: e.javaClass.simpleName

    /** Asks yt-dlp for playable HLS URL(s) (Kick, YouTube, Twitch, ...). YouTube gives video and audio separately. */
    fun resolve(url: String, log: (String) -> Unit): Resolved = synchronized(resolveLock) {
        var lastErr = "unknown error"
        for ((i, opts) in ytAttempts(url).withIndex()) {
            try {
                val req = YoutubeDLRequest(url)
                req.addOption("-g")
                req.addOption("-f", "bv[height<=720]+ba/b[height<=720]/b")
                req.addOption("-S", "res:720,fps:30")
                req.addOption("--no-playlist")
                for ((k, v) in opts) req.addOption(k, v)
                val out = YoutubeDL.getInstance().execute(req, null, null).out
                val urls = out.lines().map { it.trim() }.filter { it.startsWith("http") }
                if (urls.isNotEmpty()) {
                    if (i > 0) log("Stream found using fallback #$i")
                    return@synchronized Resolved(urls[0], urls.getOrNull(1))
                }
                lastErr = "yt-dlp returned no stream URL"
            } catch (e: Exception) {
                lastErr = errLine(e)
            }
        }
        if (!loggedFormats) {
            loggedFormats = true
            logFormats(url, log)
        }
        throw IllegalStateException(lastErr)
    }

    /** Downloads a whole video (VOD) to [dir] as video.mp4 (or similar) and returns the file. */
    fun download(url: String, dir: File, pid: String, log: (String) -> Unit, section: String? = null): File {
        var lastErr = "download failed"
        for (opts in ytAttempts(url)) {
            try {
                val req = YoutubeDLRequest(url)
                req.addOption(
                    "-f",
                    "bv*[height<=720][ext=mp4]+ba[ext=m4a]/bv*[height<=720]+ba/b[height<=720]/b"
                )
                req.addOption("--merge-output-format", "mp4")
                req.addOption("--no-playlist")
                req.addOption("-o", File(dir, "video.%(ext)s").absolutePath)
                if (section != null) req.addOption("--download-sections", section)
                for ((k, v) in opts) req.addOption(k, v)
                var lastStep = -1
                YoutubeDL.getInstance().execute(req, pid, { p: Float, _: Long, _: String ->
                    val step = p.toInt() / 10
                    if (step != lastStep) {
                        lastStep = step
                        log("Downloading video… ${p.toInt()}%")
                    }
                })
                val exact = File(dir, "video.mp4")
                val f = if (exact.exists()) exact else
                    dir.listFiles()?.filter { it.name.startsWith("video.") && !it.name.endsWith(".part") }
                        ?.maxByOrNull { it.length() }
                if (f != null && f.length() > 0) return f
                lastErr = "download finished but no file was found"
            } catch (e: Exception) {
                lastErr = errLine(e)
            }
        }
        throw IllegalStateException(lastErr)
    }

    /** Starts ffmpeg and hands back the process so the caller can stream its stdout. */
    fun stream(args: List<String>): Process =
        proc(args).redirectError(ProcessBuilder.Redirect.to(File("/dev/null"))).start()

    /** Shows what formats the site actually offered, so failures can be diagnosed from a screenshot. */
    private fun logFormats(url: String, log: (String) -> Unit) {
        try {
            val req = YoutubeDLRequest(url).addOption("-F").addOption("--no-playlist")
            val r = YoutubeDL.getInstance().execute(req, null, null)
            val rows = r.out.lines().filter {
                it.isNotBlank() && !it.startsWith("[") && !it.startsWith("-") && !it.startsWith("ID")
            }
            log("Formats offered (${rows.size}):")
            rows.take(14).forEach { log("  " + it.replace(Regex("\\s+"), " ").take(70)) }
        } catch (e: Exception) {
            log("Could not list formats: " + (e.message?.lines()?.lastOrNull { it.isNotBlank() }?.take(80) ?: ""))
        }
    }

    /** Updates yt-dlp at most once a day (sites change often) and logs the version in use. */
    fun updateYtDlpIfStale(ctx: Context, log: (String) -> Unit) {
        val p = Store.prefs(ctx)
        val last = p.getLong("ytdlp_updated", 0L)
        if (System.currentTimeMillis() - last >= 24L * 3600 * 1000) {
            try {
                val st = YoutubeDL.getInstance().updateYoutubeDL(ctx)
                p.edit().putLong("ytdlp_updated", System.currentTimeMillis()).apply()
                log("yt-dlp update: $st")
            } catch (e: Throwable) {
                log("yt-dlp update failed: " + (e.message?.take(70) ?: e.javaClass.simpleName))
            }
        }
        val v = try { YoutubeDL.getInstance().versionName(ctx) } catch (_: Throwable) { null }
        log("yt-dlp version: ${v ?: "unknown"}")
    }
}
