package app.streamclipper

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

/** yt-dlp (stream URL lookup) and the ffmpeg binary that ships inside the APK. */
object Bins {
    private var ready = false
    private lateinit var ffmpegPath: String
    private lateinit var ldPath: String
    private lateinit var tmpDir: String

    var encoder = "libx264"
        private set

    @Synchronized
    fun init(ctx: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(ctx)
        FFmpeg.getInstance().init(ctx)
        ffmpegPath = File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so").absolutePath
        ldPath = File(ctx.noBackupFilesDir, "youtubedl-android/packages/ffmpeg/usr/lib").absolutePath
        tmpDir = ctx.cacheDir.absolutePath
        ready = true
        val enc = run(listOf("-hide_banner", "-encoders")).second
        encoder = if (enc.contains("libx264")) "libx264" else "mpeg4"
    }

    private fun proc(args: List<String>): ProcessBuilder {
        val pb = ProcessBuilder(listOf(ffmpegPath) + args)
        pb.environment()["LD_LIBRARY_PATH"] = ldPath
        pb.environment()["TMPDIR"] = tmpDir
        return pb
    }

    /** Runs ffmpeg; returns exit code and combined stdout+stderr. */
    fun run(args: List<String>): Pair<Int, String> {
        val p = proc(args).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        return p.waitFor() to out
    }

    /** Runs ffmpeg and returns raw stdout bytes (stderr discarded). */
    fun bytes(args: List<String>): ByteArray {
        val p = proc(args).redirectError(ProcessBuilder.Redirect.to(File("/dev/null"))).start()
        val data = p.inputStream.readBytes()
        p.waitFor()
        return data
    }

    /** Asks yt-dlp for a playable HLS URL (works for Kick, YouTube, Twitch, ...). */
    fun resolve(url: String): String {
        val req = YoutubeDLRequest(url)
        req.addOption("-f", "best[height<=720]/best")
        req.addOption("--no-playlist")
        val info = YoutubeDL.getInstance().getInfo(req)
        return info.url ?: info.manifestUrl
            ?: throw IllegalStateException("no playable URL (is the channel live?)")
    }

    /** Updates yt-dlp at most once a day; sites change often. */
    fun updateYtDlpIfStale(ctx: Context) {
        val p = Store.prefs(ctx)
        val last = p.getLong("ytdlp_updated", 0L)
        if (System.currentTimeMillis() - last < 24L * 3600 * 1000) return
        try {
            YoutubeDL.getInstance().updateYoutubeDL(ctx)
            p.edit().putLong("ytdlp_updated", System.currentTimeMillis()).apply()
        } catch (_: Throwable) {
        }
    }
}
