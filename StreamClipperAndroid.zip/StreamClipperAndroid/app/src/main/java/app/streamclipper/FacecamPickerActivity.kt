package app.streamclipper

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Shows a frame of the stream and lets you draw a box around the facecam, so other faces are ignored. */
class FacecamPickerActivity : Activity() {
    private lateinit var region: RegionView
    private lateinit var status: TextView
    private var source = ""
    private var isUri = false
    private var variant = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, accent: Boolean, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(if (accent) 0xFFFF2E63.toInt() else 0xFF2A2A3C.toInt())
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), dp(6), dp(4), dp(6)) }
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        source = intent.getStringExtra("source") ?: ""
        isUri = intent.getBooleanExtra("isUri", false)
        val title = intent.getStringExtra("title") ?: "Facecam"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF12121A.toInt())
            fitsSystemWindows = true
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "Select facecam · $title"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFEDEDF5.toInt())
        })
        status = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF9A9AB0.toInt())
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(status)

        region = RegionView(this)
        AutoLayout.loadRegion(this, source)?.let { region.rect = RectF(it.l, it.t, it.r, it.b) }
        root.addView(region, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(btn("Another frame", false) { variant++; load() })
        row.addView(btn("Clear", false) { region.rect = null })
        row.addView(btn("Save", true) { save() })
        root.addView(row, LinearLayout.LayoutParams(-1, -2))
        root.addView(btn("Cancel", false) { finish() }.apply { layoutParams = LinearLayout.LayoutParams(-1, -2) })

        setContentView(root)
        load()
    }

    private fun load() {
        status.text = "Loading a frame… (the first time can take about 30 seconds)"
        val ctx: Context = applicationContext
        Thread {
            try {
                val bmp = Snapshot.grab(ctx, source, isUri, variant) { }
                runOnUiThread {
                    region.bitmap = bmp
                    status.text = "Drag to draw a box around the facecam. Drag the box to move it, drag a corner to resize. " +
                        "Tap Another frame if the cam isn't visible. Leave it empty for automatic."
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Couldn't load a preview: ${e.message?.take(120)}" }
            }
        }.start()
    }

    private fun save() {
        val r = region.rect
        if (r == null) {
            AutoLayout.saveRegion(this, source, null)
            Toast.makeText(this, "Facecam set to automatic", Toast.LENGTH_SHORT).show()
        } else {
            AutoLayout.saveRegion(this, source, Box(r.left, r.top, r.right, r.bottom, true))
            Toast.makeText(this, "Facecam area saved", Toast.LENGTH_SHORT).show()
        }
        setResult(RESULT_OK)
        finish()
    }
}

/** Image with a draggable, resizable selection box. The box is stored as fractions (0..1) of the image. */
class RegionView(ctx: Context) : View(ctx) {
    var bitmap: Bitmap? = null
        set(v) {
            field = v
            layoutImage()
            invalidate()
        }
    var rect: RectF? = null
        set(v) {
            field = v
            invalidate()
        }

    private val img = RectF()
    private val density = resources.displayMetrics.density
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFF2E63.toInt()
        strokeWidth = 3f * density
    }
    private val shade = Paint().apply { color = 0xAA000000.toInt() }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2E63.toInt() }

    private enum class Mode { NONE, DRAW, MOVE, RESIZE }
    private var mode = Mode.NONE
    private var ax = 0f
    private var ay = 0f
    private var lastX = 0f
    private var lastY = 0f

    private fun layoutImage() {
        val b = bitmap ?: return
        if (width <= 0 || height <= 0) return
        val s = min(width.toFloat() / b.width, height.toFloat() / b.height)
        val w = b.width * s
        val h = b.height * s
        img.set((width - w) / 2, (height - h) / 2, (width + w) / 2, (height + h) / 2)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutImage()
    }

    private fun nx(x: Float) = ((x - img.left) / img.width()).coerceIn(0f, 1f)
    private fun ny(y: Float) = ((y - img.top) / img.height()).coerceIn(0f, 1f)

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        canvas.drawBitmap(b, null, img, null)
        val r = rect ?: return
        val l = img.left + r.left * img.width()
        val t = img.top + r.top * img.height()
        val rr = img.left + r.right * img.width()
        val bb = img.top + r.bottom * img.height()
        canvas.drawRect(img.left, img.top, img.right, t, shade)
        canvas.drawRect(img.left, bb, img.right, img.bottom, shade)
        canvas.drawRect(img.left, t, l, bb, shade)
        canvas.drawRect(rr, t, img.right, bb, shade)
        canvas.drawRect(l, t, rr, bb, boxPaint)
        for ((cx, cy) in listOf(l to t, rr to t, l to bb, rr to bb)) canvas.drawCircle(cx, cy, 7f * density, handle)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (bitmap == null || img.width() <= 0f) return true
        val x = nx(e.x)
        val y = ny(e.y)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val r = rect
                if (r != null) {
                    val corners = listOf(r.left to r.top, r.right to r.top, r.left to r.bottom, r.right to r.bottom)
                    val slop = 28f * density
                    val near = corners.indexOfFirst {
                        hypot(img.left + it.first * img.width() - e.x, img.top + it.second * img.height() - e.y) < slop
                    }
                    if (near >= 0) {
                        mode = Mode.RESIZE
                        ax = corners[3 - near].first   // opposite corner stays fixed
                        ay = corners[3 - near].second
                        return true
                    }
                    if (x in r.left..r.right && y in r.top..r.bottom) {
                        mode = Mode.MOVE
                        lastX = x
                        lastY = y
                        return true
                    }
                }
                mode = Mode.DRAW
                ax = x
                ay = y
                rect = RectF(x, y, x, y)
            }
            MotionEvent.ACTION_MOVE -> when (mode) {
                Mode.DRAW, Mode.RESIZE -> rect = RectF(min(ax, x), min(ay, y), max(ax, x), max(ay, y))
                Mode.MOVE -> {
                    val r = rect ?: return true
                    val dx = (x - lastX).coerceIn(-r.left, 1f - r.right)
                    val dy = (y - lastY).coerceIn(-r.top, 1f - r.bottom)
                    rect = RectF(r.left + dx, r.top + dy, r.right + dx, r.bottom + dy)
                    lastX = x
                    lastY = y
                }
                Mode.NONE -> {}
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val r = rect
                if (r != null && (r.width() < 0.03f || r.height() < 0.03f)) rect = null
                mode = Mode.NONE
            }
        }
        return true
    }
}
