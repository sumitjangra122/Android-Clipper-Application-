package app.streamclipper

import android.content.Context
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class Config(
    val thr: Double,
    val clipLen: Int,         // wanted clip length in seconds, 0 = auto (as long as the action lasts)
    val keepRaw: Boolean,
    val camPos: String,
    val maxClips: Int = 10,   // used for video (VOD) clipping
    val outW: Int = 1440,     // vertical output size: 1440x2560 (2K) or 1080x1920
    val outH: Int = 2560,
    val srcMax: Int = 0,      // highest source height to download, 0 = best available
    val keep60: Boolean = false,
    val useCam: Boolean = true,   // false for videos without a facecam
    val game: Int = 0,        // 0 general, 1 BGMI, 2 GTA: tunes the screen detection
    val watchScreen: Boolean = true,
    val cool: Boolean = true, // cool mode: lighter encoding and pauses when the phone is hot
    val captions: Boolean = false,   // burn in captions (video clips)
    val capStyle: Int = 1,           // 0 Pop, 1 Highlight, 2 Clean, 3 Box
    val capLang: Int = 0,            // 0 English, 1 Hindi
    val downloadOnly: Boolean = false, // just download the video in the best quality
)

/**
 * Downloads the live HLS stream segment by segment into a rolling buffer and scores every half second
 * from the audio AND the screen. Whole events (build-up, peak, aftermath) are detected, so a clip starts
 * where the action starts and ends when it is over, instead of cutting at a single trigger point.
 * Handles both a single muxed playlist and separate video + audio playlists (YouTube).
 */
class Watcher(
    private val ctx: Context,
    private val id: Int,
    private val url: String,
    @Volatile var cfg: Config,
    private val submit: (File, () -> Unit) -> Unit,
    private val log: (String) -> Unit,
) {
    @Volatile
    var running = true

    private class Rec(val file: File, val audio: File?, val start: Double, val dur: Double)
    private class Win(val start: Double, val end: Double)

    private val buf = File(ctx.cacheDir, "buf${id}_${System.nanoTime()}").apply { deleteRecursively(); mkdirs() }
    private val timeline = ArrayList<Rec>()
    private val pending = ArrayList<Win>()

    private val detector = EventDetector({ cfg.thr })
    private val audioBase = Baseline(sdFloor = 1.5)
    private val audioRecent = ArrayDeque<Double>()
    private var game = -1
    private var visual = VisualFeatures(VW, VH, Game.GENERAL)
    private var scorer = VisualScorer(Game.GENERAL)

    private var lastPeak = -1e9
    private var streamEnd = 0.0
    private var clips = 0
    private var lastBeat = 0L
    private var lastLic = 0L
    private var thermalAt = 0L
    private var thermal = 0
    private var warnedEmpty = false
    private var warnedAnalyse = false
    @Volatile private var clipNow = false

    companion object {
        private const val VW = 96
        private const val VH = 54
        private const val KEEP_SECONDS = 150.0
    }

    /** "Clip now" button: cut the most recent seconds right away (also a quick end-to-end test). */
    fun requestClip() {
        clipNow = true
    }

    fun run() {
        var media: String? = null
        var audioMedia: String? = null
        var lastSeq = -1L
        var initV: ByteArray? = null
        var initA: ByteArray? = null
        var fails = 0
        try {
            while (running) {
                try {
                    val nowMs = System.currentTimeMillis()
                    if (nowMs - lastLic > 30_000) {
                        lastLic = nowMs
                        if (!License.active(ctx)) {
                            log("Access has ended. Enter a new key in the app to continue.")
                            break
                        }
                    }
                    if (media == null) {
                        log("Looking for the live stream…")
                        try {
                            val r = Bins.resolve(url, log, cfg.srcMax)
                            media = Hls.mediaUrl(r.video, cfg.srcMax)
                            audioMedia = r.audio?.let { Hls.mediaUrl(it, cfg.srcMax) }
                        } catch (e: Exception) {
                            val msg = e.message ?: ""
                            if (msg.contains("not a bot", true) || msg.contains("Sign in", true)) {
                                log("YouTube wants a login from this connection. Sign in to YouTube in Settings, or try again later. Retrying in 2 min")
                                Thread.sleep(120_000)
                            } else {
                                log("Can't open stream (${msg.take(110)}). Retrying in 30s")
                                Thread.sleep(30_000)
                            }
                            continue
                        }
                        lastSeq = -1L
                        initV = null
                        initA = null
                        log(if (audioMedia != null) "Live (video + audio streams). Watching…" else "Live. Watching…")
                    }
                    val plV = Hls.parse(media)
                    val plA = audioMedia?.let { Hls.parse(it) }
                    fails = 0
                    if (plV.ended) {
                        log("Stream ended")
                        break
                    }
                    if (plV.mapUri != null && initV == null) initV = Hls.get(plV.mapUri)
                    val am = plA?.mapUri
                    if (am != null && initA == null) initA = Hls.get(am)

                    // Video and audio playlists normally share sequence numbers; if they don't, align the live edges.
                    val shift = if (plA == null || plA.segs.isEmpty() || plV.segs.isEmpty()) {
                        0L
                    } else {
                        val aSeqs = plA.segs.map { it.seq }.toSet()
                        if (plV.segs.any { it.seq in aSeqs }) 0L
                        else plA.segs.last().seq - plV.segs.last().seq
                    }

                    var fresh = plV.segs.filter { it.seq > lastSeq }
                    if (lastSeq < 0) fresh = fresh.takeLast(3)
                    for (s in fresh) {
                        if (!running) break
                        var sa: Seg? = null
                        if (plA != null) {
                            sa = plA.segs.firstOrNull { it.seq == s.seq + shift }
                            if (sa == null) break // audio segment not published yet, retry next poll
                        }
                        val fv = File(buf, "${s.seq}.ts")
                        val dv = Hls.get(s.uri)
                        fv.outputStream().use { o ->
                            initV?.let { o.write(it) }
                            o.write(dv)
                        }
                        var fa: File? = null
                        if (sa != null) {
                            val file = File(buf, "${s.seq}a.ts")
                            val da = Hls.get(sa.uri)
                            file.outputStream().use { o ->
                                initA?.let { o.write(it) }
                                o.write(da)
                            }
                            fa = file
                        }
                        lastSeq = s.seq
                        val rec = Rec(fv, fa, streamEnd, s.dur)
                        streamEnd += s.dur
                        timeline += rec
                        try {
                            analyse(rec)
                        } catch (e: InterruptedException) {
                            throw e
                        } catch (e: Exception) {
                            if (!warnedAnalyse) {
                                warnedAnalyse = true
                                log("Analysis error: ${e.message?.take(100)}")
                            }
                        }
                    }
                    if (clipNow && streamEnd > 0) {
                        clipNow = false
                        val len = if (cfg.clipLen > 0) cfg.clipLen.toDouble() else 30.0
                        val earliest = timeline.firstOrNull()?.start ?: 0.0
                        pending += Win(max(earliest, streamEnd - len), streamEnd)
                        log("Manual clip requested, cutting…")
                    }
                    launchReady()
                    cleanup()
                    Thread.sleep(((plV.target / 2) * 1000).toLong().coerceIn(700L, 3000L))
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    fails++
                    log("Stream hiccup: ${e.message?.take(80)}")
                    if (fails >= 4 && e is java.io.IOException) {
                        media = null
                        audioMedia = null
                        fails = 0
                    }
                    Thread.sleep(3000)
                }
            }
        } catch (_: InterruptedException) {
        } finally {
            buf.deleteRecursively()
        }
    }

    // ---- scoring ------------------------------------------------------------------------------

    private fun thermalLevel(): Int {
        val n = System.currentTimeMillis()
        if (n - thermalAt > 10_000) {
            thermalAt = n
            thermal = Thermal.level(ctx)
        }
        return thermal
    }

    private fun audioScores(rec: Rec): DoubleArray {
        val src = rec.audio ?: rec.file
        val (pcm, err) = Bins.bytesWithErr(
            listOf("-loglevel", "error", "-i", src.absolutePath, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-")
        )
        if (pcm.size < 4000 && !warnedEmpty) {
            warnedEmpty = true
            log("No audio decoded from the stream. ffmpeg said: ${err.lines().lastOrNull { it.isNotBlank() }?.take(100) ?: "nothing"}")
        }
        val samples = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val win = 8000 // 0.5 s at 16 kHz
        val n = pcm.size / 2 / win
        val out = DoubleArray(n)
        for (w in 0 until n) {
            var sum = 0.0
            for (i in w * win until (w + 1) * win) {
                val v = samples.get(i) / 32768.0
                sum += v * v
            }
            val db = max(20 * log10(sqrt(sum / win) + 1e-9), -90.0)
            audioRecent.addLast(audioBase.z(db))
            if (audioRecent.size > 3) audioRecent.removeFirst()
            audioBase.add(db)
            out[w] = audioRecent.average()
        }
        return out
    }

    /** Screen score per half second: motion, flashes, red hit effects and kill-feed activity. */
    private fun screenScores(rec: Rec, windows: Int): DoubleArray {
        val out = DoubleArray(windows)
        val c = cfg
        if (!c.watchScreen || thermalLevel() >= 2) return out
        if (c.game != game) {
            game = c.game
            visual = VisualFeatures(VW, VH, Game.of(game))
            scorer = VisualScorer(Game.of(game))
        }
        // Light decode: no loop filter, few threads, tiny frames, 8 per second.
        val bytes = Bins.bytes(
            listOf(
                "-loglevel", "error", "-skip_loop_filter", "all", "-threads", "2", "-i", rec.file.absolutePath,
                "-an", "-vf", "fps=8,scale=$VW:$VH,format=rgb24", "-f", "rawvideo", "pipe:1",
            )
        )
        val fsz = VW * VH * 3
        val frames = bytes.size / fsz
        var m = 0.0; var fl = 0.0; var rd = 0.0; var hu = 0.0; var cnt = 0
        for (f in 0 until frames) {
            val ff = visual.feed(bytes, f * fsz)
            m += ff.motion; fl += ff.flash; rd += ff.red; hu += ff.hud; cnt++
            if (cnt == 4 || f == frames - 1) {
                val widx = f / 4
                if (widx < windows) out[widx] = scorer.score(FrameFeatures(m / cnt, fl / cnt, rd / cnt, hu / cnt))
                m = 0.0; fl = 0.0; rd = 0.0; hu = 0.0; cnt = 0
            }
        }
        return out
    }

    private fun analyse(rec: Rec) {
        val a = audioScores(rec)
        val v = screenScores(rec, a.size)
        for (w in a.indices) {
            val score = Fuse.score(a[w], v[w])
            val t = rec.start + w * 0.5
            val nowMs = System.currentTimeMillis()
            if (nowMs - lastBeat > 45_000) {
                lastBeat = nowMs
                log(
                    "Listening: audio ${"%.1f".format(Locale.US, a[w])}, screen ${"%.1f".format(Locale.US, v[w])}, " +
                        "score ${"%.1f".format(Locale.US, score)} (clips at ${"%.1f".format(Locale.US, cfg.thr)})"
                )
            }
            detector.feed(t, score)?.let { onEvent(it) }
        }
    }

    private fun onEvent(e: Event) {
        if (abs(e.peak - lastPeak) < 10) return   // same moment again
        lastPeak = e.peak
        val c = cfg
        val span = ClipWindow.compute(e, c.clipLen)
        val earliest = timeline.firstOrNull()?.start ?: 0.0
        val s = max(span.start, earliest)
        val end = if (c.clipLen > 0 && s > span.start) s + c.clipLen else span.end
        pending += Win(s, end)
        log("Moment found (${"%.0f".format(Locale.US, e.end - e.onset)} s of action). Cutting it when it's complete…")
    }

    // ---- cutting ------------------------------------------------------------------------------

    private fun launchReady() {
        val it = pending.iterator()
        while (it.hasNext()) {
            val w = it.next()
            if (streamEnd >= w.end) {
                it.remove()
                cutClip(w)
            }
        }
    }

    private fun cutClip(w: Win) {
        val chosen = timeline.filter { it.start + it.dur > w.start && it.start < w.end }
        if (chosen.isEmpty()) return
        val first = chosen.first().start
        val covered = chosen.last().start + chosen.last().dur
        val trimStart = max(0.0, w.start - first)
        val len = min(w.end, covered) - (first + trimStart)
        if (len < 5) return
        val n = ++clips
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val hasAudio = chosen.all { it.audio != null }
        val listV = File(buf, "clip${n}v.txt")
        listV.writeText(chosen.joinToString("\n") { "file '${it.file.absolutePath}'" } + "\n")
        val listA = File(buf, "clip${n}a.txt")
        if (hasAudio) {
            listA.writeText(chosen.joinToString("\n") { "file '${it.audio!!.absolutePath}'" } + "\n")
        }
        val raw = File(ctx.cacheDir, "raw_${stamp}_s${id}_$n.mp4")

        fun cut(bsf: Boolean): Int {
            val a = ArrayList<String>(
                listOf("-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", listV.absolutePath)
            )
            if (hasAudio) {
                a += listOf("-f", "concat", "-safe", "0", "-i", listA.absolutePath, "-map", "0:v:0", "-map", "1:a:0")
            }
            a += listOf("-c", "copy")
            if (bsf) a += listOf("-bsf:a", "aac_adtstoasc")
            a += listOf("-movflags", "+faststart", raw.absolutePath)
            return Bins.run(a).first
        }
        var code = cut(true)
        if (code != 0) code = cut(false) // fMP4 audio is already in MP4 form
        listV.delete()
        listA.delete()
        if (code != 0 || !raw.exists()) {
            log("Clip $n: cutting failed")
            return
        }
        log("Clip $n cut (${"%.0f".format(Locale.US, len)} s), editing to 9:16…")
        val c = cfg
        submit(raw) {
            try {
                Editor.process(ctx, raw, trimStart, len, url, c, "clip_${stamp}_s${id}_$n", log)
            } catch (e: Throwable) {
                log("Clip $n edit failed: ${e.message?.take(120)}")
            }
        }
    }

    private fun cleanup() {
        var keepFrom = streamEnd - KEEP_SECONDS
        pending.minOfOrNull { it.start }?.let { keepFrom = minOf(keepFrom, it - 6) }
        detector.activeOnset()?.let { keepFrom = minOf(keepFrom, it - 12) }
        val iter = timeline.iterator()
        while (iter.hasNext()) {
            val r = iter.next()
            if (r.start + r.dur < keepFrom) {
                r.file.delete()
                r.audio?.delete()
                iter.remove()
            }
        }
    }
}
