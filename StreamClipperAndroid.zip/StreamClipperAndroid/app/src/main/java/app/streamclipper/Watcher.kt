package app.streamclipper

import android.content.Context
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

class Config(
    val thr: Double,
    val pre: Int,
    val post: Int,
    val cooldown: Int,
    val keepRaw: Boolean,
    val camPos: String,
    val maxClips: Int = 10,   // used for video (VOD) clipping
)

/**
 * Downloads the live HLS stream segment by segment into a rolling buffer, scores audio
 * loudness against the stream's own recent baseline, and cuts + edits a clip on spikes.
 * Handles both a single muxed playlist and separate video + audio playlists (YouTube).
 */
class Watcher(
    private val ctx: Context,
    private val id: Int,
    private val url: String,
    private val cfg: Config,
    private val submit: (File, () -> Unit) -> Unit,
    private val log: (String) -> Unit,
) {
    @Volatile
    var running = true

    private class Rec(val file: File, val audio: File?, val start: Double, val dur: Double)

    private val buf = File(ctx.cacheDir, "buf$id").apply { deleteRecursively(); mkdirs() }
    private val timeline = ArrayList<Rec>()
    private val pending = ArrayList<Double>()          // trigger times, stream seconds
    private val hist = ArrayDeque<Double>()            // dB history (~2 min)
    private val recent = ArrayDeque<Double>()          // last 3 z-scores
    private var lastTrig = -1e9
    private var streamEnd = 0.0
    private var clips = 0

    fun run() {
        var media: String? = null
        var audioMedia: String? = null
        var lastSeq = -1L
        var initV: ByteArray? = null
        var initA: ByteArray? = null
        var fails = 0
        try {
            while (running) {
                try {
                    if (media == null) {
                        log("Looking for the live stream…")
                        try {
                            val r = Bins.resolve(url, log)
                            media = Hls.mediaUrl(r.video)
                            audioMedia = r.audio?.let { Hls.mediaUrl(it) }
                        } catch (e: Exception) {
                            log("Can't open stream (${e.message?.take(80)}). Retrying in 30s")
                            Thread.sleep(30_000)
                            continue
                        }
                        lastSeq = -1L
                        initV = null
                        initA = null
                        log(if (audioMedia != null) "Live (video + audio streams). Watching…" else "Live. Watching…")
                    }
                    val plV = Hls.parse(media)
                    val plA = audioMedia?.let { Hls.parse(it) }
                    fails = 0
                    if (plV.ended) {
                        log("Stream ended")
                        break
                    }
                    if (plV.mapUri != null && initV == null) initV = Hls.get(plV.mapUri)
                    val am = plA?.mapUri
                    if (am != null && initA == null) initA = Hls.get(am)

                    // Video and audio playlists normally share sequence numbers; if they don't, align the live edges.
                    val shift = if (plA == null || plA.segs.isEmpty() || plV.segs.isEmpty()) {
                        0L
                    } else {
                        val aSeqs = plA.segs.map { it.seq }.toSet()
                        if (plV.segs.any { it.seq in aSeqs }) 0L
                        else plA.segs.last().seq - plV.segs.last().seq
                    }

                    var fresh = plV.segs.filter { it.seq > lastSeq }
                    if (lastSeq < 0) fresh = fresh.takeLast(3)
                    for (s in fresh) {
                        if (!running) break
                        var sa: Seg? = null
                        if (plA != null) {
                            sa = plA.segs.firstOrNull { it.seq == s.seq + shift }
                            if (sa == null) break // audio segment not published yet, retry next poll
                        }
                        val fv = File(buf, "${s.seq}.ts")
                        val dv = Hls.get(s.uri)
                        fv.outputStream().use { o ->
                            initV?.let { o.write(it) }
                            o.write(dv)
                        }
                        var fa: File? = null
                        if (sa != null) {
                            val file = File(buf, "${s.seq}a.ts")
                            val da = Hls.get(sa.uri)
                            file.outputStream().use { o ->
                                initA?.let { o.write(it) }
                                o.write(da)
                            }
                            fa = file
                        }
                        lastSeq = s.seq
                        val rec = Rec(fv, fa, streamEnd, s.dur)
                        streamEnd += s.dur
                        timeline += rec
                        analyse(rec)
                    }
                    launchReady()
                    cleanup()
                    Thread.sleep(((plV.target / 2) * 1000).toLong().coerceIn(700L, 3000L))
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    fails++
                    log("Stream hiccup: ${e.message?.take(80)}")
                    if (fails >= 4) {
                        media = null
                        audioMedia = null
                        fails = 0
                    }
                    Thread.sleep(3000)
                }
            }
        } catch (_: InterruptedException) {
        } finally {
            buf.deleteRecursively()
        }
    }

    private fun zscore(db: Double): Double {
        if (hist.size < 20) return 0.0
        val mean = hist.average()
        var v = 0.0
        for (x in hist) v += (x - mean) * (x - mean)
        val sd = max(sqrt(v / hist.size), 1.5)
        return (db - mean) / sd
    }

    private fun analyse(rec: Rec) {
        val src = rec.audio ?: rec.file
        val pcm = Bins.bytes(
            listOf(
                "-loglevel", "error", "-i", src.absolutePath,
                "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-",
            )
        )
        val samples = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val win = 8000 // 0.5 s at 16 kHz
        val total = pcm.size / 2
        var w = 0
        while ((w + 1) * win <= total) {
            var sum = 0.0
            for (i in w * win until (w + 1) * win) {
                val v = samples.get(i) / 32768.0
                sum += v * v
            }
            val db = max(20 * log10(sqrt(sum / win) + 1e-9), -90.0)
            recent.addLast(zscore(db))
            if (recent.size > 3) recent.removeFirst()
            hist.addLast(db)
            if (hist.size > 240) hist.removeFirst()

            val score = recent.average()
            val t = rec.start + w * 0.5
            if (score >= cfg.thr && t - lastTrig > cfg.cooldown) {
                lastTrig = t
                pending += t
                log("Hype spike (score ${"%.1f".format(Locale.US, score)}), cutting after ${cfg.post}s")
            }
            w++
        }
    }

    private fun launchReady() {
        val it = pending.iterator()
        while (it.hasNext()) {
            val t = it.next()
            if (streamEnd >= t + cfg.post) {
                it.remove()
                cutClip(t)
            }
        }
    }

    private fun cutClip(t: Double) {
        val chosen = timeline.filter { it.start + it.dur > t - cfg.pre && it.start < t + cfg.post }
        if (chosen.isEmpty()) return
        val n = ++clips
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val hasAudio = chosen.all { it.audio != null }
        val listV = File(buf, "clip${n}v.txt")
        listV.writeText(chosen.joinToString("\n") { "file '${it.file.absolutePath}'" } + "\n")
        val listA = File(buf, "clip${n}a.txt")
        if (hasAudio) {
            listA.writeText(chosen.joinToString("\n") { "file '${it.audio!!.absolutePath}'" } + "\n")
        }
        val raw = File(ctx.cacheDir, "raw_${stamp}_s${id}_$n.mp4")

        fun cut(bsf: Boolean): Int {
            val a = ArrayList<String>(
                listOf("-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", listV.absolutePath)
            )
            if (hasAudio) {
                a += listOf("-f", "concat", "-safe", "0", "-i", listA.absolutePath, "-map", "0:v:0", "-map", "1:a:0")
            }
            a += listOf("-c", "copy")
            if (bsf) a += listOf("-bsf:a", "aac_adtstoasc")
            a += listOf("-movflags", "+faststart", raw.absolutePath)
            return Bins.run(a).first
        }
        var code = cut(true)
        if (code != 0) code = cut(false) // fMP4 audio is already in MP4 form
        listV.delete()
        listA.delete()
        if (code != 0 || !raw.exists()) {
            log("Clip $n: cutting failed")
            return
        }
        log("Clip $n cut, editing to 9:16…")
        submit(raw) {
            try {
                Editor.process(ctx, raw, url, cfg, "clip_${stamp}_s${id}_$n", log)
            } catch (e: Throwable) {
                log("Clip $n edit failed: ${e.message?.take(120)}")
            }
        }
    }

    private fun cleanup() {
        var keepFrom = streamEnd - (cfg.pre + cfg.post + 30)
        pending.minOrNull()?.let { keepFrom = minOf(keepFrom, it - cfg.pre - 4) }
        val iter = timeline.iterator()
        while (iter.hasNext()) {
            val r = iter.next()
            if (r.start + r.dur < keepFrom) {
                r.file.delete()
                r.audio?.delete()
                iter.remove()
            }
        }
    }
}
