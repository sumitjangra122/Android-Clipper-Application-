package app.streamclipper

import android.content.Context
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

class Config(
    val thr: Double,
    val pre: Int,
    val post: Int,
    val cooldown: Int,
    val keepRaw: Boolean,
    val camPos: String,
)

/**
 * Downloads the live HLS stream segment by segment into a rolling buffer, scores audio
 * loudness against the stream's own recent baseline, and cuts + edits a clip on spikes.
 */
class Watcher(
    private val ctx: Context,
    private val url: String,
    private val cfg: Config,
    private val log: (String) -> Unit,
) {
    @Volatile
    var running = true

    private class Rec(val file: File, val start: Double, val dur: Double)

    private val buf = File(ctx.cacheDir, "buf").apply { deleteRecursively(); mkdirs() }
    private val timeline = ArrayList<Rec>()
    private val pending = ArrayList<Double>()          // trigger times, stream seconds
    private val encoder = Executors.newSingleThreadExecutor()
    private val hist = ArrayDeque<Double>()            // dB history (~2 min)
    private val recent = ArrayDeque<Double>()          // last 3 z-scores
    private var lastTrig = -1e9
    private var streamEnd = 0.0
    private var clips = 0

    fun run() {
        var media: String? = null
        var lastSeq = -1L
        var initBytes: ByteArray? = null
        var fails = 0
        try {
            while (running) {
                try {
                    if (media == null) {
                        log("Looking for the live stream…")
                        try {
                            media = Hls.mediaUrl(Bins.resolve(url))
                        } catch (e: Exception) {
                            log("Can't open stream (${e.message?.take(80)}). Retrying in 30s")
                            Thread.sleep(30_000)
                            continue
                        }
                        lastSeq = -1L
                        initBytes = null
                        log("Live. Watching for hype moments…")
                    }
                    val pl = Hls.parse(media)
                    fails = 0
                    if (pl.ended) {
                        log("Stream ended")
                        break
                    }
                    if (pl.mapUri != null && initBytes == null) initBytes = Hls.get(pl.mapUri)

                    var fresh = pl.segs.filter { it.seq > lastSeq }
                    if (lastSeq < 0) fresh = fresh.takeLast(3)
                    for (s in fresh) {
                        if (!running) break
                        val f = File(buf, "${s.seq}.ts")
                        val data = Hls.get(s.uri)
                        f.outputStream().use { o ->
                            initBytes?.let { o.write(it) }
                            o.write(data)
                        }
                        lastSeq = s.seq
                        val rec = Rec(f, streamEnd, s.dur)
                        streamEnd += s.dur
                        timeline += rec
                        analyse(rec)
                    }
                    launchReady()
                    cleanup()
                    Thread.sleep(((pl.target / 2) * 1000).toLong().coerceIn(700L, 3000L))
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    fails++
                    log("Stream hiccup: ${e.message?.take(80)}")
                    if (fails >= 4) {
                        media = null
                        fails = 0
                    }
                    Thread.sleep(3000)
                }
            }
        } catch (_: InterruptedException) {
        } finally {
            encoder.shutdown()
            try {
                log("Finishing pending edits…")
                encoder.awaitTermination(10, TimeUnit.MINUTES)
            } catch (_: InterruptedException) {
            }
            buf.deleteRecursively()
        }
    }

    private fun zscore(db: Double): Double {
        if (hist.size < 20) return 0.0
        val mean = hist.average()
        var v = 0.0
        for (x in hist) v += (x - mean) * (x - mean)
        val sd = max(sqrt(v / hist.size), 1.5)
        return (db - mean) / sd
    }

    private fun analyse(rec: Rec) {
        val pcm = Bins.bytes(
            listOf(
                "-loglevel", "error", "-i", rec.file.absolutePath,
                "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-",
            )
        )
        val samples = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val win = 8000 // 0.5 s at 16 kHz
        val total = pcm.size / 2
        var w = 0
        while ((w + 1) * win <= total) {
            var sum = 0.0
            for (i in w * win until (w + 1) * win) {
                val v = samples.get(i) / 32768.0
                sum += v * v
            }
            val db = max(20 * log10(sqrt(sum / win) + 1e-9), -90.0)
            recent.addLast(zscore(db))
            if (recent.size > 3) recent.removeFirst()
            hist.addLast(db)
            if (hist.size > 240) hist.removeFirst()

            val score = recent.average()
            val t = rec.start + w * 0.5
            if (score >= cfg.thr && t - lastTrig > cfg.cooldown) {
                lastTrig = t
                pending += t
                log("Hype spike (score ${"%.1f".format(Locale.US, score)}), cutting after ${cfg.post}s")
            }
            w++
        }
    }

    private fun launchReady() {
        val it = pending.iterator()
        while (it.hasNext()) {
            val t = it.next()
            if (streamEnd >= t + cfg.post) {
                it.remove()
                cutClip(t)
            }
        }
    }

    private fun cutClip(t: Double) {
        val chosen = timeline.filter { it.start + it.dur > t - cfg.pre && it.start < t + cfg.post }
        if (chosen.isEmpty()) return
        val n = ++clips
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val list = File(buf, "clip$n.txt")
        list.writeText(chosen.joinToString("\n") { "file '${it.file.absolutePath}'" } + "\n")
        val raw = File(ctx.cacheDir, "raw_${stamp}_$n.mp4")

        fun cut(bsf: Boolean): Int {
            val a = ArrayList(
                listOf("-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", list.absolutePath, "-c", "copy")
            )
            if (bsf) a += listOf("-bsf:a", "aac_adtstoasc")
            a += listOf("-movflags", "+faststart", raw.absolutePath)
            return Bins.run(a).first
        }
        var code = cut(true)
        if (code != 0) code = cut(false) // fMP4 audio is already in MP4 form
        list.delete()
        if (code != 0 || !raw.exists()) {
            log("Clip $n: cutting failed")
            return
        }
        log("Clip $n cut, editing to 9:16…")
        encoder.execute {
            try {
                Editor.process(ctx, raw, url, cfg, "clip_${stamp}_$n", log)
            } catch (e: Throwable) {
                log("Clip $n edit failed: ${e.message?.take(120)}")
            } finally {
                raw.delete()
            }
        }
    }

    private fun cleanup() {
        var keepFrom = streamEnd - (cfg.pre + cfg.post + 30)
        pending.minOrNull()?.let { keepFrom = minOf(keepFrom, it - cfg.pre - 4) }
        val iter = timeline.iterator()
        while (iter.hasNext()) {
            val r = iter.next()
            if (r.start + r.dur < keepFrom) {
                r.file.delete()
                iter.remove()
            }
        }
    }
}
