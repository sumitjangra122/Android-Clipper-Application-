package app.streamclipper

import android.content.Context
import android.media.MediaMetadataRetriever
import java.io.File
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Turns a raw 16:9 clip into a 1080x1920 short. Every layout decision is automatic. */
object Editor {
    private const val W = 1080
    private const val H = 1920
    private const val GAME_CROP = 0.62   // share of the frame width kept for gameplay

    private fun f2(x: Double) = String.format(Locale.US, "%.2f", x)

    fun process(ctx: Context, raw: File, url: String, cfg: Config, name: String, log: (String) -> Unit) {
        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(raw.absolutePath)
        val vw = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
        val vh = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
        val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong() / 1000.0
        mmr.release()

        val key = "cam_" + url.trim().lowercase().hashCode()
        val a = AutoLayout.analyse(raw, vw, vh, AutoLayout.loadFace(ctx, key))
        val face = a.face
        if (a.fresh && face != null) AutoLayout.saveFace(ctx, key, face)

        val fc: String
        when {
            // Face fills the frame (just chatting / IRL): follow it with a 9:16 crop.
            face != null && face.width() > 0.28f -> {
                log("Layout: full-frame face follow")
                val cw = min((vh * 9 / 16) / 2 * 2, vw)
                val cx = (face.centerX() * vw - cw / 2).toInt().coerceIn(0, vw - cw)
                fc = "[0:v]crop=$cw:$vh:$cx:0,scale=$W:$H,setsar=1[stk]"
            }
            // Separate facecam overlay: facecam on one half, gameplay on the other.
            face != null -> {
                val gw = (vw * GAME_CROP).toInt() / 2 * 2
                val c = (0.65 * a.motionX + 0.35 * 0.5)
                val pan = ((c - GAME_CROP / 2) / (1 - GAME_CROP)).coerceIn(0.0, 1.0)
                val gx = ((vw - gw) * pan).toInt()
                val gameH = (W.toDouble() * vh / gw).toInt().coerceIn(700, 1300) / 2 * 2
                val camH = H - gameH

                val aspect = W.toDouble() / camH
                val fw = face.width() * vw
                val fh = face.height() * vh
                var rw = fw * 2.3
                var rh = rw / aspect
                if (rh < fh * 1.7) { rh = fh * 1.7; rw = rh * aspect }
                if (rw > vw) { rw = vw.toDouble(); rh = rw / aspect }
                if (rh > vh) { rh = vh.toDouble(); rw = rh * aspect }
                val crw = (rw.toInt() / 2 * 2).coerceAtLeast(2)
                val crh = (rh.toInt() / 2 * 2).coerceAtLeast(2)
                val cx = (face.centerX() * vw - crw / 2.0).toInt().coerceIn(0, max(vw - crw, 0))
                val cy = (face.centerY() * vh - crh * 0.45).toInt().coerceIn(0, max(vh - crh, 0))

                val camTop = cfg.camPos != "bottom"   // "auto" puts the cam on top (app UI covers the bottom)
                val top = if (camTop) "cam" else "game"
                val bot = if (camTop) "game" else "cam"
                val boundary = if (camTop) camH else gameH
                log("Layout: facecam + gameplay (cam ${if (camTop) "top" else "bottom"}, pan ${f2(pan)})")
                fc = "[0:v]split=2[c0][g0];" +
                    "[c0]crop=$crw:$crh:$cx:$cy,scale=$W:$camH,setsar=1[cam];" +
                    "[g0]crop=$gw:ih:$gx:0,scale=$W:$gameH,setsar=1[game];" +
                    "[$top][$bot]vstack=inputs=2," +
                    "drawbox=x=0:y=${boundary - 4}:w=$W:h=8:color=0xFF2E63:t=fill[stk]"
            }
            // No facecam found: gameplay centred over a blurred, zoomed copy of itself.
            else -> {
                log("Layout: no facecam, blurred background")
                fc = "[0:v]split=2[a][b];" +
                    "[a]scale=$W:$H:force_original_aspect_ratio=increase,crop=$W:$H," +
                    "boxblur=40:6,eq=brightness=-0.08[bg];" +
                    "[b]scale=$W:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2[stk]"
            }
        }

        val fadeOut = f2(max(dur - 0.5, 0.0))
        val graph = "$fc;[stk]eq=contrast=1.06:saturation=1.18:brightness=0.01,unsharp=5:5:0.7," +
            "fade=t=in:st=0:d=0.3,fade=t=out:st=$fadeOut:d=0.5,format=yuv420p[v]"
        val vcodec = if (Bins.encoder == "libx264")
            listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "21")
        else
            listOf("-c:v", "mpeg4", "-q:v", "3")

        val out = File(ctx.cacheDir, "$name-vertical.mp4")
        val args = listOf(
            "-loglevel", "error", "-y", "-i", raw.absolutePath,
            "-filter_complex", graph, "-map", "[v]", "-map", "0:a:0?",
            "-af", "loudnorm=I=-14:TP=-1.5:LRA=11,afade=t=in:st=0:d=0.2,afade=t=out:st=$fadeOut:d=0.5",
        ) + vcodec + listOf("-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", out.absolutePath)

        val r = Bins.run(args)
        if (r.first != 0 || !out.exists()) {
            throw IllegalStateException(r.second.lines().lastOrNull { it.isNotBlank() } ?: "ffmpeg failed")
        }
        Store.saveVideo(ctx, out, "$name-vertical.mp4")
        if (cfg.keepRaw) Store.saveVideo(ctx, raw, "$name.mp4")
        out.delete()
        log("Saved $name-vertical.mp4 to Movies/StreamClipper")
    }
}
