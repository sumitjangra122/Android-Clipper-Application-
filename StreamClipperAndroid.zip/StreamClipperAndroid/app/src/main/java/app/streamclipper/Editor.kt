package app.streamclipper

import android.content.Context
import android.media.MediaMetadataRetriever
import java.io.File
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Turns a raw 16:9 clip into a vertical short (1080x1920 or 1440x2560 "2K").
 * Every layout decision is automatic, and it can change scene by scene inside one clip.
 */
object Editor {
    private const val GAME_CROP = 0.62   // share of the frame width kept for gameplay

    private fun f2(x: Double) = String.format(Locale.US, "%.2f", x)
    private fun f3(x: Double) = String.format(Locale.US, "%.3f", x)

    fun process(ctx: Context, raw: File, url: String, cfg: Config, name: String, log: (String) -> Unit) {
        val W = cfg.outW
        val H = cfg.outH
        val k = W / 1080.0

        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(raw.absolutePath)
        val vw = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
        val vh = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
        val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong() / 1000.0
        mmr.release()

        val key = "cam_" + url.trim().lowercase().hashCode()
        val a = try {
            AutoLayout.analyse(ctx, raw, vw, vh, dur, AutoLayout.loadFace(ctx, key), log)
        } catch (e: Exception) {
            log("Layout analysis failed (${e.message?.take(80)}), using a simple layout")
            AutoLayout.Result(listOf(Scene(0.0, dur, Kind.BLUR, null)), 0.5, null)
        }
        a.cacheFace?.let { AutoLayout.saveFace(ctx, key, it) }

        // Shared geometry for the gameplay half.
        val gw = (vw * GAME_CROP).toInt() / 2 * 2
        val c = 0.65 * a.motionX + 0.35 * 0.5
        val pan = ((c - GAME_CROP / 2) / (1 - GAME_CROP)).coerceIn(0.0, 1.0)
        val gx = ((vw - gw) * pan).toInt()
        val gameH = (W.toDouble() * vh / gw).toInt()
            .coerceIn((700 * k).toInt(), (1300 * k).toInt()) / 2 * 2
        val camH = H - gameH
        val bar = max(2, (8 * k).toInt() / 2 * 2)
        val camTop = cfg.camPos != "bottom"   // "auto" puts the cam on top (app UI covers the bottom)

        val n = a.segs.size
        val parts = ArrayList<String>()
        for ((i, s) in a.segs.withIndex()) {
            val pre = if (n > 1)
                "[s$i]trim=start=${f3(s.start)}:end=${f3(if (i == n - 1) s.end + 5 else s.end)},setpts=PTS-STARTPTS,"
            else "[0:v]"
            val out = if (n > 1) "o$i" else "stk"
            val face = s.face
            parts += when {
                // Full-screen cam scene: follow the face with a 9:16 crop.
                s.kind == Kind.FACE && face != null -> {
                    val cw = min((vh * 9 / 16) / 2 * 2, vw)
                    val cx = (face.cx * vw - cw / 2).toInt().coerceIn(0, vw - cw)
                    "${pre}crop=$cw:$vh:$cx:0,scale=$W:$H,setsar=1,format=yuv420p[$out]"
                }
                // Facecam overlay: sized for THIS scene's face, facecam on one half, gameplay on the other.
                s.kind == Kind.STACK && face != null -> {
                    val aspect = W.toDouble() / camH
                    val fw = face.w * vw
                    val fh = face.h * vh
                    var rw = fw * 2.3
                    var rh = rw / aspect
                    if (rh < fh * 1.7) { rh = fh * 1.7; rw = rh * aspect }
                    if (rw > vw) { rw = vw.toDouble(); rh = rw / aspect }
                    if (rh > vh) { rh = vh.toDouble(); rw = rh * aspect }
                    val crw = (rw.toInt() / 2 * 2).coerceAtLeast(2)
                    val crh = (rh.toInt() / 2 * 2).coerceAtLeast(2)
                    val cx = (face.cx * vw - crw / 2.0).toInt().coerceIn(0, max(vw - crw, 0))
                    val cy = (face.cy * vh - crh * 0.45).toInt().coerceIn(0, max(vh - crh, 0))
                    val top = if (camTop) "cam$i" else "game$i"
                    val bot = if (camTop) "game$i" else "cam$i"
                    val boundary = if (camTop) camH else gameH
                    "${pre}split=2[c$i][g$i];" +
                        "[c$i]crop=$crw:$crh:$cx:$cy,scale=$W:$camH,setsar=1[cam$i];" +
                        "[g$i]crop=$gw:ih:$gx:0,scale=$W:$gameH,setsar=1[game$i];" +
                        "[$top][$bot]vstack=inputs=2," +
                        "drawbox=x=0:y=${boundary - bar / 2}:w=$W:h=$bar:color=0xFF2E63:t=fill,setsar=1,format=yuv420p[$out]"
                }
                // No cam in this scene (gameplay, banner): gameplay centred over a blurred copy of itself.
                else -> "${pre}split=2[a$i][b$i];" +
                    "[a$i]scale=$W:$H:force_original_aspect_ratio=increase,crop=$W:$H," +
                    "boxblur=${(40 * k).toInt()}:6,eq=brightness=-0.08[bg$i];" +
                    "[b$i]crop=$gw:ih:$gx:0,scale=$W:$gameH,setsar=1[fg$i];" +
                    "[bg$i][fg$i]overlay=(W-w)/2:(H-h)/2,setsar=1,format=yuv420p[$out]"
            }
        }
        val fc = if (n == 1) parts[0] else
            "[0:v]split=$n" + (0 until n).joinToString("") { "[s$it]" } + ";" +
                parts.joinToString(";") + ";" +
                (0 until n).joinToString("") { "[o$it]" } + "concat=n=$n:v=1:a=0[stk]"
        log(
            "Layout ${W}x$H: " + a.segs.joinToString(", ") {
                "${it.kind.name.lowercase()} ${String.format(Locale.US, "%.1f", it.start)}-${String.format(Locale.US, "%.1f", it.end)}s"
            }
        )

        val fadeOut = f2(max(dur - 0.5, 0.0))
        val graph = "$fc;[stk]eq=contrast=1.06:saturation=1.18:brightness=0.01,unsharp=5:5:0.7," +
            "fade=t=in:st=0:d=0.3,fade=t=out:st=$fadeOut:d=0.5,format=yuv420p[v]"

        // Keep 60 fps only if asked; otherwise 30 keeps phone encoding times sane.
        val probe = Bins.run(listOf("-hide_banner", "-i", raw.absolutePath)).second
        val srcFps = Regex("(\\d+(?:\\.\\d+)?) fps").find(probe)?.groupValues?.get(1)?.toDoubleOrNull() ?: 30.0
        val rate = if (srcFps > 31 && !cfg.keep60) listOf("-r", "30") else emptyList()

        val hi = H >= 2560
        val vcodec = if (Bins.encoder == "libx264")
            listOf(
                "-c:v", "libx264", "-preset", "veryfast", "-crf", if (hi) "19" else "20",
                "-maxrate", if (hi) "18M" else "12M", "-bufsize", if (hi) "36M" else "24M",
            )
        else
            listOf("-c:v", "mpeg4", "-q:v", "2")

        val out = File(ctx.cacheDir, "$name-vertical.mp4")
        val args = listOf(
            "-loglevel", "error", "-y", "-i", raw.absolutePath,
            "-filter_complex", graph, "-map", "[v]", "-map", "0:a:0?",
            "-af", "loudnorm=I=-14:TP=-1.5:LRA=11,afade=t=in:st=0:d=0.2,afade=t=out:st=$fadeOut:d=0.5",
        ) + rate + vcodec + listOf("-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out.absolutePath)

        val r = Bins.run(args)
        if (r.first != 0 || !out.exists()) {
            throw IllegalStateException(r.second.lines().lastOrNull { it.isNotBlank() } ?: "ffmpeg failed")
        }
        Store.saveVideo(ctx, out, "$name-vertical.mp4")
        if (cfg.keepRaw) Store.saveVideo(ctx, raw, "$name.mp4")
        out.delete()
        log("Saved $name-vertical.mp4 (${W}x$H) to ${Store.where(ctx)}")
    }
}
