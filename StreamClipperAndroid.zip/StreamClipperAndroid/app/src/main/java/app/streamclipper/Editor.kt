package app.streamclipper

import android.content.Context
import android.media.MediaMetadataRetriever
import java.io.File
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Turns a raw 16:9 clip into a vertical short (1080x1920 or 1440x2560 "2K").
 * Every layout decision is automatic, and it can change scene by scene inside one clip.
 */
object Editor {
    private const val GAME_CROP = 0.62   // share of the frame width kept for gameplay

    private fun f2(x: Double) = String.format(Locale.US, "%.2f", x)
    private fun f3(x: Double) = String.format(Locale.US, "%.3f", x)

    /**
     * @param input the raw clip or the source video
     * @param ss where the clip starts inside [input], in seconds (accurate, not snapped to a keyframe)
     * @param len how long the clip is, in seconds
     */
    fun process(ctx: Context, input: File, ss: Double, len: Double, url: String, cfg: Config, name: String, log: (String) -> Unit) {
        val W = cfg.outW
        val H = cfg.outH
        val k = W / 1080.0

        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(input.absolutePath)
        val vw = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
        val vh = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
        val dur = len
        mmr.release()

        val key = "cam_" + url.trim().lowercase().hashCode()
        val a = try {
            AutoLayout.analyse(
                ctx, input, ss, dur, vw, vh, AutoLayout.loadFace(ctx, key),
                if (cfg.useCam) AutoLayout.loadRegion(ctx, url) else null, cfg.useCam, log
            )
        } catch (e: Exception) {
            log("Layout analysis failed (${e.message?.take(80)}), using a simple layout")
            AutoLayout.Result(listOf(Scene(0.0, dur, Kind.BLUR, null)), 0.5, null)
        }
        a.cacheFace?.let { AutoLayout.saveFace(ctx, key, it) }

        // Shared geometry for the gameplay half.
        // Videos without a facecam keep a wider view so people at the edges aren't cut off.
        val cropFrac = if (cfg.useCam) GAME_CROP else 0.75
        val gw = (vw * cropFrac).toInt() / 2 * 2
        val c = 0.65 * a.motionX + 0.35 * 0.5
        val pan = ((c - cropFrac / 2) / (1 - cropFrac)).coerceIn(0.0, 1.0)
        val gx = ((vw - gw) * pan).toInt()
        val gameH = (W.toDouble() * vh / gw).toInt()
            .coerceIn((700 * k).toInt(), (1300 * k).toInt()) / 2 * 2
        val camH = H - gameH
        val bar = max(2, (8 * k).toInt() / 2 * 2)
        val camTop = cfg.camPos != "bottom"   // "auto" puts the cam on top (app UI covers the bottom)

        val n = a.segs.size
        val parts = ArrayList<String>()
        for ((i, s) in a.segs.withIndex()) {
            val pre = if (n > 1)
                "[s$i]trim=start=${f3(s.start)}:end=${f3(if (i == n - 1) s.end + 5 else s.end)},setpts=PTS-STARTPTS,"
            else "[0:v]"
            val out = if (n > 1) "o$i" else "stk"
            val face = s.face
            parts += when {
                // Full-screen cam scene: follow the face with a 9:16 crop.
                s.kind == Kind.FACE && face != null -> {
                    val cw = min((vh * 9 / 16) / 2 * 2, vw)
                    val cx = (face.cx * vw - cw / 2).toInt().coerceIn(0, vw - cw)
                    "${pre}crop=$cw:$vh:$cx:0,scale=$W:$H,setsar=1,format=yuv420p[$out]"
                }
                // Facecam overlay: sized for THIS scene's face, facecam on one half, gameplay on the other.
                s.kind == Kind.STACK && face != null -> {
                    val aspect = W.toDouble() / camH
                    val fw = (face.w * vw).toDouble()
                    val fh = (face.h * vh).toDouble()
                    var rw = if (face.manual) fw else fw * 2.3
                    var rh = rw / aspect
                    if (face.manual) {
                        if (rh < fh) { rh = fh; rw = rh * aspect }   // keep the whole marked area
                    } else if (rh < fh * 1.7) {
                        rh = fh * 1.7; rw = rh * aspect
                    }
                    if (rw > vw) { rw = vw.toDouble(); rh = rw / aspect }
                    if (rh > vh) { rh = vh.toDouble(); rw = rh * aspect }
                    val crw = (rw.toInt() / 2 * 2).coerceAtLeast(2)
                    val crh = (rh.toInt() / 2 * 2).coerceAtLeast(2)
                    val cx = (face.cx * vw - crw / 2.0).toInt().coerceIn(0, max(vw - crw, 0))
                    val cy = (face.cy * vh - crh * (if (face.manual) 0.5 else 0.45)).toInt().coerceIn(0, max(vh - crh, 0))
                    val top = if (camTop) "cam$i" else "game$i"
                    val bot = if (camTop) "game$i" else "cam$i"
                    val boundary = if (camTop) camH else gameH
                    "${pre}split=2[c$i][g$i];" +
                        "[c$i]crop=$crw:$crh:$cx:$cy,scale=$W:$camH,setsar=1[cam$i];" +
                        "[g$i]crop=$gw:ih:$gx:0,scale=$W:$gameH,setsar=1[game$i];" +
                        "[$top][$bot]vstack=inputs=2," +
                        "drawbox=x=0:y=${boundary - bar / 2}:w=$W:h=$bar:color=0xFF2E63:t=fill,setsar=1,format=yuv420p[$out]"
                }
                // No cam in this scene (gameplay, banner): gameplay centred over a blurred copy of itself.
                else -> "${pre}split=2[a$i][b$i];" +
                    "[a$i]scale=${W / 6}:${H / 6 / 2 * 2}:force_original_aspect_ratio=increase,crop=${W / 6}:${H / 6 / 2 * 2}," +
                    "boxblur=6:2,scale=$W:$H,eq=brightness=-0.08[bg$i];" +
                    "[b$i]crop=$gw:ih:$gx:0,scale=$W:$gameH,setsar=1[fg$i];" +
                    "[bg$i][fg$i]overlay=(W-w)/2:(H-h)/2,setsar=1,format=yuv420p[$out]"
            }
        }
        val fc = if (n == 1) parts[0] else
            "[0:v]split=$n" + (0 until n).joinToString("") { "[s$it]" } + ";" +
                parts.joinToString(";") + ";" +
                (0 until n).joinToString("") { "[o$it]" } + "concat=n=$n:v=1:a=0[stk]"
        log(
            "Layout ${W}x$H: " + a.segs.joinToString(", ") {
                "${it.kind.name.lowercase()} ${String.format(Locale.US, "%.1f", it.start)}-${String.format(Locale.US, "%.1f", it.end)}s"
            }
        )

        // Cool mode: wait while the phone is hot, then encode with lighter settings.
        val level = if (cfg.cool) Thermal.coolDown(ctx, log) else 0
        val light = cfg.cool || level >= 1

        // Captions (optional): offline speech-to-text, then burned in as styled subtitles.
        var capFilter = ""
        var capFile: File? = null
        if (cfg.captions) {
            try {
                val words = Transcriber.words(ctx, input, ss, len, cfg.capLang, log)
                if (words.isEmpty()) {
                    log("Captions: no speech found in this clip")
                } else {
                    val f = File(ctx.cacheDir, "$name.ass")
                    f.writeText(Captions.build(words, CapStyle.of(cfg.capStyle), cfg.capLang == 2, W, H))
                    capFile = f
                    capFilter = "ass='${f.absolutePath}':fontsdir='${Transcriber.fontsDir(ctx).absolutePath}',"
                    log("Captions: ${words.size} words (${Transcriber.langName(cfg.capLang)}, ${CapStyle.of(cfg.capStyle).label})")
                }
            } catch (e: Throwable) {
                log("Captions skipped: ${e.message?.take(90)}")
            }
        }

        val fadeOut = f2(max(dur - 0.5, 0.0))
        val sharpen = if (light) "" else "unsharp=5:5:0.7,"   // sharpening a 2K frame is expensive
        fun makeGraph(caps: String) = "$fc;[stk]eq=contrast=1.06:saturation=1.18:brightness=0.01,$sharpen" +
            caps + "fade=t=in:st=0:d=0.3,fade=t=out:st=$fadeOut:d=0.5,format=yuv420p[v]"

        // Keep 60 fps only if asked; otherwise 30 keeps phone encoding times sane.
        val probe = Bins.run(listOf("-hide_banner", "-i", input.absolutePath)).second
        val srcFps = Regex("(\\d+(?:\\.\\d+)?) fps").find(probe)?.groupValues?.get(1)?.toDoubleOrNull() ?: 30.0
        val rate = if (srcFps > 31 && !cfg.keep60) listOf("-r", "30") else emptyList()

        val hi = H >= 2560
        val preset = when {
            level >= 2 -> "ultrafast"
            light -> "superfast"
            else -> "veryfast"
        }
        val threads = when {
            level >= 2 -> "2"
            light -> "4"
            else -> "0"
        }
        val vcodec = if (Bins.encoder == "libx264")
            listOf(
                "-c:v", "libx264", "-preset", preset, "-crf", if (hi) "20" else "21",
                "-maxrate", if (hi) "18M" else "12M", "-bufsize", if (hi) "36M" else "24M",
                "-threads", threads,
            )
        else
            listOf("-c:v", "mpeg4", "-q:v", "2")

        val out = File(ctx.cacheDir, "$name-vertical.mp4")
        fun argsFor(graph: String) = listOf(
            "-loglevel", "error", "-y",
            "-ss", String.format(Locale.US, "%.3f", ss), "-t", String.format(Locale.US, "%.3f", len),
            "-i", input.absolutePath,
            "-filter_complex", graph, "-map", "[v]", "-map", "0:a:0?",
            "-af", "loudnorm=I=-14:TP=-1.5:LRA=11,afade=t=in:st=0:d=0.2,afade=t=out:st=$fadeOut:d=0.5",
        ) + rate + vcodec + listOf("-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out.absolutePath)

        var r = Bins.run(argsFor(makeGraph(capFilter)))
        if ((r.first != 0 || !out.exists()) && capFile != null) {
            log("Captions couldn't be drawn, saving the clip without them")
            r = Bins.run(argsFor(makeGraph("")))
        }
        capFile?.delete()
        if (r.first != 0 || !out.exists()) {
            throw IllegalStateException(r.second.lines().lastOrNull { it.isNotBlank() } ?: "ffmpeg failed")
        }
        Store.saveVideo(ctx, out, "$name-vertical.mp4")
        if (cfg.keepRaw) {
            // the plain full-frame clip, cut without re-encoding
            val plain = File(ctx.cacheDir, "$name-plain.mp4")
            val pr = Bins.run(
                listOf(
                    "-loglevel", "error", "-y", "-ss", String.format(Locale.US, "%.3f", ss),
                    "-t", String.format(Locale.US, "%.3f", len), "-i", input.absolutePath,
                    "-c", "copy", "-movflags", "+faststart", plain.absolutePath,
                )
            )
            if (pr.first == 0 && plain.exists()) Store.saveVideo(ctx, plain, "$name.mp4")
            plain.delete()
        }
        out.delete()
        log("Saved $name-vertical.mp4 (${W}x$H) to ${Store.where(ctx)}")
        if (light && Thermal.level(ctx) >= 1) Thread.sleep(8_000)   // let it breathe before the next edit
    }
}
