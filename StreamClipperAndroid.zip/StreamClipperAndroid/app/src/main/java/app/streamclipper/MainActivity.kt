package app.streamclipper

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import app.license.LicenseCodec
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    // ---- palette
    private val BG = 0xFF12121A.toInt()
    private val CARD = 0xFF1C1C28.toInt()
    private val CARD2 = 0xFF2A2A3C.toInt()
    private val ACCENT = 0xFFFF2E63.toInt()
    private val RED = 0xFFC62840.toInt()
    private val TEXT = 0xFFEDEDF5.toInt()
    private val MUTED = 0xFF9A9AB0.toInt()
    private val WHITE = 0xFFFFFFFF.toInt()

    private val pickVideoCode = 42
    private val pickFolderCode = 43
    private val pickCookiesCode = 44
    private lateinit var cookieStatus: TextView

    private lateinit var prefs: SharedPreferences
    private lateinit var content: FrameLayout
    private lateinit var navItems: List<TextView>
    private lateinit var pages: List<View>

    private lateinit var startBtn: Button
    private lateinit var statusLive: TextView
    private lateinit var statusVideo: TextView
    private lateinit var summaryLive: TextView
    private lateinit var summaryVideo: TextView
    private lateinit var pathText: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var sourceLabel: TextView
    private lateinit var vodBox: EditText
    private val liveBoxes = ArrayList<EditText>()
    private val camLabels = ArrayList<TextView>()
    private lateinit var applyBtn: Button
    private lateinit var runningText: TextView
    private lateinit var vodCamLabel: TextView

    private var camPos = "auto"
    private var keepRaw = false
    private var maxClips = 10
    private var clipLen = 30
    private var game = 0
    private var watchScreen = true
    private var cool = true
    private lateinit var lockView: View
    private lateinit var lockMsg: TextView
    private lateinit var lockErr: TextView
    private lateinit var lockKey: EditText
    private lateinit var lockCancel: Button
    private lateinit var accessText: TextView
    private var sens = 50
    private var outH = 2560
    private var srcMax = 0
    private var keep60 = false
    private var pickedUri: String? = null
    private var vodCam = true
    private var capOn = false
    private var capStyle = 1
    private var capLang = 0
    private lateinit var capStatus: TextView

    // ------------------------------------------------------------------ small UI helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun ripple(color: Int, r: Int): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), rounded(color, r), rounded(WHITE, r))

    private fun lp(topDp: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(topDp) }

    private fun heading(t: String) = TextView(this).apply {
        text = t; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(TEXT)
    }

    private fun muted(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(MUTED); setPadding(0, dp(4), 0, 0)
    }

    private fun card(vararg children: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 18)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        layoutParams = lp(12)
        children.forEach { addView(it) }
    }

    private fun page(vararg children: View) = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            children.forEach { addView(it) }
        })
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        setTextColor(if (primary) WHITE else TEXT)
        background = ripple(if (primary) ACCENT else CARD2, 14)
        stateListAnimator = null
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = lp(10)
        setOnClickListener { onClick() }
    }

    private fun field(hint: String, saved: String?, uri: Boolean = true) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(MUTED)
        setTextColor(TEXT)
        textSize = 15f
        setSingleLine()
        inputType = if (uri) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        else InputType.TYPE_CLASS_TEXT
        background = rounded(CARD2, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setText(saved ?: "")
        layoutParams = lp(8)
    }

    private fun segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(CARD2, 12)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = lp(8)
        }
        val views = ArrayList<TextView>()
        fun paint(sel: Int) {
            views.forEachIndexed { i, v ->
                v.background = if (i == sel) rounded(ACCENT, 10) else null
                v.setTextColor(if (i == sel) WHITE else MUTED)
            }
        }
        options.forEachIndexed { i, o ->
            val v = TextView(this).apply {
                text = o
                gravity = Gravity.CENTER
                textSize = 14f
                setPadding(0, dp(10), 0, dp(10))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { paint(i); onSelect(i) }
            }
            views += v
            row.addView(v)
        }
        paint(selected)
        return row
    }

    private fun smallButton(text: String, onClick: () -> Unit) = button(text, false, onClick).apply {
        textSize = 13f
        setPadding(dp(14), dp(8), dp(14), dp(8))
        layoutParams = LinearLayout.LayoutParams(-2, -2)
    }

    private fun openPicker(source: String, isUri: Boolean, title: String) {
        startActivity(
            Intent(this, FacecamPickerActivity::class.java)
                .putExtra("source", source).putExtra("isUri", isUri).putExtra("title", title)
        )
    }

    /** Sends the filled-in stream links to the service. Running streams that didn't change keep running. */
    private fun sendStreams() {
        val slots = ArrayList<Int>()
        val urls = ArrayList<String>()
        liveBoxes.forEachIndexed { i, b ->
            val t = b.text.toString().trim()
            if (t.isNotEmpty()) {
                slots.add(i + 1)
                urls.add(normalise(t))
            }
        }
        if (urls.isEmpty()) {
            toast(if (ClipService.watching) "Add a link, or tap Stop live watching" else "Paste at least one live stream link")
            return
        }
        val ed = prefs.edit()
        liveBoxes.forEachIndexed { i, b -> ed.putString("url${i + 1}", b.text.toString().trim()) }
        ed.apply()
        startForegroundService(
            intentFor(ClipService.ACTION_WATCH)
                .putStringArrayListExtra("urls", urls)
                .putIntegerArrayListExtra("slots", slots)
        )
        toast("Started. Progress shows below and in the Log tab")
        startBtn.postDelayed({ updateButton() }, 600)
    }

    private fun refreshCamLabels() {
        liveBoxes.forEachIndexed { i, b ->
            val t = b.text.toString().trim()
            camLabels[i].text = when {
                t.isEmpty() -> ""
                AutoLayout.loadRegion(this, normalise(t)) != null -> "Facecam: selected \u2713"
                else -> "Facecam: automatic"
            }
        }
        val picked = pickedUri
        val typed = vodBox.text.toString().trim()
        val src = picked ?: if (typed.isEmpty()) null else normalise(typed)
        vodCamLabel.text = when {
            !vodCam -> "Facecam: off. No cam is added to video clips"
            src == null -> ""
            AutoLayout.loadRegion(this, src) != null -> "Facecam: selected \u2713"
            else -> "Facecam: automatic"
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun normalise(u: String) = if (u.startsWith("http")) u else "https://$u"

    private fun parseTime(t: String): Double? {
        val parts = t.trim().split(":")
        if (parts.isEmpty() || parts.size > 3) return null
        var total = 0.0
        for (p in parts) {
            val v = p.trim().toDoubleOrNull() ?: return null
            if (v < 0) return null
            total = total * 60 + v
        }
        return total
    }

    private fun intentFor(action: String) =
        Intent(this, ClipService::class.java).setAction(action)
            .putExtra("thr", 4.5 - 0.03 * sens)
            .putExtra("camPos", camPos)
            .putExtra("keepRaw", keepRaw)
            .putExtra("maxClips", maxClips)
            .putExtra("clipLen", clipLen)
            .putExtra("game", game)
            .putExtra("watchScreen", watchScreen)
            .putExtra("cool", cool)
            .putExtra("outH", outH)
            .putExtra("srcMax", srcMax)
            .putExtra("keep60", keep60)

    private fun stopAll() {
        startService(Intent(this, ClipService::class.java).setAction(ClipService.ACTION_STOP))
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Store.prefs(this)
        camPos = prefs.getString("camPos", "auto") ?: "auto"
        keepRaw = prefs.getBoolean("keepRaw", false)
        maxClips = prefs.getInt("maxClips", 10)
        clipLen = prefs.getInt("clipLen", 30)
        game = prefs.getInt("game", 0)
        watchScreen = prefs.getBoolean("watchScreen", true)
        cool = prefs.getBoolean("cool", true)
        sens = prefs.getInt("sens", 50)
        outH = prefs.getInt("outH", 2560)
        vodCam = prefs.getBoolean("vodCam", true)
        capOn = prefs.getBoolean("capOn", false)
        capStyle = prefs.getInt("capStyle", 1)
        capLang = prefs.getInt("capLang", 0)
        srcMax = prefs.getInt("srcMax", 0)
        keep60 = prefs.getBoolean("keep60", false)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            fitsSystemWindows = true
        }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        pages = listOf(buildStreamsPage(), buildVideosPage(), buildSettingsPage(), buildLogPage())

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF181824.toInt())
        }
        val labels = listOf("📡\nStreams", "🎞\nVideos", "⚙\nSettings", "📜\nLog")
        navItems = labels.mapIndexed { i, l ->
            TextView(this).apply {
                text = l
                gravity = Gravity.CENTER
                textSize = 12f
                setPadding(0, dp(10), 0, dp(10))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { showTab(i) }
            }
        }
        navItems.forEach { nav.addView(it) }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))

        lockView = buildLock()
        lockView.visibility = View.GONE   // shown by refreshLock() when access is missing or has ended
        val host = FrameLayout(this)
        host.addView(root, FrameLayout.LayoutParams(-1, -1))
        host.addView(lockView, FrameLayout.LayoutParams(-1, -1))
        setContentView(host)
        showTab(0)
        License.refreshServerTime()
        refreshLock()
    }

    private fun showTab(i: Int) {
        content.removeAllViews()
        val p = pages[i]
        content.addView(p, FrameLayout.LayoutParams(-1, -1))
        p.alpha = 0f
        p.animate().alpha(1f).setDuration(150).start()
        navItems.forEachIndexed { idx, v ->
            v.setTextColor(if (idx == i) ACCENT else MUTED)
            v.setTypeface(null, if (idx == i) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    // ------------------------------------------------------------------ pages

    private fun buildStreamsPage(): View {
        val rows = (1..5).map { n ->
            val box = field("Stream $n: Kick / YouTube / Twitch link", prefs.getString("url$n", "")).also { liveBoxes += it }
            val label = muted("").apply { setPadding(0, 0, 0, 0) }
            camLabels += label
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = lp(4)
                addView(smallButton("Select facecam") {
                    val t = box.text.toString().trim()
                    if (t.isEmpty()) toast("Paste the stream link first") else openPicker(normalise(t), false, "Stream $n")
                })
                addView(label, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
            }
            box.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (camLabels.size == 5 && ::vodCamLabel.isInitialized && ::vodBox.isInitialized) refreshCamLabels()
                }
            })
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(box)
                addView(row)
            }
        }
        startBtn = button("Start watching", true) {
            if (ClipService.watching) {
                startService(Intent(this, ClipService::class.java).setAction(ClipService.ACTION_STOP_LIVE))
                startBtn.postDelayed({ updateButton() }, 600)
            } else {
                sendStreams()
            }
        }
        applyBtn = button("Add / update streams", false) { sendStreams() }
        applyBtn.visibility = View.GONE
        runningText = muted("")
        summaryLive = muted("")
        statusLive = muted("Idle")
        return page(
            heading("Live streams"),
            muted("Watch up to 5 streams at once. Highlights are clipped and edited to 9:16 automatically. Use Select facecam if it picks the wrong face."),
            card(*rows.toTypedArray()),
            summaryLive,
            startBtn,
            applyBtn,
            runningText,
            card(
                heading("Status"),
                statusLive,
                button("Clip now (test, from the last seconds)", false) {
                    startService(Intent(this, ClipService::class.java).setAction(ClipService.ACTION_CLIP_NOW))
                },
                button("Stop everything", false) { stopAll() },
            ),
        )
    }

    private fun buildVideosPage(): View {
        vodBox = field("Video link (YouTube video, Kick / Twitch VOD)", prefs.getString("vodurl", ""))
        sourceLabel = muted("No phone video picked. The link above will be used.")
        val clearPick = button("Use the link instead", false) {
            pickedUri = null
            sourceLabel.text = "No phone video picked. The link above will be used."
        }
        val pick = button("Pick a video from this phone", false) {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "video/*"
                },
                pickVideoCode
            )
        }
        val auto = button("Find the best moments", true) { startVideoJob(false, "", "") }
        val startBox = field("Start, e.g. 5:00 or 1:02:30", "", uri = false)
        val endBox = field("End, e.g. 5:30 (empty = clip length)", "", uri = false)
        val manual = button("Cut this time range", true) {
            startVideoJob(true, startBox.text.toString(), endBox.text.toString())
        }
        summaryVideo = muted("")
        statusVideo = muted("Idle")
        vodCamLabel = muted("")
        val selectCamBtn = smallButton("Select facecam area") {
            val picked = pickedUri
            val typed = vodBox.text.toString().trim()
            when {
                picked != null -> openPicker(picked, true, "Video")
                typed.isNotEmpty() -> openPicker(normalise(typed), false, "Video")
                else -> toast("Paste a video link or pick a video first")
            }
        }
        selectCamBtn.visibility = if (vodCam) View.VISIBLE else View.GONE
        val camSwitch = Switch(this).apply {
            text = "Add facecam to the clip"
            setTextColor(TEXT)
            isChecked = vodCam
            layoutParams = lp(8)
            setOnCheckedChangeListener { _, c ->
                vodCam = c
                prefs.edit().putBoolean("vodCam", c).apply()
                selectCamBtn.visibility = if (c) View.VISIBLE else View.GONE
                refreshCamLabels()
            }
        }
        val capSwitch = Switch(this).apply {
            text = "Add captions to edited clips"
            setTextColor(TEXT)
            isChecked = capOn
            layoutParams = lp(8)
            setOnCheckedChangeListener { _, c ->
                capOn = c
                prefs.edit().putBoolean("capOn", c).apply()
                prefetchCaps()
            }
        }
        capStatus = muted("")
        val capStyleRow = segmented(CapStyle.values().map { it.label }, capStyle.coerceIn(0, 3)) {
            capStyle = it
            prefs.edit().putInt("capStyle", it).apply()
        }
        val capLangRow = segmented(listOf("English", "Hinglish", "हिंदी"), capLang.coerceIn(0, 2)) {
            capLang = it
            prefs.edit().putInt("capLang", it).apply()
            refreshCapStatus()
            prefetchCaps()
        }
        refreshCapStatus()
        return page(
            heading("Videos"),
            muted("Clip a recorded video from a link or from your phone."),
            card(heading("1. Choose the video"), vodBox, pick, sourceLabel, clearPick),
            card(
                heading("Download"),
                muted("Downloads the full video or a short from the link above, in the highest quality available (up to 4K and 60 fps). It is saved to your save folder."),
                button("Download video / short (best quality)", true) { startDownload() },
            ),
            card(
                heading("Captions"),
                capSwitch,
                muted("Style"),
                capStyleRow,
                muted("Language"),
                capLangRow,
                capStatus,
                muted("English writes English speech. Hinglish writes Hindi speech in English letters, like \"mai ja rha hu\". हिंदी writes Hindi in Devanagari. Captions come from the speech in the clip, offline, so clear speech works best and mixed Hindi and English can have mistakes. Adds a little time per clip."),
            ),
            card(
                heading("Facecam"),
                camSwitch,
                muted("Turn off for videos without a facecam (for example MrBeast-style videos). The video then fills the screen over a blurred background and follows the people on screen. When on, a facecam is found automatically, or you can mark it."),
                vodCamLabel,
                selectCamBtn,
            ),
            card(
                heading("Auto highlights"),
                muted("Scans the whole video and clips the loudest moments."),
                muted("Max clips"),
                segmented(listOf("5", "10", "20"), listOf(5, 10, 20).indexOf(maxClips).coerceAtLeast(1)) {
                    maxClips = listOf(5, 10, 20)[it]
                    prefs.edit().putInt("maxClips", maxClips).apply()
                },
                auto,
            ),
            card(
                heading("Manual clip"),
                muted("You choose the exact part. Only that part is downloaded when possible."),
                startBox, endBox, manual,
            ),
            summaryVideo,
            card(heading("Status"), statusVideo, button("Stop everything", false) { stopAll() }),
        )
    }

    private fun buildSettingsPage(): View {
        val sensLabel = muted("")
        val sensBar = SeekBar(this).apply {
            max = 100
            progress = sens
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
            layoutParams = lp(6)
        }
        fun sensText() { sensLabel.text = "Sensitivity: $sens (higher = more clips)" }
        sensText()
        sensBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                sens = p
                sensText()
                refreshSummary()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                prefs.edit().putInt("sens", sens).apply()
            }
        })

        val lens = listOf(0, 30, 45, 60)
        val lenRow = segmented(lens.map { if (it == 0) "Auto" else "$it s" }, lens.indexOf(clipLen).coerceAtLeast(1)) {
            clipLen = lens[it]
            prefs.edit().putInt("clipLen", clipLen).apply()
            refreshSummary()
        }
        val cams = listOf("auto", "top", "bottom")
        val camRow = segmented(listOf("Auto (top)", "Top", "Bottom"), cams.indexOf(camPos).coerceAtLeast(0)) {
            camPos = cams[it]
            prefs.edit().putString("camPos", camPos).apply()
        }
        val gameRow = segmented(listOf("General", "BGMI", "GTA"), game.coerceIn(0, 2)) {
            game = it
            prefs.edit().putInt("game", game).apply()
        }
        val watchSwitch = Switch(this).apply {
            text = "Watch the screen for action (more battery)"
            setTextColor(TEXT)
            isChecked = watchScreen
            layoutParams = lp(12)
            setOnCheckedChangeListener { _, c ->
                watchScreen = c
                prefs.edit().putBoolean("watchScreen", c).apply()
            }
        }
        val coolSwitch = Switch(this).apply {
            text = "Cool mode (recommended)"
            setTextColor(TEXT)
            isChecked = cool
            layoutParams = lp(8)
            setOnCheckedChangeListener { _, c ->
                cool = c
                prefs.edit().putBoolean("cool", c).apply()
            }
        }
        accessText = muted("")
        val outs = listOf(1920, 2560)
        val outRow = segmented(listOf("1080p", "1440p (2K)"), outs.indexOf(outH).coerceAtLeast(1)) {
            outH = outs[it]
            prefs.edit().putInt("outH", outH).apply()
        }
        val srcs = listOf(0, 1080, 720)
        val srcRow = segmented(listOf("Best", "1080p", "720p"), srcs.indexOf(srcMax).coerceAtLeast(0)) {
            srcMax = srcs[it]
            prefs.edit().putInt("srcMax", srcMax).apply()
        }
        val fpsSwitch = Switch(this).apply {
            text = "Keep 60 fps when the source has it (slower)"
            setTextColor(TEXT)
            isChecked = keep60
            layoutParams = lp(12)
            setOnCheckedChangeListener { _, c ->
                keep60 = c
                prefs.edit().putBoolean("keep60", c).apply()
            }
        }
        val rawSwitch = Switch(this).apply {
            text = "Also save the full-frame clip"
            setTextColor(TEXT)
            isChecked = keepRaw
            layoutParams = lp(12)
            setOnCheckedChangeListener { _, c ->
                keepRaw = c
                prefs.edit().putBoolean("keepRaw", c).apply()
            }
        }

        cookieStatus = muted("")
        pathText = TextView(this).apply {
            textSize = 14f
            setTextColor(TEXT)
            background = rounded(CARD2, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = lp(8)
        }
        refreshSummary()

        return page(
            heading("Settings"),
            card(
                heading("Access"),
                accessText,
                button("Enter a new key", false) { showLock() },
            ),
            card(
                heading("Detection"),
                sensLabel,
                sensBar,
                muted("Clip length (Auto = as long as the action lasts)"),
                lenRow,
                muted("Game type (tunes the screen detection)"),
                gameRow,
                watchSwitch,
                muted("Screen detection looks at motion, flashes, hit effects and kill-feed activity, so fights and clutches are caught even when nobody shouts. Combined with audio it is very reliable; on its own it counts a little less."),
                coolSwitch,
                muted("Cool mode uses lighter encoding, limits CPU threads, and pauses editing while the phone is hot."),
            ),
            card(
                heading("Quality"),
                muted("Output size of the finished clip"),
                outRow,
                muted("Source quality to download (Best picks the highest the stream or video offers)"),
                srcRow,
                fpsSwitch,
                muted("A clip is only as sharp as its source. A 720p stream stretched to 2K doesn't gain detail. Higher settings use more data, battery and time per clip."),
            ),
            card(heading("Layout"), muted("Facecam position in the 9:16 clip"), camRow, rawSwitch),
            card(
                heading("Save location"),
                muted("Where finished clips go. Android doesn't allow the top Download or Internal storage folder itself, so pick or create a subfolder such as Download/Clips."),
                pathText,
                button("Choose folder", true) {
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        ),
                        pickFolderCode
                    )
                },
                button("Use default (Movies/StreamClipper)", false) {
                    prefs.edit().remove("outTree").apply()
                    refreshSummary()
                    toast("Saving to Movies/StreamClipper")
                },
            ),
            card(
                heading("YouTube account"),
                muted("Sign in so YouTube stops blocking the app with \"confirm you're not a bot\". Your login stays on this phone. A secondary Google account is safest, because automated use can occasionally limit an account."),
                cookieStatus,
                button("Sign in to YouTube", true) {
                    startActivity(Intent(this, YouTubeLoginActivity::class.java))
                },
                button("Sign out", false) {
                    java.io.File(filesDir, "cookies.txt").delete()
                    android.webkit.CookieManager.getInstance().removeAllCookies(null)
                    refreshSummary()
                    toast("Signed out")
                },
                button("Import a cookies.txt instead", false) {
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                        },
                        pickCookiesCode
                    )
                },
            ),
            card(
                heading("Keep it running"),
                muted("On Oppo / ColorOS also allow background activity and auto-launch for this app, and lock it in the recents screen."),
                button("Battery settings", false) {
                    try {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                },
            ),
        )
    }

    // ------------------------------------------------------------------ access lock

    private fun buildLock(): View {
        lockMsg = muted("").apply { textSize = 15f }
        lockErr = muted("").apply { setTextColor(0xFFFF6B6B.toInt()) }
        val code = TextView(this).apply {
            text = LicenseCodec.pretty(License.deviceCode(this@MainActivity))
            textSize = 26f
            typeface = Typeface.MONOSPACE
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        lockKey = field("Access key, e.g. ABCD-EFGH", "", uri = false).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.LengthFilter(12))
            typeface = Typeface.MONOSPACE
        }
        lockCancel = button("Cancel", false) { lockView.visibility = View.GONE }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(56), dp(20), dp(20))
            addView(heading("Stream Clipper"))
            addView(lockMsg)
            addView(card(
                muted("Your device code"),
                code,
                smallButton("Copy device code") {
                    getSystemService(ClipboardManager::class.java)
                        ?.setPrimaryClip(ClipData.newPlainText("device code", License.deviceCode(this@MainActivity)))
                    toast("Device code copied")
                },
                muted("Send this code with your request and the key will work on this phone."),
            ))
            addView(card(
                heading("Enter your key"),
                lockKey,
                button("Activate", true) {
                    val err = License.activate(this@MainActivity, lockKey.text.toString())
                    if (err == null) {
                        lockKey.setText("")
                        lockErr.text = ""
                        lockView.visibility = View.GONE
                        refreshLock()
                        refreshAccess()
                        toast("Access activated")
                    } else {
                        lockErr.text = err
                    }
                },
                lockErr,
            ))
            addView(lockCancel)
        }
        return ScrollView(this).apply {
            setBackgroundColor(BG)
            isClickable = true
            fitsSystemWindows = true
            addView(box)
        }
    }

    private fun dateText(ms: Long) = java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.US).format(java.util.Date(ms))

    private fun showLock() {
        lockErr.text = ""
        lockMsg.text = "Enter a new access key."
        lockCancel.visibility = View.VISIBLE
        lockView.visibility = View.VISIBLE
    }

    private fun refreshAccess() {
        val st = License.status(this)
        accessText.text = when (st.state) {
            License.State.ACTIVE -> "${st.plan?.label} plan. ${st.daysLeft} day${if (st.daysLeft == 1) "" else "s"} left (until ${dateText(st.expiresAt)})."
            License.State.EXPIRED -> "Your access ended on ${dateText(st.expiresAt)}."
            License.State.CLOCK -> "The phone's clock was moved back."
            License.State.NONE -> "No access key entered."
        }
    }

    private fun refreshLock() {
        val st = License.status(this)
        if (st.state != License.State.ACTIVE) {
            lockMsg.text = when (st.state) {
                License.State.EXPIRED -> "Your access ended on ${dateText(st.expiresAt)}. Ask for a new key to carry on."
                License.State.CLOCK -> "The phone's clock was moved back. Turn on automatic date and time, then reopen the app."
                else -> "Enter your access key to start."
            }
            lockCancel.visibility = View.GONE
            lockView.visibility = View.VISIBLE
        }
        refreshAccess()
    }

    private fun startDownload() {
        val typed = vodBox.text.toString().trim()
        if (typed.isEmpty()) {
            toast("Paste a video or shorts link first")
            return
        }
        prefs.edit().putString("vodurl", typed).apply()
        startForegroundService(
            intentFor(ClipService.ACTION_VOD)
                .putExtra("source", normalise(typed)).putExtra("isUri", false).putExtra("downloadOnly", true)
        )
        toast("Download started. Progress is in the Log tab")
    }

    private fun refreshCapStatus() {
        val name = Transcriber.modelLabel(capLang)
        capStatus.text = if (Transcriber.hasModel(this, capLang)) "$name speech model: ready \u2713"
        else "$name speech model: downloads once (about 40 MB) when you turn captions on or make the first captioned clip."
    }

    private fun prefetchCaps() {
        if (!capOn || Transcriber.hasModel(this, capLang)) {
            refreshCapStatus()
            return
        }
        toast("Downloading the ${Transcriber.modelLabel(capLang)} model…")
        Transcriber.prefetch(this, capLang) { err ->
            runOnUiThread {
                refreshCapStatus()
                if (err != null) toast("Couldn't download the model: ${err.take(80)}")
            }
        }
    }

    private fun buildLogPage(): View {
        logView = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(TEXT)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        logScroll = ScrollView(this).apply { addView(logView) }

        fun small(text: String, onClick: () -> Unit) = button(text, false, onClick).apply {
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) }
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(heading("Activity log"), LinearLayout.LayoutParams(0, -2, 1f))
            addView(small("Copy") {
                val cm = getSystemService(ClipboardManager::class.java)
                cm?.setPrimaryClip(ClipData.newPlainText("log", LogBus.text()))
                toast("Log copied")
            })
            addView(small("Clear") { LogBus.clear() })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, 18)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            addView(logScroll, LinearLayout.LayoutParams(-1, -1))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(header, LinearLayout.LayoutParams(-1, -2))
            addView(box, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12) })
        }
    }

    // ------------------------------------------------------------------ actions

    private fun startVideoJob(manual: Boolean, startTxt: String, endTxt: String) {
        val picked = pickedUri
        val typed = vodBox.text.toString().trim()
        val src = picked ?: if (typed.isEmpty()) null else normalise(typed)
        if (src == null) {
            toast("Paste a video link or pick a video first")
            return
        }
        val i = intentFor(ClipService.ACTION_VOD).putExtra("source", src).putExtra("isUri", picked != null)
            .putExtra("useCam", vodCam)
            .putExtra("captions", capOn)
            .putExtra("capStyle", capStyle)
            .putExtra("capLang", capLang)
        if (manual) {
            val s = parseTime(startTxt)
            if (s == null) {
                toast("Enter a start time like 5:00")
                return
            }
            val e = if (endTxt.isBlank()) s + (if (clipLen > 0) clipLen else 30) else parseTime(endTxt)
            if (e == null || e <= s) {
                toast("The end time must be after the start time")
                return
            }
            if (e - s > 600) {
                toast("Manual clips can be up to 10 minutes")
                return
            }
            i.putExtra("manualStart", s).putExtra("manualEnd", e)
        }
        prefs.edit().putString("vodurl", typed).apply()
        startForegroundService(i)
        toast("Started. Progress shows below and in the Log tab")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        when (requestCode) {
            pickVideoCode -> {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                pickedUri = uri.toString()
                var name = "selected video"
                try {
                    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) name = c.getString(0) ?: name
                    }
                } catch (_: Exception) {
                }
                sourceLabel.text = "Using video from phone: $name"
                refreshCamLabels()
            }
            pickCookiesCode -> {
                try {
                    val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                    if (!text.contains("youtube.com") && !text.contains("google.com")) {
                        toast("That doesn't look like a YouTube cookies.txt")
                    } else {
                        java.io.File(filesDir, "cookies.txt").writeText(text)
                        refreshSummary()
                        toast("Cookies added")
                    }
                } catch (e: Exception) {
                    toast("Couldn't read that file")
                }
            }
            pickFolderCode -> {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                    prefs.edit().putString("outTree", uri.toString()).apply()
                    refreshSummary()
                    toast("Clips will be saved there")
                } catch (e: Exception) {
                    toast("Can't use that folder. Pick or create a subfolder.")
                }
            }
        }
    }

    private fun updateButton() {
        val w = ClipService.watching
        startBtn.text = if (w) "Stop live watching" else "Start watching"
        startBtn.background = ripple(if (w) RED else ACCENT, 14)
        applyBtn.visibility = if (w) View.VISIBLE else View.GONE
        runningText.text = if (w)
            "Running: stream ${ClipService.activeSlots.sorted().joinToString(", ")}. Edit the links above and tap Add / update streams to change them without restarting."
        else ""
    }

    private fun refreshSummary() {
        val s = "Sensitivity $sens  ·  ${if (clipLen == 0) "auto length" else "$clipLen s"} clips  ·  Saves to ${Store.where(this)}"
        summaryLive.text = s
        summaryVideo.text = s
        pathText.text = Store.where(this)
        val ck = java.io.File(filesDir, "cookies.txt")
        cookieStatus.text = if (ck.exists() && ck.length() > 0) "Signed in to YouTube" else "Not signed in"
    }

    private fun refreshLog() {
        val t = LogBus.text()
        logView.text = if (t.isEmpty()) "Nothing yet. Start a stream or a video job and activity shows up here." else t
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        val last = LogBus.last() ?: "Idle"
        statusLive.text = last
        statusVideo.text = last
        updateButton()
    }

    override fun onResume() {
        super.onResume()
        LogBus.listener = { refreshLog() }
        refreshLock()
        refreshSummary()
        refreshLog()
        refreshCamLabels()
    }

    override fun onPause() {
        LogBus.listener = null
        super.onPause()
    }
}
