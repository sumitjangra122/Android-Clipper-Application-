package app.streamclipper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var startBtn: Button
    private var camPos = "auto"
    private var keepRaw = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Store.prefs(this)
        camPos = prefs.getString("camPos", "auto") ?: "auto"
        keepRaw = prefs.getBoolean("keepRaw", false)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            fitsSystemWindows = true
        }
        val title = TextView(this).apply {
            text = "Stream Clipper"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        }
        val urlBox = EditText(this).apply {
            hint = "Live URL (Kick, YouTube, Twitch)"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("url", ""))
        }
        val sensLabel = TextView(this).apply { textSize = 14f; setPadding(0, dp(10), 0, 0) }
        val sens = SeekBar(this).apply { max = 100; progress = prefs.getInt("sens", 50) }
        fun sensText() { sensLabel.text = "Sensitivity: ${sens.progress} (higher = more clips)" }
        sensText()
        sens.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = sensText()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        startBtn = Button(this)
        val camBtn = Button(this)
        fun camText() {
            camBtn.text = "Facecam position: " + when (camPos) {
                "top" -> "Top"; "bottom" -> "Bottom"; else -> "Auto (top)"
            }
        }
        camText()
        camBtn.setOnClickListener {
            camPos = when (camPos) { "auto" -> "top"; "top" -> "bottom"; else -> "auto" }
            prefs.edit().putString("camPos", camPos).apply()
            camText()
        }
        val rawBtn = Button(this)
        fun rawText() { rawBtn.text = "Also save full-frame clip: " + if (keepRaw) "On" else "Off" }
        rawText()
        rawBtn.setOnClickListener {
            keepRaw = !keepRaw
            prefs.edit().putBoolean("keepRaw", keepRaw).apply()
            rawText()
        }
        val batBtn = Button(this).apply {
            text = "Allow background running (battery settings)"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
        }

        startBtn.setOnClickListener {
            if (ClipService.running) {
                startService(Intent(this, ClipService::class.java).setAction(ClipService.ACTION_STOP))
            } else {
                var u = urlBox.text.toString().trim()
                if (u.isEmpty()) {
                    Toast.makeText(this, "Paste a live stream URL first", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (!u.startsWith("http")) u = "https://$u"
                prefs.edit().putString("url", u).putInt("sens", sens.progress).apply()
                startForegroundService(
                    Intent(this, ClipService::class.java)
                        .putExtra("url", u)
                        .putExtra("thr", 4.5 - 0.03 * sens.progress)
                        .putExtra("camPos", camPos)
                        .putExtra("keepRaw", keepRaw)
                )
            }
            startBtn.postDelayed({ updateButton() }, 600)
        }

        logView = TextView(this).apply { textSize = 12f; typeface = Typeface.MONOSPACE }
        scroll = ScrollView(this).apply { addView(logView) }

        root.addView(title)
        root.addView(urlBox)
        root.addView(sensLabel)
        root.addView(sens)
        root.addView(startBtn)
        root.addView(camBtn)
        root.addView(rawBtn)
        root.addView(batBtn)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun updateButton() {
        startBtn.text = if (ClipService.running) "Stop watching" else "Start watching"
    }

    private fun refreshLog() {
        val t = LogBus.text()
        logView.text = if (t.isEmpty())
            "Paste a live URL and tap Start.\nClips are saved to Movies/StreamClipper." else t
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        updateButton()
    }

    override fun onResume() {
        super.onResume()
        LogBus.listener = { refreshLog() }
        refreshLog()
    }

    override fun onPause() {
        LogBus.listener = null
        super.onPause()
    }
}
