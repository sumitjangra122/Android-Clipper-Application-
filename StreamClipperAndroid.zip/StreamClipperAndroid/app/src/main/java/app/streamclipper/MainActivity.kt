package app.streamclipper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var startBtn: Button
    private val liveBoxes = ArrayList<EditText>()
    private var camPos = "auto"
    private var keepRaw = false
    private var maxClips = 10
    private lateinit var sens: SeekBar

    private val pickCode = 42

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun urlBox(hint: String, saved: String?) = EditText(this).apply {
        this.hint = hint
        setSingleLine()
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        setText(saved ?: "")
    }

    private fun intentFor(action: String) =
        Intent(this, ClipService::class.java).setAction(action)
            .putExtra("thr", 4.5 - 0.03 * sens.progress)
            .putExtra("camPos", camPos)
            .putExtra("keepRaw", keepRaw)
            .putExtra("maxClips", maxClips)

    private fun normalise(u: String) = if (u.startsWith("http")) u else "https://$u"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Store.prefs(this)
        camPos = prefs.getString("camPos", "auto") ?: "auto"
        keepRaw = prefs.getBoolean("keepRaw", false)
        maxClips = prefs.getInt("maxClips", 10)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }
        val outer = ScrollView(this).apply {
            fitsSystemWindows = true
            addView(root)
        }

        root.addView(TextView(this).apply {
            text = "Stream Clipper"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        })

        // ---- live streams (up to 5)
        root.addView(label("Live streams (up to 5)"))
        for (i in 1..5) {
            val e = urlBox("Live stream $i (Kick / YouTube / Twitch)", prefs.getString("url$i", ""))
            liveBoxes += e
            root.addView(e)
        }

        // ---- shared settings
        val sensLabel = TextView(this).apply { textSize = 14f; setPadding(0, dp(12), 0, 0) }
        sens = SeekBar(this).apply { max = 100; progress = prefs.getInt("sens", 50) }
        fun sensText() { sensLabel.text = "Sensitivity: ${sens.progress} (higher = more clips)" }
        sensText()
        sens.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = sensText()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sensLabel)
        root.addView(sens)

        startBtn = Button(this)
        root.addView(startBtn)
        startBtn.setOnClickListener {
            if (ClipService.watching) {
                startService(Intent(this, ClipService::class.java).setAction(ClipService.ACTION_STOP_LIVE))
            } else {
                val urls = liveBoxes.map { it.text.toString().trim() }
                    .filter { it.isNotEmpty() }.map { normalise(it) }.distinct()
                if (urls.isEmpty()) {
                    Toast.makeText(this, "Paste at least one live stream URL", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val ed = prefs.edit().putInt("sens", sens.progress)
                liveBoxes.forEachIndexed { i, b -> ed.putString("url${i + 1}", b.text.toString().trim()) }
                ed.apply()
                startForegroundService(
                    intentFor(ClipService.ACTION_WATCH).putStringArrayListExtra("urls", ArrayList(urls))
                )
            }
            startBtn.postDelayed({ updateButton() }, 600)
        }

        // ---- video clipping
        root.addView(label("Clip a video (not live)"))
        val vodBox = urlBox("Video URL (YouTube video, Kick/Twitch VOD)", prefs.getString("vodurl", ""))
        root.addView(vodBox)
        root.addView(Button(this).apply {
            text = "Clip this video URL"
            setOnClickListener {
                val u = vodBox.text.toString().trim()
                if (u.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Paste a video URL first", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                prefs.edit().putString("vodurl", u).putInt("sens", sens.progress).apply()
                startForegroundService(
                    intentFor(ClipService.ACTION_VOD).putExtra("source", normalise(u)).putExtra("isUri", false)
                )
            }
        })
        root.addView(Button(this).apply {
            text = "Pick a video from this phone"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "video/*"
                }
                startActivityForResult(i, pickCode)
            }
        })
        val maxBtn = Button(this)
        fun maxText() { maxBtn.text = "Max clips per video: $maxClips" }
        maxText()
        maxBtn.setOnClickListener {
            maxClips = when (maxClips) { 5 -> 10; 10 -> 20; else -> 5 }
            prefs.edit().putInt("maxClips", maxClips).apply()
            maxText()
        }
        root.addView(maxBtn)

        // ---- options
        root.addView(label("Options"))
        val camBtn = Button(this)
        fun camText() {
            camBtn.text = "Facecam position: " + when (camPos) {
                "top" -> "Top"; "bottom" -> "Bottom"; else -> "Auto (top)"
            }
        }
        camText()
        camBtn.setOnClickListener {
            camPos = when (camPos) { "auto" -> "top"; "top" -> "bottom"; else -> "auto" }
            prefs.edit().putString("camPos", camPos).apply()
            camText()
        }
        root.addView(camBtn)
        val rawBtn = Button(this)
        fun rawText() { rawBtn.text = "Also save full-frame clip: " + if (keepRaw) "On" else "Off" }
        rawText()
        rawBtn.setOnClickListener {
            keepRaw = !keepRaw
            prefs.edit().putBoolean("keepRaw", keepRaw).apply()
            rawText()
        }
        root.addView(rawBtn)
        root.addView(Button(this).apply {
            text = "Allow background running (battery settings)"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Stop everything (live + video jobs)"
            setOnClickListener {
                startService(Intent(this@MainActivity, ClipService::class.java).setAction(ClipService.ACTION_STOP))
            }
        })

        // ---- log
        root.addView(label("Log"))
        logView = TextView(this).apply { textSize = 12f; typeface = Typeface.MONOSPACE }
        logScroll = ScrollView(this).apply {
            addView(logView)
            setOnTouchListener { v, _ ->
                v.parent.requestDisallowInterceptTouchEvent(true)
                false
            }
        }
        root.addView(logScroll, LinearLayout.LayoutParams(-1, dp(280)))

        setContentView(outer)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        startForegroundService(
            intentFor(ClipService.ACTION_VOD).putExtra("source", uri.toString()).putExtra("isUri", true)
        )
    }

    private fun updateButton() {
        startBtn.text = if (ClipService.watching) "Stop live watching" else "Start watching"
    }

    private fun refreshLog() {
        val t = LogBus.text()
        logView.text = if (t.isEmpty())
            "Add live URLs and tap Start, or clip a video above.\nClips are saved to Movies/StreamClipper." else t
        logScroll.post { logScroll.fullScroll(android.view.View.FOCUS_DOWN) }
        updateButton()
    }

    override fun onResume() {
        super.onResume()
        LogBus.listener = { refreshLog() }
        refreshLog()
    }

    override fun onPause() {
        LogBus.listener = null
        super.onPause()
    }
}
