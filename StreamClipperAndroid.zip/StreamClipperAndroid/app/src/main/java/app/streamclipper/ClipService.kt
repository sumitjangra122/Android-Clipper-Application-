package app.streamclipper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.io.File
import kotlin.math.max
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Runs up to 5 live watchers plus any number of video-clipping jobs.
 * All finished clips go through one shared edit queue (one encode at a time).
 */
class ClipService : Service() {
    companion object {
        const val ACTION_WATCH = "app.streamclipper.WATCH"
        const val ACTION_VOD = "app.streamclipper.VOD"
        const val ACTION_STOP = "app.streamclipper.STOP"
        const val ACTION_STOP_LIVE = "app.streamclipper.STOP_LIVE"
        const val ACTION_CLIP_NOW = "app.streamclipper.CLIP_NOW"
        @Volatile var watching = false
        @Volatile var busy = false
        /** Stream slots (1..5) that are currently being watched. */
        @Volatile var activeSlots: Set<Int> = emptySet()
    }

    private val lock = Any()
    private val engineLock = Any()
    private var engineReady = false
    private val encoder = Executors.newSingleThreadExecutor()
    private val pendingEdits = AtomicInteger(0)
    @Volatile private var cancelEdits = false

    private val watchers = LinkedHashMap<Int, Watcher>()       // slot -> watcher
    private val watcherThreads = HashMap<Int, Thread>()
    private val watcherUrls = HashMap<Int, String>()
    private val vodJobs = ArrayList<VodJob>()
    private var jobs = 0
    private var liveJobs = 0
    private var vodCount = 0

    private var wake: PowerManager.WakeLock? = null
    private lateinit var nm: NotificationManager
    @Volatile private var lastText = "Starting…"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)!!
        nm.createNotificationChannel(
            NotificationChannel("watch", "Stream watching", NotificationManager.IMPORTANCE_LOW)
        )
    }

    @Suppress("DEPRECATION")
    private fun notif(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, ClipService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "watch")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Stream Clipper")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop all", stop)
            .build()
    }

    private fun say(line: String) {
        LogBus.post(line)
        lastText = line
        nm.notify(1, notif(line))
    }

    /** Shared edit queue: one encode at a time, raw clip always deleted afterwards. */
    private val submit: (File, () -> Unit) -> Unit = { raw, task ->
        pendingEdits.incrementAndGet()
        encoder.execute {
            try {
                if (!cancelEdits) task()
            } finally {
                raw.delete()
                pendingEdits.decrementAndGet()
                checkDone()
            }
        }
    }

    private fun ensureEngine() = synchronized(engineLock) {
        if (!engineReady) {
            say("Starting engine (first launch unpacks yt-dlp + ffmpeg, ~30s)…")
            Bins.init(applicationContext)
            say("Engine ready: ${Bins.ffmpegInfo} (${Bins.encoder})")
            Bins.updateYtDlpIfStale(applicationContext) { say(it) }
            engineReady = true
        }
    }

    private fun config(i: Intent): Config {
        val tall = i.getIntExtra("outH", 2560) >= 2560
        return Config(
            thr = i.getDoubleExtra("thr", 3.0),
            clipLen = i.getIntExtra("clipLen", 30),   // 0 = auto length
            keepRaw = i.getBooleanExtra("keepRaw", false),
            camPos = i.getStringExtra("camPos") ?: "auto",
            maxClips = i.getIntExtra("maxClips", 10),
            outW = if (tall) 1440 else 1080,
            outH = if (tall) 2560 else 1920,
            srcMax = i.getIntExtra("srcMax", 0),
            keep60 = i.getBooleanExtra("keep60", false),
            useCam = i.getBooleanExtra("useCam", true),
            game = i.getIntExtra("game", 0),
            watchScreen = i.getBooleanExtra("watchScreen", true),
            cool = i.getBooleanExtra("cool", true),
        )
    }

    private fun acquireWake() {
        if (wake?.isHeld == true) return
        wake = getSystemService(PowerManager::class.java)!!
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "streamclipper:work")
            .apply { acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAll()
                return START_NOT_STICKY
            }
            ACTION_STOP_LIVE -> {
                stopLive()
                return START_NOT_STICKY
            }
            ACTION_CLIP_NOW -> {
                val n = synchronized(lock) { watchers.values.onEach { it.requestClip() }.size }
                say(if (n == 0) "Start watching a stream first" else "Clipping now from $n stream${if (n > 1) "s" else ""}…")
                if (!busy) stopSelf()
                return START_NOT_STICKY
            }
            ACTION_WATCH, ACTION_VOD -> {
                val n = notif(lastText)
                if (Build.VERSION.SDK_INT >= 34) {
                    startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                } else {
                    startForeground(1, n)
                }
                License.refreshServerTime()
                if (!License.active(this)) {
                    say("Access has ended. Enter a new key in the app (Settings > Access).")
                    if (!busy) finish()
                    return START_NOT_STICKY
                }
                acquireWake()
                val cfg = config(intent)
                if (intent.action == ACTION_WATCH) {
                    val urls = intent.getStringArrayListExtra("urls") ?: arrayListOf()
                    val slots = intent.getIntegerArrayListExtra("slots") ?: arrayListOf()
                    val desired = LinkedHashMap<Int, String>()
                    urls.forEachIndexed { i, u ->
                        val s = slots.getOrNull(i) ?: (i + 1)
                        if (s in 1..5) desired[s] = u
                    }
                    syncWatch(desired, cfg)
                } else {
                    val src = intent.getStringExtra("source")
                    val ms = intent.getDoubleExtra("manualStart", -1.0)
                    val me = intent.getDoubleExtra("manualEnd", -1.0)
                    val range = if (ms >= 0 && me > ms) Pair(ms, me) else null
                    if (src != null) startVod(src, intent.getBooleanExtra("isUri", false), range, cfg)
                }
                if (!busy) finish()
            }
            else -> if (!busy) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun publishSlots() {
        activeSlots = synchronized(lock) { watchers.keys.toSet() }
    }

    /**
     * Makes the running streams match [desired] (slot -> link): starts new ones, restarts ones whose
     * link changed, stops removed ones. Streams that stay keep running without a restart.
     */
    private fun syncWatch(desired: Map<Int, String>, cfg: Config) {
        synchronized(lock) {
            if (pendingEdits.get() == 0) cancelEdits = false
            for (slot in watchers.keys.toList()) {
                val want = desired[slot]
                if (want == null || want != watcherUrls[slot]) {
                    watchers.remove(slot)?.running = false
                    watcherThreads.remove(slot)?.interrupt()
                    watcherUrls.remove(slot)
                    say("[$slot] stopped")
                } else {
                    watchers[slot]?.cfg = cfg   // sensitivity and clip length changes apply to running streams too
                }
            }
            var started = 0
            for ((slot, url) in desired) {
                if (watchers.containsKey(slot)) continue
                val w = Watcher(applicationContext, slot, url, cfg, submit) { line -> say("[$slot] $line") }
                watchers[slot] = w
                watcherUrls[slot] = url
                jobs++
                liveJobs++
                val t = Thread({
                    try {
                        ensureEngine()
                        w.run()
                    } catch (e: Throwable) {
                        say("[$slot] error: ${e.message ?: e.javaClass.simpleName}")
                    } finally {
                        synchronized(lock) {
                            if (watchers[slot] === w) {
                                watchers.remove(slot)
                                watcherThreads.remove(slot)
                                watcherUrls.remove(slot)
                            }
                        }
                        publishSlots()
                        jobEnded(true)
                    }
                }, "watch-$slot")
                watcherThreads[slot] = t
                t.start()
                started++
            }
            if (watchers.isNotEmpty()) {
                watching = true
                busy = true
            }
            publishSlots()
            val n = watchers.size
            if (started > 0 || n > 0) {
                say("Watching $n stream${if (n != 1) "s" else ""}" + if (started > 0) " ($started added)" else "")
            }
        }
    }

    private fun startVod(source: String, isUri: Boolean, range: Pair<Double, Double>?, cfg: Config) {
        val job = synchronized(lock) {
            if (pendingEdits.get() == 0) cancelEdits = false
            busy = true
            jobs++
            vodCount++
            val id = vodCount
            VodJob(applicationContext, id, source, isUri, range, cfg, submit) { line -> say("[video $id] $line") }
                .also { vodJobs += it }
        }
        Thread({
            try {
                ensureEngine()
                job.run()
            } catch (e: Throwable) {
                say("[video ${job.id}] failed: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                synchronized(lock) { vodJobs.remove(job) }
                jobEnded(false)
            }
        }, "vod-${job.id}").start()
    }

    private fun stopLive() {
        synchronized(lock) {
            watchers.values.forEach { it.running = false }
            watcherThreads.values.forEach { it.interrupt() }
        }
        say("Stopping live watching…")
    }

    private fun stopAll() {
        cancelEdits = true
        synchronized(lock) {
            watchers.values.forEach { it.running = false }
            watcherThreads.values.forEach { it.interrupt() }
            vodJobs.forEach { it.cancel() }
        }
        say("Stopping everything…")
        if (!busy) finish()
    }

    private fun jobEnded(live: Boolean) {
        synchronized(lock) {
            jobs--
            if (live) {
                liveJobs--
                if (liveJobs == 0) {
                    watching = false
                    watchers.clear()
                    watcherThreads.clear()
                    watcherUrls.clear()
                    activeSlots = emptySet()
                    LogBus.post("Live watching stopped")
                }
            }
        }
        checkDone()
    }

    private fun checkDone() {
        val done = synchronized(lock) { jobs == 0 && pendingEdits.get() == 0 }
        if (done) finish()
    }

    private fun finish() {
        busy = false
        watching = false
        LogBus.post("All done")
        wake?.let { if (it.isHeld) it.release() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        synchronized(lock) { watchers.values.forEach { it.running = false } }
        wake?.let { if (it.isHeld) it.release() }
        encoder.shutdown()
        super.onDestroy()
    }
}
