package app.streamclipper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class ClipService : Service() {
    companion object {
        const val ACTION_STOP = "app.streamclipper.STOP"
        @Volatile var running = false
    }

    private var thread: Thread? = null
    private var watcher: Watcher? = null
    private var wake: PowerManager.WakeLock? = null
    private lateinit var nm: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)!!
        nm.createNotificationChannel(
            NotificationChannel("watch", "Stream watching", NotificationManager.IMPORTANCE_LOW)
        )
    }

    @Suppress("DEPRECATION")
    private fun notif(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, ClipService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "watch")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Stream Clipper")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stop)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            watcher?.running = false
            val t = thread
            if (t == null) stopSelf() else t.interrupt()
            return START_NOT_STICKY
        }

        val n = notif("Starting…")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        val url = intent?.getStringExtra("url")
        if (url == null || running) {
            if (!running) stopSelf()
            return START_NOT_STICKY
        }
        running = true

        val cfg = Config(
            thr = intent.getDoubleExtra("thr", 3.0),
            pre = 25, post = 10, cooldown = 45,
            keepRaw = intent.getBooleanExtra("keepRaw", false),
            camPos = intent.getStringExtra("camPos") ?: "auto",
        )

        wake = getSystemService(PowerManager::class.java)!!
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "streamclipper:watch")
            .apply { acquire() }

        val log: (String) -> Unit = { line ->
            LogBus.post(line)
            nm.notify(1, notif(line))
        }

        thread = Thread({
            try {
                log("Starting engine (first launch unpacks yt-dlp + ffmpeg, ~30s)…")
                Bins.init(applicationContext)
                Bins.updateYtDlpIfStale(applicationContext)
                val w = Watcher(applicationContext, url, cfg, log)
                watcher = w
                w.run()
            } catch (e: Throwable) {
                LogBus.post("Error: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                running = false
                LogBus.post("Stopped")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }, "clipper-worker").also { it.start() }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        watcher?.running = false
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
