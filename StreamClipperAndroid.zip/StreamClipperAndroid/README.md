# Stream Clipper (Android app)

Watches a live stream (Kick, YouTube, Twitch, anything yt-dlp supports), detects hype
moments from audio, cuts a clip, and auto-edits it into a 9:16 short:
facecam found automatically, gameplay crop panned to the action, color grade, fades,
loudness normalise. Clips land in Movies/StreamClipper.

## Build the APK (no Android Studio needed)
1. Create a new GitHub repo and push this folder to it.
2. Open the repo's Actions tab, wait for "Build APK" to finish (or run it manually).
3. Download the `StreamClipper-debug-apk` artifact, unzip, install the APK on the phone.

Or open the folder in Android Studio and press Run.

## Oppo / ColorOS settings (important, or the OS kills it)
- Settings > Battery > App battery management > Stream Clipper > Allow background activity
- Allow auto-launch / "Allow activity in background" for the app
- Lock the app in the recents screen (pull down on its card)
- Tap "Allow background running" inside the app and choose "Don't optimize"

## Tabs
- Streams: up to 5 live links, start/stop, status.
- Videos: link or phone file, auto highlights, or a manual time range.
- Settings: sensitivity, clip length, facecam position, save folder, battery tips.
- Log: copy or clear the activity log.

## Output
Clips are exported vertical at 1440x2560 (2K) by default, or 1080x1920. Layout is decided per scene,
so streams that cut between cams, banners and gameplay are framed correctly each time.

## Facecam
Automatic mode ignores mid-screen faces (game characters). For full control, tap Select facecam under a stream
link (or in the Videos tab), draw a box around the cam on the preview, and only that area is used.

## Videos without a facecam
In the Videos tab, turn off Add facecam for videos with no cam (for example MrBeast-style videos). The video then
fills the screen over a blurred background and follows the people on screen.

## Features
- Watch up to 5 live streams at once (Kick, YouTube, Twitch).
- Clip recorded videos: paste a video / VOD URL, or pick a file from the phone.
  The whole audio track is scanned and the best moments (max clips setting) are cut.
- Every clip is auto-edited to 9:16 (facecam found automatically, gameplay crop follows the action).
- All edits share one queue, so the phone encodes one clip at a time.
