# Stream Clipper (Android app)

Watches a live stream (Kick, YouTube, Twitch, anything yt-dlp supports), detects hype
moments from audio, cuts a clip, and auto-edits it into a 9:16 short:
facecam found automatically, gameplay crop panned to the action, color grade, fades,
loudness normalise. Clips land in Movies/StreamClipper.

## Build the APK (no Android Studio needed)
1. Create a new GitHub repo and push this folder to it.
2. Open the repo's Actions tab, wait for "Build APK" to finish (or run it manually).
3. Download the `StreamClipper-debug-apk` artifact, unzip, install the APK on the phone.

Or open the folder in Android Studio and press Run.

## Oppo / ColorOS settings (important, or the OS kills it)
- Settings > Battery > App battery management > Stream Clipper > Allow background activity
- Allow auto-launch / "Allow activity in background" for the app
- Lock the app in the recents screen (pull down on its card)
- Tap "Allow background running" inside the app and choose "Don't optimize"
