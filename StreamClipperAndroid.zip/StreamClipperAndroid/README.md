# Stream Clipper (Android app)

Watches a live stream (Kick, YouTube, Twitch, anything yt-dlp supports), detects hype
moments from audio, cuts a clip, and auto-edits it into a 9:16 short:
facecam found automatically, gameplay crop panned to the action, color grade, fades,
loudness normalise. Clips land in Movies/StreamClipper.

## Build the APK (no Android Studio needed)
1. Create a new GitHub repo and push this folder to it.
2. Open the repo's Actions tab, wait for "Build APK" to finish (or run it manually).
3. Download the `StreamClipper-debug-apk` artifact, unzip, install the APK on the phone.

Or open the folder in Android Studio and press Run.

## Oppo / ColorOS settings (important, or the OS kills it)
- Settings > Battery > App battery management > Stream Clipper > Allow background activity
- Allow auto-launch / "Allow activity in background" for the app
- Lock the app in the recents screen (pull down on its card)
- Tap "Allow background running" inside the app and choose "Don't optimize"

## Tabs
- Streams: up to 5 live links, start/stop, status.
- Videos: link or phone file, auto highlights, or a manual time range.
- Settings: sensitivity, clip length, facecam position, save folder, battery tips.
- Log: copy or clear the activity log.

## Features
- Watch up to 5 live streams at once (Kick, YouTube, Twitch).
- Clip recorded videos: paste a video / VOD URL, or pick a file from the phone.
  The whole audio track is scanned and the best moments (max clips setting) are cut.
- Every clip is auto-edited to 9:16 (facecam found automatically, gameplay crop follows the action).
- All edits share one queue, so the phone encodes one clip at a time.
