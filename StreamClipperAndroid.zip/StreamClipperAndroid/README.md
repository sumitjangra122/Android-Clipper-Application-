# Stream Clipper (Android) + KeyMaker

Two apps, built from two zips:
- StreamClipperAndroid.zip: the clipper. Locked until an access key is entered.
- KeyMaker.zip: your private app that makes the 8-character access keys.

## One-time setup on GitHub
1. Repo > Settings > Secrets and variables > Actions > New repository secret.
   Name: LICENSE_SECRET, value: any long random text (16+ characters). Never change it later.
   Both apps are built with the same secret.
2. Use the build.yml from the chat (builds both zips).
3. The first time, uninstall the old Stream Clipper once. After that, updates install over it.

## Giving someone access
1. They open the clipper, copy their device code from the lock screen, and send it to you.
2. In KeyMaker: pick the plan, paste their device code, tap Generate, send them the key.
3. They enter it in the clipper. The plan starts then (7 days, 1 month, ...). When it ends the app locks.
A key made with a device code works only on that phone. A key made without one works on any phone.
