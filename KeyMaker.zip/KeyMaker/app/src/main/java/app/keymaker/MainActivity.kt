package app.keymaker

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import app.license.LicenseCodec
import app.license.Plan
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

/** Makes the 8-character access keys for the Stream Clipper app. Keep this app private. */
class MainActivity : Activity() {
    private val BG = 0xFF12121A.toInt()
    private val CARD = 0xFF1C1C28.toInt()
    private val CARD2 = 0xFF2A2A3C.toInt()
    private val ACCENT = 0xFFFF2E63.toInt()
    private val TEXT = 0xFFEDEDF5.toInt()
    private val MUTED = 0xFF9A9AB0.toInt()

    private var plan = Plan.D7
    private lateinit var deviceBox: EditText
    private lateinit var nameBox: EditText
    private lateinit var keyText: TextView
    private lateinit var keyInfo: TextView
    private lateinit var history: LinearLayout
    private lateinit var checkBox: EditText
    private lateinit var checkResult: TextView
    private var lastKey = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    private fun heading(t: String) = TextView(this).apply {
        text = t; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(TEXT)
    }

    private fun muted(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(MUTED); setPadding(0, dp(4), 0, 0)
    }

    private fun card(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 18)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        layoutParams = lp(12)
        v.forEach { addView(it) }
    }

    private fun button(t: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 15f
        setTextColor(0xFFFFFFFF.toInt())
        background = rounded(if (primary) ACCENT else CARD2, 14)
        stateListAnimator = null
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = lp(10)
        setOnClickListener { onClick() }
    }

    private fun field(hint: String, caps: Boolean = false) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(MUTED); setTextColor(TEXT); textSize = 15f; setSingleLine()
        inputType = InputType.TYPE_CLASS_TEXT or (if (caps) InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS else 0) or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        background = rounded(CARD2, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = lp(8)
    }

    private fun copy(label: String, text: String) {
        getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText(label, text))
        toast("Copied")
    }

    private fun today(): Long = System.currentTimeMillis() / 86_400_000L
    private fun dayText(epochDay: Long) = LocalDate.ofEpochDay(epochDay).toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        root.addView(heading("Clipper KeyMaker"))
        root.addView(muted("Makes access keys for the Stream Clipper app. Keep this app to yourself."))

        // plan chooser
        val plans = Plan.values().toList()
        val chips = ArrayList<TextView>()
        fun paint() = chips.forEachIndexed { i, v ->
            v.background = if (plans[i] == plan) rounded(ACCENT, 10) else null
            v.setTextColor(if (plans[i] == plan) 0xFFFFFFFF.toInt() else MUTED)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(CARD2, 12)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = lp(8)
        }
        plans.forEach { p ->
            val v = TextView(this).apply {
                text = p.label; gravity = Gravity.CENTER; textSize = 13f
                setPadding(0, dp(10), 0, dp(10))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { plan = p; paint() }
            }
            chips.add(v); row.addView(v)
        }
        paint()

        deviceBox = field("Customer's device code (optional)", caps = true).apply {
            filters = arrayOf(InputFilter.LengthFilter(9))
            typeface = Typeface.MONOSPACE
        }
        nameBox = field("Customer name or note (optional)")
        keyText = TextView(this).apply {
            textSize = 34f; typeface = Typeface.MONOSPACE; setTextColor(TEXT); gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(6))
        }
        keyInfo = muted("").apply { gravity = Gravity.CENTER }

        root.addView(card(
            heading("New key"),
            muted("How long the key lasts once the customer enters it"),
            row,
            muted("With a device code, the key only works on that phone and can't be passed on. Without one, it works on any phone."),
            deviceBox,
            nameBox,
            button("Generate key", true) { generate() },
        ))
        root.addView(card(
            keyText,
            keyInfo,
            button("Copy key", false) { if (lastKey.isNotEmpty()) copy("key", LicenseCodec.pretty(lastKey)) },
            button("Share key", false) { share() },
        ))

        checkBox = field("Check a key, e.g. ABCD-EFGH", caps = true)
        checkResult = muted("")
        root.addView(card(
            heading("Check a key"),
            muted("Enter a key (and the device code if it has one) to see what it is."),
            checkBox,
            button("Check", false) { check() },
            checkResult,
        ))

        history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(card(
            heading("Keys made"),
            muted("Tap one to copy it."),
            history,
            button("Clear history", false) { prefs().edit().remove("h").apply(); renderHistory() },
        ))
        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            fitsSystemWindows = true
            addView(root)
        })
        renderHistory()
    }

    private fun prefs() = getSharedPreferences("keys", Context.MODE_PRIVATE)

    private fun generate() {
        val dev = deviceBox.text.toString().trim()
        try {
            val key = LicenseCodec.generate(BuildConfig.LICENSE_SECRET, plan, dev.ifEmpty { null }, today())
            lastKey = key
            keyText.text = LicenseCodec.pretty(key)
            val bound = LicenseCodec.normalise(dev).isNotEmpty()
            keyInfo.text = "${plan.label} · " + (if (bound) "this device only" else "any device") +
                "\nCustomer must enter it within ${LicenseCodec.ACTIVATION_WINDOW_DAYS} days (by ${dayText(today() + LicenseCodec.ACTIVATION_WINDOW_DAYS)})"
            val h = JSONArray(prefs().getString("h", "[]"))
            val e = JSONObject()
                .put("k", key).put("p", plan.label).put("d", LicenseCodec.normalise(dev))
                .put("n", nameBox.text.toString().trim()).put("t", System.currentTimeMillis())
            val out = JSONArray().put(e)
            for (i in 0 until minOf(h.length(), 59)) out.put(h.get(i))
            prefs().edit().putString("h", out.toString()).apply()
            renderHistory()
        } catch (e: IllegalArgumentException) {
            toast(e.message ?: "Check the device code (8 characters)")
        }
    }

    private fun share() {
        if (lastKey.isEmpty()) return
        val msg = "Your Stream Clipper access key: ${LicenseCodec.pretty(lastKey)} (${plan.label}). " +
            "Open the app > Settings > Access > Enter a new key."
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), "Share key"))
    }

    private fun check() {
        val k = checkBox.text.toString()
        val dev = deviceBox.text.toString()
        val d = LicenseCodec.decode(BuildConfig.LICENSE_SECRET, k, dev)
        checkResult.text = if (d == null) {
            "Not valid. If this key was made for a device, fill in that device code above first."
        } else {
            val made = LicenseCodec.epochDayOf(d.issueDay)
            "Valid. ${d.plan.label} plan, " + (if (d.bound) "tied to one device" else "works on any device") +
                ". Made ${dayText(made)}, must be entered by ${dayText(made + LicenseCodec.ACTIVATION_WINDOW_DAYS)}."
        }
    }

    private fun renderHistory() {
        history.removeAllViews()
        val h = JSONArray(prefs().getString("h", "[]"))
        if (h.length() == 0) {
            history.addView(muted("Nothing yet."))
            return
        }
        val fmt = SimpleDateFormat("d MMM, HH:mm", Locale.US)
        for (i in 0 until h.length()) {
            val e = h.getJSONObject(i)
            val line = LicenseCodec.pretty(e.getString("k")) + "  ·  " + e.getString("p") +
                (if (e.getString("d").isNotEmpty()) "  ·  device" else "  ·  any") +
                (if (e.getString("n").isNotEmpty()) "  ·  " + e.getString("n") else "") +
                "\n" + fmt.format(Date(e.getLong("t")))
            history.addView(TextView(this).apply {
                text = line; textSize = 13f; typeface = Typeface.MONOSPACE; setTextColor(TEXT)
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { copy("key", LicenseCodec.pretty(e.getString("k"))) }
            })
        }
    }
}
