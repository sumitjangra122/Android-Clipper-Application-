package app.license

import java.security.MessageDigest
import java.security.SecureRandom
import java.time.LocalDate
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

enum class Plan(val code: Int, val days: Int, val label: String) {
    D7(0, 7, "7 days"),
    D30(1, 30, "1 month"),
    D90(2, 90, "3 months"),
    D365(3, 365, "1 year");

    companion object {
        fun of(code: Int): Plan = values().first { it.code == code }
    }
}

class Decoded(val plan: Plan, val bound: Boolean, val issueDay: Int)

/**
 * 8-character access keys (40 bits): plan, creation day, and a keyed signature.
 * A key made with a device code only works on that device; a key made without one works anywhere.
 */
object LicenseCodec {
    const val ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"   // no 0/1/I/O, easy to read out loud
    const val ACTIVATION_WINDOW_DAYS = 7                        // a key must be activated within 7 days of creation

    private val BASE_DAY: Long = LocalDate.of(2026, 1, 1).toEpochDay()

    fun dayNumber(epochDay: Long): Int = (epochDay - BASE_DAY).toInt()
    fun epochDayOf(issueDay: Int): Long = BASE_DAY + issueDay

    /** Uppercases and drops spaces, dashes and anything that isn't a key character. */
    fun normalise(s: String): String = s.uppercase().filter { it in ALPHABET }

    fun pretty(key: String): String = if (key.length == 8) key.substring(0, 4) + "-" + key.substring(4) else key

    private fun mac(secret: String, msg: String): Long {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        val h = m.doFinal(msg.toByteArray())
        return ((h[0].toLong() and 0xFF) shl 24) or ((h[1].toLong() and 0xFF) shl 16) or
            ((h[2].toLong() and 0xFF) shl 8) or (h[3].toLong() and 0xFF)
    }

    private fun toText(v: Long): String {
        val sb = StringBuilder()
        for (i in 7 downTo 0) sb.append(ALPHABET[((v shr (i * 5)) and 31L).toInt()])
        return sb.toString()
    }

    private fun fromText(s: String): Long {
        var v = 0L
        for (c in s) v = (v shl 5) or ALPHABET.indexOf(c).toLong()
        return v
    }

    /** The code a customer reads out to you so the key can be tied to their phone. */
    fun deviceCodeFrom(id: String): String {
        val h = MessageDigest.getInstance("SHA-256").digest(("clipper-device|$id").toByteArray())
        var v = 0L
        for (i in 0 until 5) v = (v shl 8) or (h[i].toLong() and 0xFF)
        return toText(v)
    }

    fun generate(secret: String, plan: Plan, deviceCode: String?, todayEpochDay: Long, rnd: SecureRandom = SecureRandom()): String {
        val day = dayNumber(todayEpochDay)
        require(day in 0..2047) { "Date is outside the supported range" }
        val dc = deviceCode?.let { normalise(it) }.orEmpty()
        val bound = dc.isNotEmpty()
        require(!bound || dc.length == 8) { "Device code must be 8 characters" }
        var v = (plan.code.toLong() shl 38) or ((if (bound) 1L else 0L) shl 37) or (day.toLong() shl 26)
        v = if (bound) {
            v or (mac(secret, "B|${plan.code}|$day|$dc") and 0x3FFFFFFL)
        } else {
            val nonce = rnd.nextInt(1024)
            v or (nonce.toLong() shl 16) or (mac(secret, "U|${plan.code}|$day|$nonce") and 0xFFFFL)
        }
        return toText(v)
    }

    /** Returns the key's details if its signature is valid for this device, otherwise null. */
    fun decode(secret: String, keyText: String, deviceCode: String): Decoded? {
        val k = normalise(keyText)
        if (k.length != 8) return null
        val v = fromText(k)
        val plan = Plan.of(((v shr 38) and 3L).toInt())
        val bound = ((v shr 37) and 1L) == 1L
        val day = ((v shr 26) and 2047L).toInt()
        val ok = if (bound) {
            (v and 0x3FFFFFFL) == (mac(secret, "B|${plan.code}|$day|${normalise(deviceCode)}") and 0x3FFFFFFL)
        } else {
            val nonce = ((v shr 16) and 1023L).toInt()
            (v and 0xFFFFL) == (mac(secret, "U|${plan.code}|$day|$nonce") and 0xFFFFL)
        }
        return if (ok) Decoded(plan, bound, day) else null
    }
}
