plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Same secret as the Stream Clipper app (GitHub secret LICENSE_SECRET). Never change it, or old keys stop working.
val licenseSecret: String = System.getenv("LICENSE_SECRET")?.takeIf { it.isNotBlank() }
    ?: (project.findProperty("LICENSE_SECRET") as String?) ?: ""
if (licenseSecret.length < 12) {
    throw GradleException(
        "LICENSE_SECRET is missing or too short. In GitHub: Settings > Secrets and variables > Actions > " +
            "New repository secret, name LICENSE_SECRET (16+ characters). Use the same value for both apps."
    )
}

android {
    namespace = "app.keymaker"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.keymaker"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "LICENSE_SECRET", "\"" + licenseSecret.replace("\\", "\\\\").replace("\"", "\\\"") + "\"")
    }

    buildFeatures { buildConfig = true }

    signingConfigs {
        create("ci") {
            storeFile = file("ci.keystore")
            storePassword = "android"
            keyAlias = "ci"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("ci") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
